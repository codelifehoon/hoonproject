package skt.tmall.daemon.escrow;

import skt.tmall.daemon.bulkSmsSender.BulkSmsSenderMessageBatch;

public class E48_BulkSmsInsertMessageBatch extends EscrowBaseDaemon {

	/**
	 * @param args
	 */
	public static void main(String[] args) {
		   EscrowBaseDaemon.initSqlMap();
		   E48_BulkSmsInsertMessageBatch batch = new E48_BulkSmsInsertMessageBatch();
		   batch.run();

	}

	public void run() {
		batchName = "SmsSender ��ġ��ȯ";
        batch_no = 2548;


        /* ��ø ���� ����  */
        if (isRunning(batch_no)) {
            String errMsg = "SmsSender �̹� �������Դϴ�:";
            log.error(errMsg);
            batchLogPrint(batch_no, null, null, "-1", "User Define Error", "N/A", "Y", errMsg, errMsg);
            return;
        }

		run_sub();
	}

	public void run_sub() {
		log.debug("===== "+batchName+" START =====");
		batchLogPrint(batch_no, null, null, "-1", "Start", "N/A", "Y", "����", batchName + "����");
    	log.info("SmsSender ����!!!!!!!!!");
        batchLogStart(batch_no,"��ġ ����");
        BulkSmsSenderMessageBatch uploader = null;
        try {
        	uploader = new BulkSmsSenderMessageBatch();
        	uploader.insertMessage();

        	batchLogEnd(batch_no, "0", "Success", "N/A", "N", "ó���Ǽ�:"+0, null);
        	batchLogPrint(batch_no, null, null, "-1", "Complete", "N/A", "Y", "����", batchName + "�Ϸ�");
        } catch(Exception e) {

        	e.printStackTrace();
        	log.error(e.toString());

            String err="";
            err += " Err:"+e.toString();
            batchLogEnd(batch_no, "-1", "Error", "N/A", "Y", err, batchName + " ����");
            log.error(e);
		} finally {
			log.debug("===== "+batchName+" END =====");
		}
        log.info(batchName + " ����!!");


	}

	public void sendBatchSMS(String message, String fileName) {
		batchLogPrint(batch_no, null, null, "-1", "User Define Error", "N/A", "Y", message, fileName + "��ó��");
	}

}
