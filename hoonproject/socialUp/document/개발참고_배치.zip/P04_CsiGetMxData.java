package skt.tmall.daemon.escrow;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.Timestamp;
import java.util.Properties;

import skt.tmall.daemon.common.util.DBHandler;
import skt.tmall.daemon.pas.*;

public class P04_CsiGetMxData extends EscrowBaseDaemon {

    private static boolean debug = false;

    // MB_MEM.CSH_RCPT_REG_CD :
    final private static String SELLER_REQ_STAT_SB = "00";  // ��� ��� �� : ���� ����ڹ�ȣ ��� ��� ��
    final private static String SELLER_REQ_STAT_REQ = "01";  // ��� ��û �� : ���� ����ڹ�ȣ ��� ��û ��
    final private static String SELLER_REQ_STAT_REQS = "02";  // ��� �Ϸ� : ���� ����ڹ�ȣ ��� �Ϸ�
    final private static String SELLER_REQ_STAT_REQF = "03";  // ��� ���� : ���� ����ڹ�ȣ ��� ����
    final private static String SELLER_REQ_STAT_CREQ = "04";  // ���� ��û �� : ���� ����ڹ�ȣ ���� ��û ��
    final private static String SELLER_REQ_STAT_CREQS = "05";  // ���� �Ϸ� : ���� ����ڹ�ȣ ���� �Ϸ�
    final private static String SELLER_REQ_STAT_CREQF = "06";  // ���� ���� : ���� ����ڹ�ȣ ���� ����


    public static void main( String[] args ) {

        StdOut.setDebug( false );

        if (args.length < 2) {
            usage( );
        }
        EscrowBaseDaemon.initSqlMap();
        P04_CsiGetMxData cgmd = new P04_CsiGetMxData();

        // args[0] : ������ID, args[1] : ��û��-����(ex : 20100525)
        cgmd.run( args[0], args[1] );
    }

    private static void usage(  ) {
        StdOut.error("CsiGetExe","\tUsage: skt.tmall.daemon.escrow.P04_CsiGetMxData <CapDate_From> <CapDate>");

        System.exit(-1);
    }

	public void run( String capdate_from, String capdate ) {
		batch_no = 2704;
    	batchID = "tmba_2704";
    	batchName = "���ݿ����� ������� ���ϻ��� 1�ܰ� (1/2)";

		/* ��ø ���� ����  */
		if (isRunning(batch_no)) {
			String errMsg = "�̹� �������Դϴ�";
			log.error(errMsg);
			batchLogPrint(batch_no, null, null, "-1", "User Define Error", "N/A", "Y", errMsg, errMsg);
			return;
		}

		run_sub( capdate_from, capdate );
	}



    public void run_sub( String capdate_from, String capdate )  {

        Connection connQ    = null;
        PreparedStatement pstmt = null;
        PreparedStatement pstmt2 = null;

        ResultSet rs        = null;
        ResultSet rs2		= null;

        Connection connU    = null;

        Properties rowPam   = null;
        Properties iniPam   = null;

        String sql          = "";
        String up_file      = "";

        int index       = 0;        // Total Rows
        int failCnt     = 0;        // Fail Rows

		Timestamp to_date = new Timestamp( System.currentTimeMillis() );
		Timestamp yes_date = new Timestamp( to_date.getTime() - 24*60*60*1000 );	// ������¥

		String yes_ext = yes_date.toString().substring(0, 4) + yes_date.toString().substring(5, 7) + yes_date.toString().substring(8, 10);	// ������¥ YYYYMMDD
		String to_ext = to_date.toString().substring(0, 4) + to_date.toString().substring(5, 7) + to_date.toString().substring(8, 10);	// ���ó�¥ YYYYMMDD

		if ( capdate.equals(to_ext) ) {
			capdate = yes_ext;	// ������ ���� ������¥�� �� �޾ƿ��� ��찡 ����.
		}

        StdOut.log( "requestTR", "*** Begin - Service *** " );
        StdOut.log( "requestTR", "CapDate_From = " + capdate_from );
        StdOut.log( "requestTR", "CapDate = " + capdate );

        try {
            connQ = DBHandler.getConnection(dbUrl,dbId,dbPwd);
            StdOut.log("requestTR", "Connection to the DB sucessfully stablished. - connQ" );

            connU = DBHandler.getConnection(dbUrl,dbId,dbPwd);
            StdOut.log("requestTR", "Connection to the DB sucessfully stablished. - connU");

            connU.setAutoCommit(true);

            iniPam = new Properties();
            rowPam = new Properties();

            // Set from Argument
            iniPam.setProperty("CapDateFrom",    capdate_from );     // ó�� ���� : ���� �ŷ� ���� ���� ���� ��ġ�� ó��
            iniPam.setProperty("CapDate",    capdate );     // ó�� ���� : ���� �ŷ� ���� ���� ���� ��ġ�� ó��

            //
            iniPam   = routeVan( connQ, iniPam );
            StdOut.log("requestTR", "Initial Params : "+iniPam.toString() );


            sql = getTarget( iniPam );	// MB_MEM ���̺��� Update �� ��� ����

            StdOut.debug("requestTR", "SQL : " + sql );

            pstmt    = connQ.prepareStatement( sql );

 		   	pstmt.setString( 1, capdate_from );
 		   	pstmt.setString( 2, capdate );

            rs = pstmt.executeQuery();

            // EDI Filename
            //to_date = new Timestamp(System.currentTimeMillis());
            String to_tmp  = to_date.toString();

            // ������ ������ SYSDATE�� ���ϸ� �����Ͽ� ����
            up_file = "CSI.NTSG." + to_tmp.substring(0,4)+to_tmp.substring(5,7)+to_tmp.substring(8,10) + "_01";

            String senddate = to_tmp.substring(0,4)+to_tmp.substring(5,7)+to_tmp.substring(8,10);
            iniPam.setProperty("SendDate", senddate);

            // Initial Property
            iniPam.setProperty("UpFile",    up_file );	// ������ ���ϸ�

            StdOut.log( "requestTR", "Initial Params : "+iniPam.toString() );
            StdOut.log( "requestTR","LOOP Start! ---------------------------" );

            while ( rs.next() ) {
                try {
                    // Initial Properties Copy.
                    rowPam = iniPam;

                    rowPam.setProperty( "MemNO",  rs.getString(1) );
                    rowPam.setProperty( "SBizNO",  rs.getString(2) );

                    StdOut.log( "requestTR", "["+ index +"]="+ rowPam.toString() );


                    sql =
                    	" SELECT " +
                    		" mem_no as memno, decodeparam(mem_idnty_no) as memidno " +
                    			" FROM mb_seller_info " +
                    				" WHERE mem_no = ? ";

                    pstmt2 = null;
                    pstmt2 = connQ.prepareStatement( sql );

                    pstmt2.setString( 1, rowPam.getProperty( "MemNO" ) );
                    rs2 = pstmt2.executeQuery();


                    if ( rs2.next() ) {

                    	if ( ! rowPam.getProperty( "MemNO" ).equals( rs2.getString(2) ) ) {

                        	if ( targetUpdate( connU, rowPam ) != 1 ) {
                        		throw new PGServiceException("99999999", "Unable to update" );
                        	}
                    	}
                    } else {

                    	if ( targetInsert( connU, rowPam ) <= 0 ) {
                    		throw new PGServiceException("99999999", "Unable to insert" );
                    	}
                    }

                    StdOut.log( "requestTR", "Success. (" + rowPam.getProperty("MemNO") + ")" );
         	    } catch ( Exception e ) {
         	    	StdOut.error( "requestTR", e.getMessage() );

         	    	failCnt ++;
         	    } finally {
         	    	index ++;
         	    	DBHandler.closeDBResource(rs2, pstmt2);
         	    	//DBHandler.closeDBResource(pstmt);
         	    }
            }	// end while


            StdOut.log( "requestTR","LOOP End!   ---------------------------");
            if( index <= 0 )
                StdOut.error("requestTR", "Select was failed. 0 rows selected." );

        } catch ( Exception e ) {
            StdOut.error("requestTR", e.getMessage());
        } finally {
        	DBHandler.closeDBResource(rs, pstmt);
        	DBHandler.closeDBResource(connU);
        	DBHandler.closeDBResource(connQ);
        }

        StdOut.log( "requestTR", "*** End   - Service *** (Total Count="+index+", Fail Count="+failCnt+")" );

    }

    /**
     *
     *
     * <P/>
     * ���� �޼ҵ� ����.
     *
     * @param conn
     * @param param
     * @return
     * @throws Exception
     */
    private Properties routeVan(Connection conn, Properties param) throws Exception {

        param.setProperty("MxName",     "SKT");
        param.setProperty("MxBizNO",    "1048137225");          // ���ݿ����� ���� ����� ��ȣ(CP ����� ��ȣ)

        StdOut.debug( "routeVan", "Properties:" + param );

        return param;
    }


    private String getTarget(Properties param) throws Exception {

    	String sql = null;

    	sql =
    		" SELECT " +
    			" mem_no as memno, decodeparam(mem_idnty_no) as sbizno " +
    			" FROM   mb_mem " +
    				" WHERE  to_char(update_dt, 'yyyymmdd') >= ? " +
    					" AND    to_char(update_dt, 'yyyymmdd') <= ? " +
    					" AND    mem_clf = '02' " +
    					" AND    mem_typ_cd = '02' " +
    					" AND    mem_stat_cd = '01' " +
    					" AND    mem_stat_dtls_cd = '101' ";

    	return sql;
    }


    private int targetUpdate(Connection conn, Properties param ) throws Exception  {

        PreparedStatement pstmt = null;
        int     rows = 0;

        StdOut.debug("targetUpdate", "Properties = " + param.toString() );

        try {
            pstmt = conn.prepareStatement(
                    "UPDATE MB_SELLER_INFO " +
                    "   SET csh_rcpt_reg_cd = '" + SELLER_REQ_STAT_SB + "', csh_rcpt_req_dt = ?, csh_rcpt_aprv_no = 'E8' || SEQ_CSH_RCPT_APRVNO.nextval, " +
//                    "   SET csh_rcpt_reg_cd = '" + SELLER_REQ_STAT_REQ + "', csh_rcpt_req_dt = ?, csh_rcpt_aprv_no = 'E8' || SEQ_CSH_RCPT_APRVNO.nextval, " +
                    "		csh_rcpt_sendfile = ?, update_dt = sysdate " +
                    " WHERE mem_no = ? "
            );

            pstmt.setString(1, param.getProperty("CapDate") );
            pstmt.setString(2, param.getProperty("UpFile") );
            pstmt.setLong(3, Long.parseLong( param.getProperty("MemNO") ) );

            rows = pstmt.executeUpdate();

            if ( rows != 1 ) {
                StdOut.error("targetUpdate", "Unable to update ...  ["+param.getProperty("MemNO") +"]"  );

                throw new PGServiceException("99999999", "Unable to update ..." );
            }

        } catch ( Exception e) {
            StdOut.error("targetUpdate", e.getMessage() );
            rows = -1;
        } finally {
            DBHandler.closeDBResource(pstmt);
        }

        return rows;
    }



    private int targetInsert(Connection conn, Properties param )  {

        PreparedStatement pstmt = null;
        int     rows = 0;
        int     res = 1;

        StdOut.debug( "targetInsert", "Properties:" + param.toString() );

        try {
            pstmt = conn.prepareStatement(
                " INSERT INTO MB_SELLER_INFO " +
                        " ( mem_no, mem_idnty_no, csh_rcpt_reg_cd, csh_rcpt_req_dt, csh_rcpt_aprv_no, " +	// 1 ~ 5
                        "	csh_rcpt_sendfile, create_dt, update_dt ) " +		// 6 ~ 8
                " VALUES ( ?, encodeparam(?), ?, ?, 'E8' || SEQ_CSH_RCPT_APRVNO.nextval,		?, sysdate, sysdate ) "
            );

            pstmt.setLong(1, Long.parseLong( param.getProperty("MemNO") ) );
            pstmt.setString(2,  param.getProperty("SBizNO"));
            pstmt.setString(3,  SELLER_REQ_STAT_SB );
//            pstmt.setString(3,  SELLER_REQ_STAT_REQ );
            pstmt.setString(4,  param.getProperty("CapDate"));
            pstmt.setString(5,  param.getProperty("UpFile"));

            rows = pstmt.executeUpdate();

            if ( rows != 1 ) {
                StdOut.error("targetInsert", "Unable to save ... - MB_SELLER_INFO ["+param.getProperty("MemNO") +"]"  );

                throw new PGServiceException("99999999", "Insert Fail. To MB_SELLER_INFO. " );
            }
        } catch ( Exception e) {
            StdOut.error( "targetInsert", e.getMessage() );
            res = -1;
        } finally {
            DBHandler.closeDBResource(pstmt);
        }

        return res;
    }

}
