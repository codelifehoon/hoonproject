/**
 * �̺�Ʈ ���� ������ ���� ��ġ
 * ���� �̺�Ʈ ��Ʈ���� F/U ���ּ���.
 */
package skt.tmall.daemon.escrow;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.util.Date;

import skt.tmall.common.util.EDate;
import skt.tmall.daemon.common.util.DBHandler;

public class E20_Event extends EscrowBaseDaemon {

	/**
	 * @param args
	 */
	public static void main(String[] args) {
		E20_Event dm = new E20_Event();
		dm.run(args);
	}

	public void run(String[] args) {
		if (args == null || args.length < 1) {
			log.error("�Ķ���Ͱ� �ùٸ��� �ʽ��ϴ�.");
			return;
		}
		
		// ���ſ� �̺�Ʈ
		if ("080527_ranking".equals(args[0])) {
			run_080527_ranking(args);
			return;
		}

		log.error("ó���� �̺�Ʈ�� ã�� ���߽��ϴ�.");
	}

	/**
	 * ���ſ� ��ŷ ������ ����
	 * @param today
	 */
	public void run_080527_ranking(String[] args) {
		
		String today = "";
		if (args != null && args.length > 1) {
			today = args[1];
		}

		batchName = "���ſ� �̺�Ʈ";
		log.debug("===== "+batchName+" START =====");
		
		if (today == null || today.length() != 8) {
			Date dt = EDate.offset(new Date(), 0, 0, -1);
			today = this.dateFormat(dt, "yyyyMMdd");
		}
		
		log.debug("������� : " + today);
		
		Connection conn = null;
		PreparedStatement pstmt = null;
		ResultSet rs = null;
		
		/**
		 * �ش����� ������ ����
		 */
		StringBuffer buff = new StringBuffer();
		buff.append(" delete from mt_evnt_080527_ranking	\n ");
		buff.append(" where REG_YMD = ?					\n ");
		
		try {
			conn = DBHandler.getConnection(dbUrl,dbId,dbPwd);
			if (conn == null) {
				log.error("Connection is NULL !!!");
				throw new Exception("Connection is NULL !!!");
			}
			
			pstmt = conn.prepareStatement(buff.toString());
			pstmt.setString(1, today);
			pstmt.execute();
			
			conn.commit();
			
			DBHandler.closeDBResource(rs,pstmt);
			DBHandler.closeDBResource(conn);
			
		} catch (Exception e) {
			String err = "�������:"+today;
			err += " Err:"+e.toString();
			log.error(err);
			e.printStackTrace();
			return;
		} finally {
			try {
				DBHandler.closeDBResource(rs,pstmt);
				DBHandler.closeDBResource(conn);
			} catch (Exception e) {}
		}
		
		/**
		 * ��ŷ ����
		 */
		conn = null;
		pstmt = null;
		rs = null;
		
		buff = new StringBuffer();
		buff.append(" insert into mt_evnt_080527_ranking (REG_YMD,SEQ,MEM_NO,BUY_PRC)                                                       \n ");
		buff.append(" select ? as reg_ymd                                                                                            		\n ");
		buff.append("     , rnk as seq                                                                                                      \n ");
		buff.append("     , buy_mem_no as mem_no                                                                                            \n ");
		buff.append("     , stl_amt as buy_prc                                                                                              \n ");
		buff.append(" from (                                                                                                                \n ");
		buff.append("         select                                                                                                        \n ");
		buff.append("             buy_mem_no                                                                                                \n ");
		buff.append("             , stl_amt                                                                                                 \n ");
		buff.append("             , row_number() over (order by stl_amt desc, stl_cnt desc) as rnk                                          \n ");
		buff.append("         from (                                                                                                        \n ");
		buff.append("                 select o.buy_mem_no                                                                                   \n ");
		buff.append("                     , sum(op.ORD_PRD_WON_STL - op.ORD_CN_AMT) as stl_amt                                              \n ");
		buff.append("                     , count(1) as stl_cnt                                              								\n ");
		buff.append("                 from tr_ord o                                                                                         \n ");
		buff.append("                     ,tr_ord_prd op                                                                                    \n ");
		buff.append("                     ,dp_disp_ctgr_list c                                                                              \n ");
		buff.append("                 where o.ord_no = op.ord_no                                                                            \n ");
		buff.append("                 and op.DISP_CTGR_NO = c.DISP_CTGR_NO                                                                  \n ");
		buff.append("                 and op.ORD_PRD_WON_STL > op.ORD_CN_AMT                                                                \n ");
		buff.append("                 and o.buy_mem_no > 0                                                                                  \n ");
		buff.append("                 and o.ORD_STL_STAT = '04'   /* �ֹ���������(�����Ϸ�) */                                                	\n ");
		buff.append("                 and op.ORD_PRD_STAT = '901' /* �ֹ���ǰ����(����Ȯ��) : ����Ȯ�� �����϶� ����� */                     		\n ");
		buff.append("                 and c.DISP_CTGR1_NO in (2629,2396,2072,1930,2790)   /* ��ī�װ��� ��ȣ */                               	\n ");
		buff.append("				  and c.DISP_CTGR3_NO not in (2406,4015) /* ���� ��ī�װ��� ��ȣ */											\n ");
		buff.append("				  and c.DISP_CTGR4_NO not in (2638) /* ���� ��ī�װ��� ��ȣ */												\n ");
		int iDate = Integer.parseInt(this.dateFormat(new Date(), "yyyyMMdd"));
	    
		if(iDate<20080527){ //�̺�Ʈ ���������� �׽�Ʈ
		    //����Ȯ�� �������� ���� �ʴ´�.
	    }else {
	        buff.append("                 and op.POCNFRM_DT >= to_date('20080527'||'000000','yyyymmddhh24miss') /* ����Ȯ���� �������� */            \n ");
	    }
		
		buff.append("                 and op.POCNFRM_DT <= to_date(?||'235959','yyyymmddhh24miss') /* ����Ȯ���� �������� */         			\n ");
		
		//20080604 �߰� (���� ���� ȸ��)
		buff.append("                 and o.buy_mem_no not in																				\n ");
		buff.append("				  (select mem_no from mb_mem where mem_id in 															\n ");
		buff.append("					('kani8841','hsseo629','spah000','k535416','z76549','jspe2d','kk9832','kk535416','kk5354','kk983216')) \n ");
		
		buff.append("                 group by buy_mem_no                                                                                   \n ");
		buff.append("             )                                                                                                         \n ");
		buff.append("     )                                                                                                                 \n ");
		buff.append(" where rnk <= 100																																																				\n ");


		try {
			conn = DBHandler.getConnection(dbUrl,dbId,dbPwd);
			if (conn == null) {
				log.error("Connection is NULL !!!");
				throw new Exception("Connection is NULL !!!");
			}
			
			pstmt = conn.prepareStatement(buff.toString());
			pstmt.setString(1, today);
			pstmt.setString(2, today);
			pstmt.execute();

			conn.commit();

			DBHandler.closeDBResource(rs,pstmt);
			DBHandler.closeDBResource(conn);

		} catch (Exception e) {
			log.error(e.toString());
			e.printStackTrace();
			return;
		} finally {
			try {
				DBHandler.closeDBResource(rs,pstmt);
				DBHandler.closeDBResource(conn);
			} catch (Exception e) {}

			log.debug("===== "+batchName+" ���� END =====");
		}
	}
} // end of class
