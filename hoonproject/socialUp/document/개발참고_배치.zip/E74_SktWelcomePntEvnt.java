package skt.tmall.daemon.escrow;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

import skt.tmall.ServiceFactory;
import skt.tmall.daemon.common.util.DBHandler;
import skt.tmall.process.share.escrow.buymng.service.BuyManagementService;
import skt.tmall.process.share.escrow.buymng.service.BuyManagementServiceImpl;

public class E74_SktWelcomePntEvnt extends EscrowBaseDaemon {
	/**
	 * @param args
	 */
	public static void main(String[] args) {
		EscrowBaseDaemon.initSqlMap();
		E74_SktWelcomePntEvnt dm = new E74_SktWelcomePntEvnt();
		dm.run();
	}

	public void run() {
		batch_no = 2574;
		batchID = "tmba_bo_74";
		batchName = "�ִ� 11,000 Welcome ����Ʈ����";

		/* ��ø ���� ����  */
		if (isRunning(batch_no)) {
			String errMsg = "�̹� �������Դϴ�";
			log.error(errMsg);
			batchLogPrint(batch_no, null, null, "-1", "User Define Error", "N/A", "Y", errMsg, errMsg);
			return;
		}

		run_sub();
	}

	public void run_sub() {
		log.debug("===== "+batchName+" START =====");

		batchLogStart(batch_no,"�ִ� 11,000 Welcome ����Ʈ����");

        Connection conn = null;
        PreparedStatement pstmt = null;
        ResultSet rs = null;

        long sTime = 0;
        long eTime = 0;

        StringBuffer buff = new StringBuffer();

        buff.append("	select a.mem_no															\n");
        buff.append("	     , case when (select to_char(max(SEND_DATE),'yyyyMM')               \n");
        buff.append("	                  from TR_SKT_PNT_SEND                                  \n");
        buff.append("	                  where mem_no = a.mem_no) = to_char(sysdate,'yyyyMM')  \n");
        buff.append("	       then 'Y' else 'N' end pnt_yn                                     \n");
        buff.append("	     , to_char(sysdate,'yyyyMMdd') dl_dt                                \n");
        buff.append("	from tmall.mb_skt_phn_mem a, mb_mem b                                   \n");
        buff.append("	where a.AUTH_STAT_CD = '01'                                             \n");
        buff.append("	  and b.mem_stat_cd != '03'                                             \n");
        buff.append("	  and a.mem_no = b.mem_no                                               \n");

        /***************************************************
         * �ִ� 11,000 Welcome ����Ʈ���� ��� ��ȸ
         */
        List arMemNo 		= new ArrayList();
        List arPntYn 		= new ArrayList();
        List arDlDt 		= new ArrayList();
        int cnt = 0;

        try {

            conn = DBHandler.getConnection(dbUrl,dbId,dbPwd);
            if (conn == null) {
                log.error("Connection is NULL !!!");
                throw new Exception("Connection is NULL !!!");
            }

            log.info(buff.toString());
            pstmt = conn.prepareStatement(buff.toString());
            sTime = System.currentTimeMillis();
            log.error("�ִ� 11,000 Welcome ����Ʈ���� ���ǰ������� ����");
            rs = pstmt.executeQuery();
            while( rs.next() ) {
            	arMemNo.add(rs.getString("mem_no"));
            	arPntYn.add(rs.getString("pnt_yn"));
            	arDlDt.add(rs.getString("dl_dt"));
            	cnt++;
            }
            eTime = System.currentTimeMillis();
            log.error("���Ǽ�===>"+cnt);
            log.error("�ִ� 11,000 Welcome ����Ʈ���� ���ǰ������� ���� : ����ð� ===> "+((double)(eTime-sTime) / (double)1000)+" sec");

            DBHandler.closeDBResource(rs,pstmt);
            DBHandler.closeDBResource(conn);

        } catch (Exception e) {
			batchLogEnd(batch_no, "-1", "ERROR", "step.01", "Y", "�ִ� 11,000 Welcome ����Ʈ���� ��ȸ ����", "�ִ� 11,000 Welcome ����Ʈ���� ��ȸ ����");
            e.printStackTrace();
            log.error(e.toString());
            return;
        } finally {
            try {
                DBHandler.closeDBResource(rs,pstmt);
                DBHandler.closeDBResource(conn);
            } catch (Exception e) {}
        }


        /******************************
         * �ִ� 11,000 Welcome ����Ʈ���� ó��
         */

        if (arMemNo.size() <= 0) {
			batchLogEnd(batch_no, "0", "Success", "N/A", "N", "�ִ� 11,000 Welcome ����Ʈ���� ���� : ������", "�ִ� 11,000 Welcome ����Ʈ���� ���� : ������");
			return;
        }

        String msg = "�ִ� 11,000 Welcome ����Ʈ����";
        try {
            BuyManagementService buyManagementService = (BuyManagementService)ServiceFactory.createService( BuyManagementServiceImpl.class );

            long cntSucc = 0;
            long cntFail = 0;
            int cntProc = 0;
            long smsCnt = 0;

            for(int i=0; i<arMemNo.size(); i++)
            {
            	sTime = System.currentTimeMillis();
                cntProc ++;
                log.info("############################################################");
                log.info("### [" + cntProc + "] ȸ����ȣ : " + (String)arMemNo.get(i) + " START~!!");
                log.info("############################################################");
                try {
                	String sktPntYn = (String)arPntYn.get(i);

                	if(sktPntYn != null && "N".equals(sktPntYn)){
                		buyManagementService.sktWelcomePntEvnt((String)arMemNo.get(i), (String)arDlDt.get(i));
                		boolean result = pntSendOkSms((String)arMemNo.get(i));

                		if(result){
                			smsCnt++;
                		}

                		cntSucc++;
                	}

                } catch (SQLException e) {
                    log.error("�ִ� 11,000 Welcome ����Ʈ���� ����!");
                    log.error(e.getMessage());
                    log.error("### 1ȸ����ȣ : " + (String)arMemNo.get(i));
                    cntFail++;
                } catch (Exception e) {
                    log.error("�ִ� 11,000 Welcome ����Ʈ���� ����!");
                    log.error(e.getMessage());
                    log.error("### 2ȸ����ȣ : " + (String)arMemNo.get(i));
                    cntFail++;
                }
                eTime = System.currentTimeMillis();
                if ( ((i+1)%5000) == 0 )
                {
                	log.error("[" + String.valueOf(i+1) + "/" + String.valueOf(arMemNo.size()) + "] �ִ� 11,000 Welcome ����Ʈ����("+(String)arMemNo.get(i)+") ����ð�===> "+((double)(eTime-sTime) / (double)1000)+" sec");
                }
                log.info("############################################################");
                log.info("### [" + cntProc + "] ȸ����ȣ : " + (String)arMemNo.get(i) + " END~!!");
                log.info("############################################################");
            }

            msg += " : ���� " + cntSucc + "��, sms ���� " + smsCnt + "��";
            msg += " : ���� " + cntFail + "��";
            String errYN = (cntFail > 0) ? "Y" : "N";

        	batchLogEnd(batch_no, "0", "Success", "step.02", errYN, msg, msg);
        } catch (Exception e) {
			batchLogEnd(batch_no, "-1", "ERROR", "step.03", "Y", "�ִ� 11,000 Welcome ����Ʈ���� ����", "�ִ� 11,000 Welcome ����Ʈ���� ����");
            e.printStackTrace();
            log.error(e.toString());
        } finally {
            log.error("===== "+msg+" END =====");
        }
	}

	private boolean pntSendOkSms(String memNo) {
		Connection conn = null;
        PreparedStatement pstmt = null;
        PreparedStatement inPstmt = null;
        ResultSet rs = null;

        boolean result = false;

        StringBuffer buff = new StringBuffer();

        StringBuffer inBuff = new StringBuffer();

        buff.append("	select a.mem_no, nvl(replace(a.PRTBL_TLPHN_NO,'-',''), '') ph_tel		\n");
        buff.append("	from mb_mem a, tmall.mb_skt_phn_mem b                              		\n");
        buff.append("	where a.mem_no = ?		                                        		\n");
        buff.append("	  and a.mem_no = b.mem_no                                       		\n");
        buff.append("	  and SMS_RCV_YN = 'Y'                                          		\n");
        buff.append("	  and mem_stat_cd != '03'												\n");

        inBuff.append("	INSERT INTO MESSAGE																			\n");
        inBuff.append("			(msgid,                                                                             \n");
        inBuff.append("			msgmemid,                                                                           \n");
        inBuff.append("			adminid,                                                                            \n");
        inBuff.append("			msgheadertype,                                                                      \n");
        inBuff.append("			msgreservetype,                                                                     \n");
        inBuff.append("			msgreservename,                                                                     \n");
        inBuff.append("			msgsendto,                                                                          \n");
        inBuff.append("			msgtitle,                                                                           \n");
        inBuff.append("			msgsenddate,                                                                        \n");
        inBuff.append("			msgsendlimitdate,                                                                   \n");
        inBuff.append("			msgcontentfilepath,                                                                 \n");
        inBuff.append("			msgtobelog,                                                                         \n");
        inBuff.append("			seq,                                                                                \n");
        inBuff.append("			callback,                                                                           \n");
        inBuff.append("			start_date,                                                                         \n");
        inBuff.append("			start_time,                                                                         \n");
        inBuff.append("			end_date,                                                                           \n");
        inBuff.append("			end_time,                                                                           \n");
        inBuff.append("			msgstatus,                                                                          \n");
        inBuff.append("			teleinfo,                                                                           \n");
        inBuff.append("			msgsubid,                                                                           \n");
        inBuff.append("			tid )                                                                               \n");
        inBuff.append("	VALUES (seqmsgid.NEXTVAL,                                                               	\n");
        inBuff.append("			0,                                                                                  \n");
        inBuff.append("			'admin',                                                                            \n");
        inBuff.append("			'7',                                                                                \n");
        inBuff.append("			'7',                                                                                \n");
        inBuff.append("			'[11��',                                                                            \n");
        inBuff.append("			?,                                                                                  \n");
        inBuff.append("			'11����>11�� Welcome����Ʈ1,000P',                                                  	\n");
        inBuff.append("			SYSDATE,                                                                            \n");
        inBuff.append("			SYSDATE + (1 / 12),                                                                 \n");
        inBuff.append("			'11����>11�� Welcome����Ʈ1,000P�� �����Ǿ����ϴ�-����11���� Ȯ�� �ź�0808505297',  		\n");
        inBuff.append("			'7',                                                                                \n");
        inBuff.append("			seqmsgid.NEXTVAL,                                                                   \n");
        inBuff.append("			'15990110',                                                                           \n");
        inBuff.append("			TO_CHAR (SYSDATE, 'yyyymmdd'),                                                      \n");
        inBuff.append("			TO_CHAR (SYSDATE, 'hh24mi'),                                                        \n");
        inBuff.append("			TO_CHAR (SYSDATE + (1 / 12), 'yyyymmdd'),                                           \n");
        inBuff.append("			TO_CHAR (SYSDATE + (1 / 12), 'hh24mi'),                                             \n");
        inBuff.append("			'6',                                                                                \n");
        inBuff.append("			'SK',                                                                               \n");
        inBuff.append("			0,                                                                                  \n");
        inBuff.append("			1116                                                                                \n");
        inBuff.append("	)                                                                                       	\n");

        List arMemNo 		= new ArrayList();
        List arPhTel 		= new ArrayList();

        try {
            conn = DBHandler.getConnection(dbUrl,dbId,dbPwd);
            if (conn == null) {
                log.error("Connection is NULL !!!");
                throw new Exception("Connection is NULL !!!");
            }

            pstmt = conn.prepareStatement(buff.toString());
            pstmt.setString(1, memNo);

            rs = pstmt.executeQuery();
            while( rs.next() ) {
            	arMemNo.add(rs.getString("mem_no"));
            	arPhTel.add(rs.getString("ph_tel"));
            }

            DBHandler.closeDBResource(rs,pstmt);

            for(int i=0; i < arMemNo.size(); i++){
            	inPstmt = conn.prepareStatement(inBuff.toString());
            	inPstmt.setString(1, (String)arPhTel.get(i));
            	inPstmt.executeUpdate();

            	DBHandler.closeDBResource(inPstmt);
            }

            DBHandler.closeDBResource(conn);

            return true;

        } catch (Exception e) {
			batchLogEnd(batch_no, "-1", "ERROR", "step.04", "Y", "�ִ� 11,000 Welcome SMS ����", "�ִ� 11,000 Welcome SMS ����");
            e.printStackTrace();
            log.error(e.toString());
            return false;
        } finally {
            try {
                DBHandler.closeDBResource(rs,pstmt);
                DBHandler.closeDBResource(inPstmt);
                DBHandler.closeDBResource(conn);
            } catch (Exception e) {}
        }
	}
}
