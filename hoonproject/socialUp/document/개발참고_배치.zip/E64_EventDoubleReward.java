package skt.tmall.daemon.escrow;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

import skt.tmall.BOFactory;
import skt.tmall.ServiceFactory;
import skt.tmall.business.escrow.trade.domain.OrderProductBO;
import skt.tmall.daemon.common.util.DBHandler;
import skt.tmall.process.share.escrow.buymng.service.BuyManagementService;
import skt.tmall.process.share.escrow.buymng.service.BuyManagementServiceImpl;

/**
 * ����Ʈ ������ �̺�Ʈ
 *
 */
public class E64_EventDoubleReward extends EscrowBaseDaemon {
    /**
     * @param args
     */
    public static void main(String[] args) {
        EscrowBaseDaemon.initSqlMap();
        E64_EventDoubleReward dm = new E64_EventDoubleReward();
        dm.run();
    }


	public void run() {
		batch_no = 2564;
    	batchID = "tmba_bo_64";
    	batchName = "����Ʈ ������ �̺�Ʈ";

		/* ��ø ���� ����  */
		if (isRunning(batch_no)) {
			String errMsg = "�̹� �������Դϴ�";
			log.error(errMsg);
			batchLogPrint(batch_no, null, null, "-1", "User Define Error", "N/A", "Y", errMsg, errMsg);
			return;
		}

		run_sub();
	}

	@SuppressWarnings("unchecked")
	public void run_sub() {
    	log.debug("===== "+batchName+" START =====");

		batchLogStart(batch_no,"����Ʈ ������ �̺�Ʈ");

        Connection conn = null;
        PreparedStatement pstmt = null;
        ResultSet rs = null;

        long sTime = 0;
        long eTime = 0;

        StringBuffer buff = new StringBuffer();
        buff.append("	    select 																													  ");
        buff.append("	           a.MEM_NO                                                                                                           ");
        buff.append("	         , a.STATUS                                                                                                           ");
        buff.append("	         , a.ORD_NO_1                                                                                                         ");
        buff.append("	         , a.POINT_1                                                                                                          ");
        buff.append("	         , a.ORD_NO_2                                                                                                         ");
        buff.append("	         , a.POINT_2                                                                                                          ");
        buff.append("	         , a.REWARD_SEQ, b.ord_no				                                                                              ");
        buff.append("	    from MT_PNT_DOUBLE_REWARD a                                                                                               ");
        buff.append("	       , tr_ord b                                                                                                             ");
        buff.append("	       , tr_ord_prd c                                                                                                         ");
        buff.append("	    where a.mem_no = b.BUY_MEM_NO                                                                                             ");
        buff.append("	      and a.status in ('03','04')                                                                                             ");
        buff.append("		  and not exists (select 1 from MT_PNT_DOUBLE_REWARD where ORD_NO_1 = b.ord_no and mem_no = b.buy_mem_no)                 ");
        buff.append("		  and not exists (select 1 from MT_PNT_DOUBLE_REWARD where ORD_NO_2 = b.ord_no and mem_no = b.buy_mem_no)                 ");
        buff.append("	      and b.ord_no = c.ord_no                                                                                                 ");
        buff.append("	      and c.ORD_PRD_STAT = '901'                                                                                              ");
        buff.append("	      and c.POCNFRM_DT between to_date('20100605000000','yyyyMMddHH24miss') and to_date('20100731235959','yyyyMMddHH24miss')  ");
        buff.append("	    group by  a.MEM_NO                                                                                                        ");
        buff.append("	         , a.STATUS                                                                                                           ");
        buff.append("	         , a.ORD_NO_1                                                                                                         ");
        buff.append("	         , a.POINT_1                                                                                                          ");
        buff.append("	         , a.ORD_NO_2                                                                                                         ");
        buff.append("	         , a.POINT_2                                                                                                          ");
        buff.append("	         , a.REWARD_SEQ, b.ord_no				                                                                              ");

        List arOrdNo 		= new ArrayList();
        List arOrdPrdSeq	= new ArrayList();

        int cnt = 0;

        try {

            conn = DBHandler.getConnection(dbUrl,dbId,dbPwd);
            if (conn == null) {
                log.error("Connection is NULL !!!");
                throw new Exception("Connection is NULL !!!");
            }

            log.info(buff.toString());
            pstmt = conn.prepareStatement(buff.toString());
            sTime = System.currentTimeMillis();
            log.error("����Ʈ ������ �̺�Ʈ ���ǰ������� ����");
            rs = pstmt.executeQuery();
            while( rs.next() ) {
            	arOrdNo.add(rs.getString("ord_no"));
            	arOrdPrdSeq.add("1");
            	cnt++;
            }
            eTime = System.currentTimeMillis();
            log.error("���Ǽ�===>"+cnt);
            log.error("����Ʈ ������ �̺�Ʈ  ���ǰ������� ���� : ����ð� ===> "+((double)(eTime-sTime) / (double)1000)+" sec");

            DBHandler.closeDBResource(rs,pstmt);
            DBHandler.closeDBResource(conn);

        } catch (Exception e) {
			batchLogEnd(batch_no, "-1", "ERROR", "step.01", "Y", "����Ʈ ������ �̺�Ʈ ��ȸ ����", "����Ʈ ������ �̺�Ʈ ��ȸ ����");
            e.printStackTrace();
            log.error(e.toString());
            return;
        } finally {
            try {
                DBHandler.closeDBResource(rs,pstmt);
                DBHandler.closeDBResource(conn);
            } catch (Exception e) {}
        }


        /******************************
         * ����Ʈ ������ �̺�Ʈ ����� ����
         */

        if (arOrdNo.size() <= 0) {
			batchLogEnd(batch_no, "0", "Success", "N/A", "N", "����Ʈ ������ �̺�Ʈ  ���� : ������", "����Ʈ ������ �̺�Ʈ ���� : ������");
			return;
        }

        String msg = "����Ʈ ������ �̺�Ʈ";
        try {
        	BuyManagementService buyManagementService = (BuyManagementService)ServiceFactory.createService( BuyManagementServiceImpl.class );
        	OrderProductBO		 paramBO              = null;


            long cntSucc = 0;
            long cntFail = 0;
            int cntProc = 0;

            for(int i=0; i<arOrdNo.size(); i++)
            {
            	sTime = System.currentTimeMillis();
                cntProc ++;
                log.info("############################################################");
                log.info("### [" + cntProc + "] �ֹ���ȣ : " + (String)arOrdNo.get(i) + " START~!!");
                log.info("############################################################");
                try {
                    paramBO = (OrderProductBO)BOFactory.createBO(OrderProductBO.class);
                    paramBO.setOrdNo( (String)arOrdNo.get(i) );
                    paramBO.setOrdPrdSeq( (String)arOrdPrdSeq.get(i) );

                    buyManagementService.batchEventDoubleReward(paramBO);

                    cntSucc++;

                } catch (SQLException e) {
                    log.error("����Ʈ ������ �̺�Ʈ ����!");
                    log.error(e.getMessage());
                    cntFail++;
                } catch (Exception e) {
                    log.error("����Ʈ ������ �̺�Ʈ ����!");
                    log.error(e.getMessage());
                    cntFail++;
                }
                eTime = System.currentTimeMillis();
                if ( ((i+1)%5000) == 0 )
                {
                	log.error("[" + String.valueOf(i+1) + "/" + String.valueOf(arOrdNo.size()) + "] ����Ʈ ������ �̺�Ʈ ("+(String)arOrdNo.get(i)+","+") ����ð�===> "+((double)(eTime-sTime) / (double)1000)+" sec");
                }
            }

            msg += " : ���� " + cntSucc + "��";
            msg += " : ���� " + cntFail + "��";
            String errYN = (cntFail > 0) ? "Y" : "N";

        	batchLogEnd(batch_no, "0", "Success", "step.02", errYN, msg, msg);
        } catch (Exception e) {
			batchLogEnd(batch_no, "-1", "ERROR", "step.03", "Y", "����Ʈ ������ �̺�Ʈ ����", "����Ʈ ������ �̺�Ʈ ����");
            e.printStackTrace();
            log.error(e.toString());
        } finally {
            log.error("===== "+msg+" END =====");
        }
    }

} // end of class