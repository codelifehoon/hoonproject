package skt.tmall.daemon.escrow;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.util.Date;

import skt.tmall.common.util.EDate;
import skt.tmall.daemon.common.util.DBHandler;

/**
 * �����ϸ��� ��ġ
 * @author ZZ07237
 *
 */
public class E63_BizprocMonitor extends EscrowBaseDaemon {

	/**
	 * @param args
	 */
	public static void main(String[] args) {
		E63_BizprocMonitor dm = new E63_BizprocMonitor();
		String startDT = null;
		String endDt = null;

		if (args != null && args.length == 2)
		{
			startDT = args[0];
			endDt = args[1];
		}
		dm.run(startDT,endDt);
	}

	public void run(String startDT,String endDt) {
		batch_no = 2576;
		batchID = "";
		batchName = "��������͸�";

		/* ��ø ���� ����  */
		if (isRunning(batch_no)) {
			String errMsg = "�̹� �������Դϴ�:" ;
			log.error(errMsg);
			batchLogPrint(batch_no, null, null, "-1", "User Define Error", "N/A", "Y", errMsg, errMsg);
			return;
		}

		run_sub(startDT,endDt);
	}

	public void run_sub(String startDT,String endDt) {
		log.debug("===== "+batchName+" START =====");

		Connection conn = null;
		PreparedStatement pstmt = null;
		ResultSet rs = null;

		try
		{


			// ����,������ ����
			if ( ( startDT == null || startDT.length() == 14)
					&& ( endDt == null || endDt.length() == 14) )
			{
				//
			}
			else
			{
				throw new Exception("����,��������  �Է����� �ʰų�  ����Ͻú���(14�ڸ�)�� �־��ּ���.");
			}

			StringBuffer buff = new StringBuffer();

			if (startDT == null )
			{
				buff.append("	BEGIN 							\n");
				buff.append("		/* ����Ͻ� ���� ����͸� (05.tMallETCProject/src/skt/tmall/daemon/escrow/E63_BizprocMonitor.java */	 \n");
				buff.append("   	 SP_SE_BIZPROC_MONITOR(null,null);	\n");
				buff.append("	END;							\n");
			}
			else
			{
				buff.append("	BEGIN 							\n");
				buff.append("		/* ����Ͻ� ���� ����͸� (05.tMallETCProject/src/skt/tmall/daemon/escrow/E63_BizprocMonitor.java */	 \n");
				buff.append("   	 SP_SE_BIZPROC_MONITOR(to_date(?,'YYYYMMDDHH24MISS'),to_date(?,'YYYYMMDDHH24MISS'));	\n");
				buff.append("	END;							\n");
			}

			if (log.isDebugEnabled())
			{
				log.debug("buff:" + buff);
				log.debug("startDT:" + startDT);
				log.debug("endDt:" + endDt);
			}

			conn = DBHandler.getConnection(dbUrl,dbId,dbPwd);
			if (conn == null)
			{
				log.error("Connection is NULL !!!");
				throw new Exception("Connection is NULL !!!");
			}

			pstmt = conn.prepareStatement(buff.toString());

			// ��ȸ���� �����Ѵٸ� ����,������ ���ε�.
			if (startDT != null )
			{
				pstmt.setString(1, startDT);
				pstmt.setString(2, endDt);
			}

			pstmt.execute();

			DBHandler.closeDBResource(rs,pstmt);
			DBHandler.closeDBResource(conn);


		} catch (Exception e)
		{
			e.printStackTrace();
		} finally {
			try {
				DBHandler.closeDBResource(rs,pstmt);
				DBHandler.closeDBResource(conn);
			} catch (Exception e) {e.printStackTrace();}

			log.debug("===== "+batchName+" END =====");
		}
	}
} // end of class
