package skt.tmall.daemon.escrow;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.util.ArrayList;
import java.util.List;

import skt.tmall.ServiceFactory;
import skt.tmall.business.escrow.trade.domain.OrderClaimDeliveryListBO;
import skt.tmall.daemon.common.util.DBHandler;
import skt.tmall.process.share.escrow.shipping.service.ShippingInterfaceService;
import skt.tmall.process.share.escrow.shipping.service.ShippingInterfaceServiceImpl;

import com.ibatis.sqlmap.client.SqlMapClient;
import com.skt.omp.common.db.SqlMapLoader;

/**
 * GoodsFlow ������
 * �߼�ó���� 7�� ���� ��ۿ� ���� ��۾ȵȰ��
 * GoodsFlow �� �������� �Ѵ�.
 * @author ZZ07237
 * @version 0.1
 */
public class E18_GoodsFlowResend extends EscrowBaseDaemon {

	/**
	 * @param args
	 */
	public static void main(String[] args) {
        EscrowBaseDaemon.initSqlMap();
        E18_GoodsFlowResend dm = new E18_GoodsFlowResend();
		dm.run();
	}

	public void run() {
		batchName = "GoodsFlow ������";
        batch_no = 2518;


        /* ��ø ���� ����  */
        if (isRunning(batch_no)) {
            String errMsg = "�̹� �������Դϴ�:";
            log.error(errMsg);
            batchLogPrint(batch_no, null, null, "-1", "User Define Error", "N/A", "Y", errMsg, errMsg);
            return;
        }

		run_sub();
	}

	public void run_sub() {
		log.debug("===== "+batchName+" START =====");

    	log.info("��۰�� ���� ������Ʈ ����!!!!!!!!!");
        batchLogStart(batch_no,"��ġ ����");

        SqlMapClient sqlMapClient = null;

        try {
        	List<OrderClaimDeliveryListBO> list = getResendList();
        	if (list != null && list.size() > 0) {
				sqlMapClient = SqlMapLoader.getInstance();
	        	sqlMapClient.startTransaction();
				log.debug("sqlMapClient : " + sqlMapClient);

				ShippingInterfaceService shippingInterfaceService = (ShippingInterfaceService)ServiceFactory.createService( ShippingInterfaceServiceImpl.class );
	            shippingInterfaceService.setProperties(prop);
				shippingInterfaceService.getDeliveryFileSend(sqlMapClient, list);

				sqlMapClient.commitTransaction();
        	}

            batchLogEnd(batch_no, "0", "Success", "N/A", "N", "ó���Ǽ�:"+list.size(), null);
        }
        catch(Exception e) {
        	if (sqlMapClient != null) {
        		try {
        			sqlMapClient.endTransaction();
        		} catch (Exception e2) {}
        	}

        	e.printStackTrace();
        	log.error(e.toString());

            String err="";
            err += " Err:"+e.toString();
            batchLogEnd(batch_no, "-1", "Error", "N/A", "Y", err, batchName + " ����");
            log.error(e);
		} finally {
			log.debug("===== "+batchName+" END =====");
		}
        log.info(batchName + " ����!!");
    }

	public List<OrderClaimDeliveryListBO> getResendList() {

		List<OrderClaimDeliveryListBO> list = new ArrayList<OrderClaimDeliveryListBO>();

		Connection conn = null;
		PreparedStatement pstmt = null;
		ResultSet rs = null;

		/**
		 * @author �ȿ
		 * buff�� ��� �����մϴ�. ����� ���������� ���ؼ�
		 *
		 */
		StringBuffer buff = new StringBuffer();
		buff.append(" SELECT  /*+ INDEX (a PK_TR_ORD) */                                 \n");
		buff.append(" 		distinct(d.dlv_no) as dlv_no                                 \n");
		buff.append(" FROM    tr_ord a                                                   \n");
		buff.append("         , tr_ord_prd b                                             \n");
		buff.append("         , tr_ord_clm_delvplace c                                   \n");
		buff.append("         , tr_ord_clm_dlv_dtls d                                    \n");
		buff.append("         , mb_mem f                                                 \n");
		buff.append("         , pd_prd_tgow_plc_exch_rtngd g                             \n");
		buff.append("         , mb_addr h                                                \n");
		buff.append("         , sy_mail_no i                                             \n");
		buff.append(" WHERE   a.ord_no = b.ord_no                                        \n");
		buff.append("         and c.delvplace_seq = b.delvplace_seq                      \n");
		buff.append("         and d.dlv_no = b.dlv_no                                    \n");
		buff.append("         and c.del_yn = 'N'                                         \n");
		buff.append("         and d.dlv_etprs_cd is not null                             \n");
		buff.append("         and d.del_yn = 'N'                                         \n");
		buff.append("         and f.mem_no = b.seller_mem_no                             \n");
		buff.append("         and g.prd_no = b.prd_no                                    \n");
		buff.append("         and g.mem_no = f.mem_no                                    \n");
		buff.append("         and g.prd_addr_clf_cd = '01' /** ����� **/                  \n");
		buff.append("         and h.mem_no = f.mem_no                                    \n");
		buff.append("         and h.addr_seq = g.addr_seq                                \n");
		buff.append("         and i.mail_no = h.mail_no                                  \n");
		buff.append("         and i.mail_no_seq = h.mail_no_seq                          \n");
		buff.append("         and d.DLV_OCCR_TY = '01'               /* �߼���ü : 01 : �����, 02: ��ȯ�߼�, 04 : ��ǰ�߼� */    \n");
		buff.append("         and d.dlv_etprs_cd NOT IN ('00099')	                     \n");
		buff.append("         and rownum <= 500                                          \n");
		buff.append("         and b.ORD_PRD_STAT = '401'			/* �߼ۿϷ� */             \n");
		buff.append("         and b.prd_typ_cd = '01'                /* ��ǰ�ֹ��ڵ�(PD018) */  \n");
		buff.append("         and d.DLV_MTHD_CD in ('01','02','03') 	/* ��۹��(TR044) */  \n");
		buff.append("         and d.GOODSFLOW_SEND_DT is null		/* �½��÷����� ���� */  \n");
		buff.append("         and d.SND_END_DT < sysdate-1		/* �߼ۿϷ��� 7�� */       \n");


		StringBuffer buffer = new StringBuffer();
        buffer.append(" SELECT  /*+ INDEX (a PK_TR_ORD) */                                 \n");
        buffer.append("       distinct(d.dlv_no) as dlv_no                                 \n");
        buffer.append(" FROM    tr_ord a                                                   \n");
        buffer.append("         , tr_ord_prd b                                             \n");
        buffer.append("         , tr_ord_clm_delvplace c                                   \n");
        buffer.append("         , tr_ord_clm_dlv_dtls d                                    \n");
        buffer.append("         , TR_TRSNP_ETPRS_EXTR e									   \n");
        buffer.append(" WHERE   a.ord_no = b.ord_no                                        \n");
        buffer.append("         and c.delvplace_seq = b.delvplace_seq                      \n");
        buffer.append("         and d.dlv_no = b.dlv_no                                    \n");
        buffer.append("         and c.del_yn = 'N'                                         \n");
        buffer.append("         and d.dlv_etprs_cd is not null                             \n");
        buffer.append("         and d.del_yn = 'N'                                         \n");
        buffer.append("         and d.DLV_OCCR_TY = '01'               /* �߼���ü : 01 : �����, 02: ��ȯ�߼�, 04 : ��ǰ�߼� */    \n");
        buffer.append("         and d.dlv_etprs_cd = e.dlv_etprs_cd	                                                            \n");
        buffer.append("         and e.GOODSFLOW_TRACE_YN = 'Y'                                                                  \n");
//        buffer.append("         and d.dlv_etprs_cd NOT IN ('00099')                          \n");
        buffer.append("         and b.ORD_PRD_STAT = '401'            /* �߼ۿϷ� */             \n");
//        buffer.append("         and b.prd_typ_cd = '01'                /* ��ǰ�ֹ��ڵ�(PD018) */  \n");
        buffer.append("         and d.DLV_MTHD_CD in ('01','02','03')     /* ��۹��(TR044) */  \n");
        buffer.append("         and d.GOODSFLOW_SEND_DT is null       /* �½��÷����� ���� */  \n");
//        buffer.append("         and d.SND_END_DT < sysdate-12/24      /* �߼ۿϷ��� 7�� */       \n");
//        buffer.append("         and d.SND_END_DT > sysdate-22/24      /* �߼ۿϷ��� 7�� */       \n");
        buffer.append("         and d.SND_END_DT < sysdate-12/24      /* �߼ۿϷ��� 7�� */       \n");
        buffer.append("         and d.SND_END_DT > sysdate-10      /* �߼ۿϷ��� 7�� */       \n");
        buffer.append("         and (b.CHINA_SALE_YN is null or b.CHINA_SALE_YN = 'N')     \n");
        buffer.append("         and rownum <= 1500                                          \n");


		try {
			conn = DBHandler.getConnection(dbUrl,dbId,dbPwd);
			if (conn == null) {
				log.error("Connection is NULL !!!");
				throw new Exception("Connection is NULL !!!");
			}

			pstmt = conn.prepareStatement(buffer.toString());
			rs = pstmt.executeQuery();
			while( rs.next() ) {
				OrderClaimDeliveryListBO bo = new OrderClaimDeliveryListBO();
				bo.setDlvNo(rs.getString("dlv_no"));
				list.add(bo);
			}

			DBHandler.closeDBResource(rs,pstmt);
			DBHandler.closeDBResource(conn);

		} catch (Exception e) {
			e.printStackTrace();
			log.error(e.toString());
		} finally {
			try {
				DBHandler.closeDBResource(rs,pstmt);
				DBHandler.closeDBResource(conn);
			} catch (Exception e) {}

			log.debug("===== "+batchName+" ���� END =====");
		}

		return list;
	}



	public List<OrderClaimDeliveryListBO> Not_work_getResendList() {

	        List<OrderClaimDeliveryListBO> list = new ArrayList<OrderClaimDeliveryListBO>();

	        String[] dlv_no = {
	        		"43697122"


	        };

	        try {
	               for(int i = 0; i < dlv_no.length; i++) {
	                OrderClaimDeliveryListBO bo = new OrderClaimDeliveryListBO();
	                bo.setDlvNo(dlv_no[i]);
	                list.add(bo);
	               }

	        } catch (Exception e) {
	            e.printStackTrace();
	            log.error(e.toString());
	        } finally {

	            log.debug("===== "+batchName+" ���� END =====");
	        }

	        return list;
	    }


} // end of class
