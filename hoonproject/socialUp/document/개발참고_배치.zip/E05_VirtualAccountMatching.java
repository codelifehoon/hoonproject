package skt.tmall.daemon.escrow;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;

import skt.tmall.daemon.common.util.DBHandler;

/**
 * ������ �Ա� ��Ī ó��
 * @author ZZ07237
 *
 */
public class E05_VirtualAccountMatching extends EscrowBaseDaemon {

	/**
	 * @param args
	 */
	public static void main(String[] args) {
		E05_VirtualAccountMatching dm = new E05_VirtualAccountMatching();
		dm.run();
	}

	public void run() {
		batch_no = 2505;
		batchID = "tmba_bo_05";
		batchName = "������ �Ա� ��Ī ó��";
		
		/* ��ø ���� ����  */
		if (isRunning(batch_no)) {
			String errMsg = "�̹� �������Դϴ�";
			log.error(errMsg);
			batchLogPrint(batch_no, null, null, "-1", "User Define Error", "N/A", "Y", errMsg, errMsg);
			return;
		}
		
		run_sub();
	}

	public void run_sub() {
		log.debug("===== "+batchName+" START =====");

		batchLogStart(batch_no,"������� �Աݸ�Ī");

		Connection conn = null;
		PreparedStatement pstmt = null;
		ResultSet rs = null;
		
		StringBuffer buff = new StringBuffer();
		buff.append("	BEGIN /* ������ �Ա� ��Ī ó�� (/05.tMallETCProject/src/skt/tmall/daemon/escrow/VirtualAccountMatching.java) */	\n");
		buff.append("   	SP_VIRTUALACCOUNT_MATCHING;	\n");
		buff.append("	END;							\n");

		try {
			conn = DBHandler.getConnection(dbUrl,dbId,dbPwd);
			if (conn == null) {
				log.error("Connection is NULL !!!");
				throw new Exception("Connection is NULL !!!");
			}
			
			pstmt = conn.prepareStatement(buff.toString());
			pstmt.execute();
			
			DBHandler.closeDBResource(rs,pstmt);
			DBHandler.closeDBResource(conn);
			
			batchLogEnd(batch_no, "0", "Success", "N/A", "N", "������ �Աݸ�Ī ����", null);
		} catch (Exception e) {
			batchLogEnd(batch_no, "-1", "ERROR", "N/A", "Y", "������ �Աݸ�Ī ����", "������ �Աݸ�Ī ����");
			log.error(e.toString());
		} finally {
			try {
				DBHandler.closeDBResource(rs,pstmt);
				DBHandler.closeDBResource(conn);
			} catch (Exception e) {}

			log.debug("===== "+batchName+" END =====");
		}
	}
} // end of class
