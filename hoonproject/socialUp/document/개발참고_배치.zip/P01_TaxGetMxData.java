package skt.tmall.daemon.escrow;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.Statement;
import java.sql.Timestamp;
import java.util.Properties;

import skt.tmall.daemon.common.util.DBHandler;
import skt.tmall.daemon.pas.*;


/**
 * Class�� ���� ������ �Է��� �ּ���.
 * <p/>
 * ���� ������ �Է��� �ּ���.
 *
 * @author  �̿���
 */
public class P01_TaxGetMxData extends EscrowBaseDaemon {

    private static boolean debug = false;

    // TR_CSH_RCPT_RQST.CASH_RCPT_REQ_STAT :
    final private static String OM_REQ_STAT_WAIT = "01";  // ��û��� : tMall���� Hollding�Ͽ� ���� ����
    final private static String OM_REQ_STAT_REQU = "02";  // ��û���� : ���������� ������ ��û�� ��
    final private static String OM_REQ_STAT_CANC = "03";  // ��û��� : ��û�� �������� �������� tMall���� ����Ѱ�
    final private static String OM_REQ_STAT_RECE = "04";  // ��û���� : PAS���� ���ݿ�����ó���� ���� ������ ����
    final private static String OM_REQ_STAT_TERM = "05";  // ó���Ϸ� : ���ݿ����� ó���Ϸ� ����
    final private static String OM_REQ_STAT_FAIL = "06";  // ó������ : ���ݿ����� ó������ ����

    public static void main( String[] args ) {

        EscrowBaseDaemon.initSqlMap();
        P01_TaxGetMxData dm = new P01_TaxGetMxData();

        StdOut.setDebug( false );

        if (args.length < 2) {
            usage( );
        }

        // args[0] : ������ID, args[1] : ��û��-����(ex : 20100525)
        dm.run( args[0], args[1] );
    }

    private static void usage(  ) {
        StdOut.error("P01_TaxGetMxData","\tUsage: skt.tmall.daemin.escrow.P01_TaxGetMxData <MxID> <CapDate>");

        System.exit(-1);
    }

	public void run( String MxID, String CapDate ) {
		batch_no = 2701;
    	batchID = "tmba_2701";
    	batchName = "���ݿ����� ���ϻ��� 1�ܰ� (1/2)";

		/* ��ø ���� ����  */
		if (isRunning(batch_no)) {
			String errMsg = "�̹� �������Դϴ�";
			log.error(errMsg);
			batchLogPrint(batch_no, null, null, "-1", "User Define Error", "N/A", "Y", errMsg, errMsg);
			return;
		}

		run_sub( MxID, CapDate );
	}

	@SuppressWarnings("unchecked")
	public void run_sub( String MxID, String CapDate ) {

        Connection connQ    = null;
        PreparedStatement pstmt = null;
        ResultSet rs        = null;

        Connection connU    = null;

        Properties rowPam   = null;
        Properties iniPam   = null;

        String sql          = "";
        String up_file      = "";

        int index       = 0;        // Total Rows
        int failCnt     = 0;        // Fail Rows

		Timestamp to_date = new Timestamp( System.currentTimeMillis() );
		Timestamp yes_date = new Timestamp( to_date.getTime() - 24*60*60*1000 );	// ������¥

		String yes_ext = yes_date.toString().substring(0, 4) + yes_date.toString().substring(5, 7) + yes_date.toString().substring(8, 10);

		if ( ! CapDate.equals(yes_ext) ) {
			CapDate = yes_ext;	// ������ ���� ������¥�� �� �޾ƿ��� ��찡 ����.
		}

        StdOut.log( "requestTR", "*** Begin - Service *** " );
        StdOut.log( "requestTR", "MxID    = " + MxID );
        StdOut.log( "requestTR", "CapDate = " + CapDate );

       // batchLogStart(batch_no,"��ġ ���� : ���ݿ����� �߱޹�ġ");

        try {
            //connQ = com.tgcorp.pg.batch.ConnectionManager.getConnection();
            connQ = DBHandler.getConnection(dbUrl,dbId,dbPwd);
            if (connQ == null) {
                log.error("Connection is NULL !!!");
                throw new Exception("Connection is NULL !!!");
            }
            StdOut.log("run_sub", "Connection to the DB sucessfully stablished. - connQ" );

            connU = DBHandler.getConnection(dbUrl,dbId,dbPwd);
            if (connU == null) {
                log.error("Connection is NULL !!!");
                throw new Exception("Connection is NULL !!!");
            }
            StdOut.log("run_sub", "Connection to the DB sucessfully stablished. - connU");

            connU.setAutoCommit(true);

            iniPam = new Properties();
            rowPam = new Properties();

            // Set from Argument
            iniPam.setProperty("MxID",       MxID );
            iniPam.setProperty("CapDate",    CapDate );     // ó�� ���� : ���� �ŷ� ���� ���� ���� ��ġ�� ó��

            //
            iniPam   = routeVan( connQ, iniPam );
            StdOut.log("requestTR", "Initial Params : "+iniPam.toString() );

            //
            sql     = getQuery( iniPam );
            StdOut.debug("requestTR", "SQL : " + sql );

            //
            pstmt    = connQ.prepareStatement(sql);
            rs = pstmt.executeQuery();

            // EDI Filename
            //to_date = new Timestamp(System.currentTimeMillis());
            String to_tmp  = to_date.toString();
            //up_file = "SKT_TAX_S_KSNET" + "." + to_tmp.substring(2,4)+to_tmp.substring(5,7)+to_tmp.substring(8,10);

            // SKT ���ݿ����� �������� ���� : ZPAYBOTS10020-001-YYYYMMDD_02.dat
            // SKT ���ݿ����� ������� ���� : ERO.NTSG.YYYYMMDD_02
            // ������ ������ SYSDATE�� ���ϸ� �����Ͽ� ����
            String senddate = to_tmp.substring(0,4)+to_tmp.substring(5,7)+to_tmp.substring(8,10);
            up_file = "ZPAYBOTS10020-001-" + senddate + "_02.dat";

            iniPam.setProperty("SendDate", senddate);

            // Initial Property
            iniPam.setProperty("UpFile",    up_file );	// ������ ���ϸ�

            //
            StdOut.log( "requestTR", "Initial Params : "+iniPam.toString() );
            StdOut.log( "requestTR","LOOP Start! ---------------------------" );

            int financial_cnt = 0;
            int cancel_cnt = 0;

            int date1 = 0;
            int idate = 0;

            while ( rs.next() ) {
                try {
                    // Initial Properties Copy.
                    rowPam = iniPam;

                    rowPam.setProperty("MxIssueNO",  rs.getString(1));       //
                    rowPam.setProperty("MxIssueDate",rs.getString(2));       //
                    rowPam.setProperty("TxCode",     rs.getString(3));       // ���α��� , 11-����, 22 -���
                    rowPam.setProperty("BizNO",      rs.getString(4));       // ����� ��ȣ
                    rowPam.setProperty("Currency",   rs.getString(5));       // ��ȭ���� '_'-��ȭ, '$'-�޷�
                    rowPam.setProperty("BizType",    rs.getString(6));       // �ŷ��� ����, 0-����, 1-�����
                    rowPam.setProperty("IDNO",       rs.getString(7));       // �ź�Ȯ�� , ��ġ�� �ƴѰ�� ī���ȣ ����
                    rowPam.setProperty("Amount",     rs.getString(8));       // �Ǹűݾ�
                    rowPam.setProperty("TAX",        rs.getString(9));       // ����
                    rowPam.setProperty("SVCFee",     rs.getString(10));      // �����
                    rowPam.setProperty("TAmount",    rs.getString(11));      // �Ѱŷ��ݾ�(=�Ǹűݾ� + ���� + �����)

                    rowPam.setProperty("IssueNO",   rs.getString(12) == null ? "" : rs.getString(12));      // ���� ��ȣ

                    date1 = Integer.parseInt(rs.getString(18));	// 5�� �� ��¥
                    idate = Integer.parseInt(rs.getString(13));

                    if ( idate < date1 ) {		// issuedate�� 5�� �� ��¥���� ���� ��¥�� ���
                    	rowPam.setProperty("IssueDate", rs.getString(19));      // ���� �Ͻ� : 1���� ��¥�� ����
                    } else {
                        rowPam.setProperty("IssueDate", rs.getString(13) == null ? "" : rs.getString(13));      // ���� �Ͻ�
                    }

                    rowPam.setProperty("MxKey",      rs.getString(14) == null ? "" : rs.getString(14) );      // ������ Key
                    rowPam.setProperty("SBizNO",      rs.getString(15) == null ? "1048137225" : rs.getString(15) );      // ���� ��������ȣ

                    rowPam.setProperty("PGName",      rs.getString(16) == null ? "" : rs.getString(16) );      // ��� ����� ����

                    rowPam.setProperty("H_Seq",     rs.getString(17) );      // h_csh_rcpt_iss_seq ��

                    // --
                    rowPam = validateTR( rowPam );

                    // --
                    StdOut.log( "requestTR", "["+ index +"]="+ rowPam.toString() );

                    String oIssueNO = "";
                    String oIssueDate = "";
                    if ( rowPam.getProperty("TxCode").equals("22") )
                    {
                    	rowPam = getCancelData( connU, rowPam );

                    	cancel_cnt++;
                    } else {
                    	rowPam.setProperty( "oIssueNO", "" );
                    	rowPam.setProperty( "oIssueDate", "" );

                    	financial_cnt++;
                    }

                    // --
                    if( save2PAS( connU, rowPam ) <= 0) {

                        rowPam.setProperty("OM_Stat",     OM_REQ_STAT_FAIL);
                        rowPam.setProperty("OM_Refs",     "T802");
                        rowPam.setProperty("OM_Mesg",     "Unable to save ...");

                        StdOut.error("requestTR", "Unable to Insert PAS(" + rowPam.getProperty("MxID")+", " + rowPam.getProperty("MxIssueNO")+")");
                        throw new PGServiceException("99999999", "Unable to save PAS" );
                    }

                    //
                    if( save2Mx( connU, rowPam ) != 1 ) {

                        rowPam.setProperty("OM_Stat",     OM_REQ_STAT_FAIL);
                        rowPam.setProperty("OM_Refs",     "T804");
                        rowPam.setProperty("OM_Mesg",     "Database - Insert fail!");

                        StdOut.error("requestTR", "Unable to save MALL(" + rowPam.getProperty("MxID")+"," + rowPam.getProperty("MxIssueNO")+")");
                        throw new PGServiceException("99999999", "Unable to save Mall" );
                    }

                    StdOut.log( "requestTR",
                         "Success. ("+rowPam.getProperty("MxID") +","+ rowPam.getProperty("MxIssueNO")+","+ rowPam.getProperty("MxIssueDate")+")" );



                } catch ( Exception e ) {
                    StdOut.error( "requestTR",
                         "Exception... ("+rowPam.getProperty("MxID") +","+ rowPam.getProperty("MxIssueNO")+","+ rowPam.getProperty("MxIssueDate")+")" );

                    failCnt ++;

                    rowPam.setProperty("OM_Stat",     OM_REQ_STAT_FAIL);
                    rowPam.setProperty("OM_Refs",     "T804");
                    rowPam.setProperty("OM_Mesg",     e.getMessage() );

                    updateError( connU, rowPam );
                } finally {
                    index ++;
                }
            }   // end while


            // SMS �� �ޱ����� ���� ���θ� Y �� ��
            //batchLogEnd(batch_no, "0", "Success", "N/A", "Y", "��ġ�Ϸ�", "[���ݿ��������ϻ���]�߱�" + financial_cnt + "��/���:" + cancel_cnt + "��" );

            StdOut.log( "requestTR","LOOP End!   ---------------------------");
            if( index <= 0 )
                StdOut.error("requestTR", "Select was failed. 0 rows selected." );

        } catch ( Exception e ) {
            StdOut.error("requestTR", e.getMessage());
        } finally {
            DBHandler.closeDBResource(rs, pstmt);
            DBHandler.closeDBResource(connU);
            DBHandler.closeDBResource(connQ);
        }

        StdOut.log( "requestTR", "*** End   - Service *** (Total Count="+index+", Fail Count="+failCnt+")" );

    }

    /**
     * <P/>
     * ���� �޼ҵ� ����.
     *
     * @param param
     * @return
     * @throws Exception
     */


    private String getQuery(Properties param) throws Exception {
        String sql = null;

//        if( param.getProperty("MxID").equals("tmall")) {
            sql =
                "SELECT "+
                    "csh_rcpt_iss_seq AS mxissueno, "+                      // 1. MxIssueNO = ���ݿ����� �߱� ��ȣ
                    "TO_CHAR(rqst_dy,'YYMMDDHH24MISS') AS mxissuedate, "+   // 2. MxIssueDate = ��û���� = ��û����
                    "cash_rcpt_aprv_clf AS txcode, "+                       // 3. ���ݿ����� ���α���  11-����, 22:���
                    "vlnr_rtlr_bsns_no  AS bizno, "+                        // 4. ����������� ��ȣ
                    "won_clf AS currency, "+                                // 5. ��ȭ���� _-��ȭ, $-�޷�
                    "trans_mem_clf AS biztype, "+                           // 6. �ŷ��� ���� 0-����, 1-�����
                    "idnt_cnf_no AS idno, "+                                // 7. �ź�Ȯ��
                    "sppl_prc AS amount, "+                                 // 8. ���ް���
                    "tax_amt AS tax, "+                                     // 9.����
                    "svc_amt AS svcfee, "+                                  // 10.�����
                    "tot_trans_amt AS tamount, "+                           // 11.�Ѱŷ� �ݾ�
                    "aprv_no AS issueno, "+                                 // 12.���� ��ȣ
                    "TO_CHAR(aprv_dt,'YYYYMMDD')  AS issuedate, "+            // 13.���� ����
                    "csh_rcpt_iss_seq AS o_mxissueno, " +                    // 14������ Key ��
                    "decodeparam(seller_idnty_no) AS seller_bizno, " +                    // 15.���� ��������ȣ
                    "pgcode AS pgname " +                    // 16. ���ݿ����� ����� ����(KSNET/SKT, null�̸� KSNET)
                    ", h_csh_rcpt_iss_seq AS h_seq " +                    // 17. h_seq : �� �ǿ� �߱޿�û, ��ҿ�û�� �Ѵ� ������ ����� ������
                "  FROM " + param.getProperty( "TabName" ) +" " +
                " WHERE cash_rcpt_req_stat = '"+OM_REQ_STAT_REQU+"' " +
                    " and rqst_dy <= to_date('"+ param.getProperty("CapDate")+"235959', 'YYMMDDHH24MISS') and (pgcode = 'SKT' or pgcode = 'skt') " +
//                    " and decodeparam(idnt_cnf_no) is not null and length(decodeparam(seller_idnty_no)) = 10 ";
            " and decodeparam(idnt_cnf_no) is not null and length(decodeparam(seller_idnty_no)) = 10 ";
//            "                      and ( CASH_RCPT_APRV_CLF = '11' or (CASH_RCPT_APRV_CLF = '22' and CSH_RCPT_ISS_SEQ in ('201008260822959','201008260823020' )) ) ";
           // "                      and ( (CASH_RCPT_APRV_CLF = '22' and CSH_RCPT_ISS_SEQ in ('201008260822959','201008260823020' )) ) ";
//        } else {
//            sql= "";
//            throw new PGServiceException("99990001", "routeVan : Not Define MxID!");
//        }

        return sql;
    }
/*
    private String getQuery(Properties param) throws Exception {
        String sql = null;

        String mxid = param.getProperty("MxID");

//        if( param.getProperty("MxID").equals("tmall")) {
            sql =
                "SELECT "+
                    "csh_rcpt_iss_seq AS mxissueno, "+                      // 1. MxIssueNO = ���ݿ����� �߱� ��ȣ
                    "TO_CHAR(rqst_dy,'YYMMDDHH24MISS') AS mxissuedate, "+   // 2. MxIssueDate = ��û���� = ��û����
                    "cash_rcpt_aprv_clf AS txcode, "+                       // 3. ���ݿ����� ���α���  11-����, 22:���
                    "vlnr_rtlr_bsns_no  AS bizno, "+                        // 4. ����������� ��ȣ
                    "won_clf AS currency, "+                                // 5. ��ȭ���� _-��ȭ, $-�޷�
                    "trans_mem_clf AS biztype, "+                           // 6. �ŷ��� ���� 0-����, 1-�����
                    "idnt_cnf_no AS idno, "+                                // 7. �ź�Ȯ��
                    "sppl_prc AS amount, "+                                 // 8. ���ް���
                    "tax_amt AS tax, "+                                     // 9.����
                    "svc_amt AS svcfee, "+                                  // 10.�����
                    "tot_trans_amt AS tamount, "+                           // 11.�Ѱŷ� �ݾ�
                    "aprv_no AS issueno, "+                                 // 12.���� ��ȣ
                    "TO_CHAR(nvl(aprv_dt,sysdate),'YYYYMMDD')  AS issuedate, "+            // 13.���� ����
                    "csh_rcpt_iss_seq AS o_mxissueno, " +                    // 14������ Key ��
                    "decodeparam(seller_idnty_no) AS seller_bizno, " +                    // 15.���� ��������ȣ
                    "pgcode AS pgname " +                    // 16. ���ݿ����� ����� ����(KSNET/SKT, null�̸� KSNET)
                    ", h_csh_rcpt_iss_seq AS h_seq " +                    // 17. h_seq : �� �ǿ� �߱޿�û, ��ҿ�û�� �Ѵ� ������ ����� ������
                    ", TO_CHAR(sysdate - 5,'YYYYMMDD')  AS date1 " +                    // 18. sysdate-5
                    ", TO_CHAR(sysdate - 1,'YYYYMMDD')  AS date2 " +                    // 19. sysdate-1
                "  FROM " + param.getProperty( "TabName" ) +" " +
                " WHERE cash_rcpt_req_stat = '"+OM_REQ_STAT_REQU+"' " +
                    " and rqst_dy <= to_date('"+ param.getProperty("CapDate")+"235959', 'YYMMDDHH24MISS') and (pgcode = 'SKT' or pgcode = 'skt') " +
//                    " and decodeparam(idnt_cnf_no) is not null and length(decodeparam(seller_idnty_no)) = 10 ";
            " and decodeparam(idnt_cnf_no) is not null and (length(decodeparam(seller_idnty_no)) = 10 or seller_idnty_no is null) " ;
           // "                      and  (CASH_RCPT_APRV_CLF = '22' and CSH_RCPT_ISS_SEQ in ('201008290032793','201008290032836' ))  ";
           // "                      and CASH_RCPT_APRV_CLF = '11'  ";
            //"                      and CASH_RCPT_APRV_CLF = '22' and  rqst_dy >= to_date('20100828000000', 'YYMMDDHH24MISS') ";
//        } else {
//            sql= "";
//            throw new PGServiceException("99990001", "routeVan : Not Define MxID!");
//        }

            if ( mxid.equals("tmall") ) {
            	sql = sql + "                      and ( (CASH_RCPT_APRV_CLF = '11') or (CASH_RCPT_APRV_CLF = '22' and  rqst_dy >= to_date('20100828000000', 'YYMMDDHH24MISS')) ) ";
            }

        return sql;
    }
*/

/*
    private String getQuery(Properties param) throws Exception {
        String sql = null;

//        if( param.getProperty("MxID").equals("tmall")) {
        sql =
            "SELECT "+
                "csh_rcpt_iss_seq AS mxissueno, "+                      // 1. MxIssueNO = ���ݿ����� �߱� ��ȣ
                "TO_CHAR(rqst_dy,'YYMMDDHH24MISS') AS mxissuedate, "+   // 2. MxIssueDate = ��û���� = ��û����
                "cash_rcpt_aprv_clf AS txcode, "+                       // 3. ���ݿ����� ���α���  11-����, 22:���
                "vlnr_rtlr_bsns_no  AS bizno, "+                        // 4. ����������� ��ȣ
                "won_clf AS currency, "+                                // 5. ��ȭ���� _-��ȭ, $-�޷�
                "trans_mem_clf AS biztype, "+                           // 6. �ŷ��� ���� 0-����, 1-�����
                "idnt_cnf_no AS idno, "+                                // 7. �ź�Ȯ��
                "sppl_prc AS amount, "+                                 // 8. ���ް���
                "tax_amt AS tax, "+                                     // 9.����
                "svc_amt AS svcfee, "+                                  // 10.�����
                "tot_trans_amt AS tamount, "+                           // 11.�Ѱŷ� �ݾ�
                "aprv_no AS issueno, "+                                 // 12.���� ��ȣ
                "TO_CHAR(nvl(aprv_dt,sysdate),'YYYYMMDD')  AS issuedate, "+            // 13.���� ����
                "csh_rcpt_iss_seq AS o_mxissueno, " +                    // 14������ Key ��
                "decodeparam(seller_idnty_no) AS seller_bizno, " +                    // 15.���� ��������ȣ
                "pgcode AS pgname " +                    // 16. ���ݿ����� ����� ����(KSNET/SKT, null�̸� KSNET)
                ", h_csh_rcpt_iss_seq AS h_seq " +                    // 17. h_seq : �� �ǿ� �߱޿�û, ��ҿ�û�� �Ѵ� ������ ����� ������
                ", TO_CHAR(sysdate - 5,'YYYYMMDD')  AS date1 " +                    // 18. sysdate-5
                ", TO_CHAR(sysdate - 1,'YYYYMMDD')  AS date2 " +                    // 19. sysdate-1
            "  FROM " + param.getProperty( "TabName" ) +" " +
            " WHERE cash_rcpt_req_stat = '"+OM_REQ_STAT_REQU+"' " +
                " and rqst_dy <= to_date('"+ param.getProperty("CapDate")+"235959', 'YYMMDDHH24MISS') and (pgcode = 'SKT' or pgcode = 'skt') " +
//                " and decodeparam(idnt_cnf_no) is not null and length(decodeparam(seller_idnty_no)) = 10 ";
        " and decodeparam(idnt_cnf_no) is not null and (length(decodeparam(seller_idnty_no)) = 10 or seller_idnty_no is null) " +
       // "                      and  (CASH_RCPT_APRV_CLF = '22' and CSH_RCPT_ISS_SEQ in ('201008290032793','201008290032836' ))  ";
       // "                      and CASH_RCPT_APRV_CLF = '11'  ";
        "                      and CASH_RCPT_APRV_CLF = '22' and csh_rcpt_iss_seq in ( " +
"        select a.CSH_RCPT_ISS_SEQ   " +
"        from dev_ord.taxsave_temp e, tr_ord b, tr_csh_rcpt_rqst a " +
"        where e.buy_mem_no = b.buy_mem_no " +
"        and e.cnt between 2 and 4 " +
"        and b.ord_no = a.ord_no " +
"        and CASH_RCPT_APRV_CLF = '22' " +
"        and CASH_RCPT_REQ_STAT in ('02') " +
"        and a.rqst_dy <= to_date('20100827235959', 'YYMMDDHH24MISS') " +
"        and (pgcode = 'SKT' or pgcode = 'skt')  " +
"        and decodeparam(idnt_cnf_no) is not null " +
"        and (length(decodeparam(a.seller_idnty_no)) = 10 or a.seller_idnty_no is null) )";
//        } else {
//            sql= "";
//            throw new PGServiceException("99990001", "routeVan : Not Define MxID!");
//        }

        return sql;
    }

*/
    /**
     *
     *
     * <P/>
     * ���� �޼ҵ� ����.
     *
     * @param conn
     * @param param
     * @return
     * @throws Exception
     */
    private Properties routeVan(Connection conn, Properties param) throws Exception {


        /*
         *  �� �κ��� MM, OM �� ������ 11���� DBMS�� ����ϰ� ������ DB ��Ű���� ����Ѵٴ� �����Ͽ�
         *  ���̺� ���� �ٸ��� �����ϱ� ���ؼ� ������ �κ��̴�.
         *  �� �κа� ���� �� �κ��� ReceiveExe Ŭ������ routeVan �޼ҵ� �̴�.
         *
         */
        if( param.getProperty("MxID").equals("tmall")) {
            param.setProperty("MxName",     "SKT");                 //
            param.setProperty("VanCode",    "0006");                // ���ݿ������� ����û�� �����ϱ� ���� VAN Code
            //param.setProperty("VanName",    "KSNET");               // ���ݿ������� ����û�� �����ϱ� ���� VAN Name
            param.setProperty("VanName",    "SKT");               // ���ݿ������� ����û�� �����ϱ� ���� VAN Name
            param.setProperty("MxBizNO",    "1048137225");          // ���ݿ����� ���� ����� ��ȣ(CP ����� ��ȣ)
            param.setProperty("TermID",     "DPT0A00987");          // VAN�� �ܸ��� ID

            param.setProperty("TabName",    "tr_csh_rcpt_rqst");    // ���ݿ����� ��û �� ��� ������Ʈ�� ���� CP�� ���̺�
            // param.setProperty("TabName", "INSPADMIN.tr_csh_rcpt_rqst_IMS");
        } else {
            param.setProperty("MxName",     "SKT");                 //
            param.setProperty("VanCode",    "0006");                // ���ݿ������� ����û�� �����ϱ� ���� VAN Code
            //param.setProperty("VanName",    "KSNET");               // ���ݿ������� ����û�� �����ϱ� ���� VAN Name
            param.setProperty("VanName",    "SKT");               // ���ݿ������� ����û�� �����ϱ� ���� VAN Name
            param.setProperty("MxBizNO",    "1048137225");          // ���ݿ����� ���� ����� ��ȣ(CP ����� ��ȣ)
            param.setProperty("TermID",     "DPT0A00987");          // VAN�� �ܸ��� ID

            // Add 2010.02.xx tmall_book
            param.setProperty("TabName",    "merchant.TBL_CSH_RCPT_RQST");	// ������ ���ݿ����� ���̺�
        }

        /*
        Statement   stmt = null;
        ResultSet   rs = null;
        String      sql = "SELECT MxName, VanCode, MxBizNO, TermID " +
                          "  FROM TaxTRSite " +
                          " WHERE mxid = '" + param.getProperty("MxID")+ "'" ;

        try {
            stmt    = conn.createStatement();
            rs      = stmt.executeQuery( sql );

            while(rs.next()) {
                param.setProperty("MxName",     rs.getString(1));
                param.setProperty("VanCode",    rs.getString(2));
                param.setProperty("MxBizNO",    rs.getString(3));
                param.setProperty("TermID",     rs.getString(4));
                param.setProperty("TabName",    rs.getString(5));
            }
        } catch ( Exception  e) {
            throw e;
        } finally {
            DBUtil.cleanup(stmt, rs);
        }
        */

        StdOut.debug( "routeVan", "Properties:" + param );

        return param;
    }

    /**
     *
     *
     * <P/>
     * ���� �޼ҵ� ����.
     *
     * @param param
     * @return
     * @throws Exception
     */
    private Properties validateTR( Properties param ) throws Exception  {

        StdOut.debug("validateTR", "Properties=" + param.toString() );

        if( param.getProperty( "TxCode" ).equals("11")) {
            param.setProperty("txCode",     PGCode.SC_TAX_FINANCIAL);
            param.setProperty("txStatus",   PGCode.ST_TAX_REQING);
        } else if( param.getProperty( "TxCode" ).equals("22")) {
            param.setProperty("txCode",     PGCode.SC_TAX_REVERSAL);
            param.setProperty("txStatus",   PGCode.ST_TAX_REVING);
        } else {
            throw new PGServiceException( "99999999", "Invalid arguement(TxCode).");
            /*
            param.setProperty("OM_Stat",     OM_REQ_STAT_FAIL);
            param.setProperty("OM_Refs",     "T803");
            param.setProperty("OM_Mesg",     "���α��а� ����");
            */
        }

        return param;
    }

    /**
     *
     *
     * <P/>
     * ���� �޼ҵ� ����.
     *
     * @param conn
     * @param param
     * @return
     * @throws Exception
     */
    private int save2Mx(Connection conn, Properties param ) throws Exception  {
        PreparedStatement pstmt = null;
        int     rows = 0;

        StdOut.debug("save2Mx", "Properties = " + param.toString() );
        try {
            pstmt = conn.prepareStatement(
                    "UPDATE "+ param.getProperty( "TabName" ) +" " +
                    "   SET cash_rcpt_req_stat = '"+OM_REQ_STAT_RECE+"' " +
                    " WHERE csh_rcpt_iss_seq = ?   "
            );

            pstmt.setLong(1, Long.parseLong( param.getProperty("MxIssueNO") ) );

            rows = pstmt.executeUpdate();

            if(rows != 1 ) {
                StdOut.error("save2Mx", "Unable to update ...  ["+param.getProperty("MxID")
                 +"] ["+param.getProperty("MxIssueNO")
                 +"] ["+param.getProperty("MxIssueDate")+"]"  );

                throw new PGServiceException("99999999", "Unable to update ..." );
            }

        } catch ( Exception e) {
            StdOut.error("save2Mx", e.getMessage() );
            rows = -1;
        } finally {
            DBHandler.closeDBResource(pstmt);
        }

        return rows;
    }

    /**
     *
     *
     * <P/>
     * ���� �޼ҵ� ����.
     *
     * @param conn
     * @param param
     * @return
     */
    private int save2PAS(Connection conn, Properties param )  {

        PreparedStatement pstmt = null;
        int     rows = 0;
        int     res = 1;

        StdOut.debug( "save2PAS", "Properties:" + param );

        try {
            pstmt = conn.prepareStatement(
                " INSERT INTO taxtr " +
                        " ( txno, mxid, mxissueno, mxissuedate, termid, reqdate, fitype, bizno, currency, biztype, " + 		// 1 ~ 10
                        " idno, amount, tax, svcfee, tamount, senddate, txcode, txstatus, sendfile, issueno, " +		// 11 ~ 20
                        " issuedate, seller_bizno, oissueno, oissuedate, pgname ) " +	// 21 ~ 25
                " VALUES ( taxtr_txno_seq.nextval, ?, ?, ?, ?, ?, ?, ?, ?, ?,           ?, ?, ?, ?, ?, ?, ?, ?, ?, ?,           ?, encodeparam(?), ?, ?, ? ) "
            );

            pstmt.setString(1,  param.getProperty("MxID"));

            pstmt.setString(2,  param.getProperty("MxIssueNO"));
            pstmt.setString(3,  param.getProperty("MxIssueDate"));
            pstmt.setString(4,  param.getProperty("TermID"));
            pstmt.setString(5,  param.getProperty("CapDate") );
            pstmt.setString(6,  param.getProperty("TxCode"));
            pstmt.setString(7,  param.getProperty("BizNO"));
            pstmt.setString(8,  param.getProperty("Currency"));
            pstmt.setString(9,  param.getProperty("BizType"));
            pstmt.setString(10, param.getProperty("IDNO"));

            pstmt.setLong(11, Long.parseLong(param.getProperty("Amount")));
            pstmt.setLong(12, Long.parseLong(param.getProperty("TAX")));
            pstmt.setLong(13, Long.parseLong(param.getProperty("SVCFee")));
            pstmt.setLong(14, Long.parseLong(param.getProperty("TAmount")));
            pstmt.setString(15, param.getProperty("SendDate") );
            pstmt.setString(16, param.getProperty("txCode") );
            pstmt.setString(17, param.getProperty("txStatus"));
            pstmt.setString(18, param.getProperty("UpFile"));
            pstmt.setString(19, param.getProperty("IssueNO"));
            pstmt.setString(20, param.getProperty("IssueDate"));

            pstmt.setString(21, param.getProperty("SBizNO"));
            pstmt.setString(22, param.getProperty("oIssueNO"));
            pstmt.setString(23, param.getProperty("oIssueDate"));
            pstmt.setString(24, param.getProperty("PGName"));

            rows = pstmt.executeUpdate();

            if(rows != 1) {
                StdOut.error("save2PAS", "Unable to save ... - taxtr ["+param.getProperty("MxID")
                 +"] ["+param.getProperty("MxIssueNO")
                 +"] ["+param.getProperty("MxIssueDate")+"]"  );

                throw new PGServiceException("99999999", "Insert Fail. To PAS. " );
            }
        } catch ( Exception e) {
            StdOut.error( "save2PAS", e.getMessage() );
            res = -1;
        } finally {
            DBHandler.closeDBResource(pstmt);
        }

        return res;
    }

    /**
     *
     *
     * <P/>
     * ���� �޼ҵ� ����.
     *
     * @param conn
     * @param param
     */
    private void updateError(Connection conn, Properties param) {

        PreparedStatement pstmt = null;
        int rows = 0;

        StdOut.error( "updateError", param.toString() );

        try {
            pstmt = conn.prepareStatement(
                "UPDATE " + param.getProperty( "TabName" ) +" "+
                "   SET "+
                        "cash_rcpt_req_stat = ?, "+
                        "refs_cd = ?, "+
                        "trt_msg = ? " +
                " WHERE csh_rcpt_iss_seq = ? "
            );
            pstmt.setString(1, OM_REQ_STAT_FAIL );
            pstmt.setString(2, param.getProperty("OM_Refs") );
            pstmt.setString(3, param.getProperty("OM_Mesg") );
            pstmt.setString(4, param.getProperty("MxIssueNO") );

            rows = pstmt.executeUpdate();

            if(rows != 1) {
                StdOut.error("updateError", "[MxID="+param.getProperty("MxID")
                 +"] [MxIssueNO="+param.getProperty("MxIssueNO")
                 +"] [MxIssueDate="+param.getProperty("MxIssueDate")+"] "
                 +"] [OM_Stat="+param.getProperty("OM_Stat")+"] "
                 +"] [OM_Refs="+param.getProperty("OM_Refs")+"] "
                 +"] [OM_Mesg="+param.getProperty("OM_Mesg") );

                throw new PGServiceException( "99999999","Update Fail.");
            }
        } catch( Exception e ) {
            e.printStackTrace();
        } finally {
            DBHandler.closeDBResource(pstmt);
        }
        return;
    }


	/**
	*
	*
	* <P/>
	* ���� �޼ҵ� ����.
	*
	* @param param
	* @return
	* @throws Exception
	*/
    /*
	   private Properties getCancelData( Connection conn, Properties param ) throws Exception  {

	       PreparedStatement pstmt = null;
	       ResultSet rs = null;
           String oIssueNO = "";
           String oIssueDate = "";

	       StdOut.log("getCancelData", "Properties=" + param.toString() );

	   try {
		   pstmt = conn.prepareStatement(
				   " SELECT aprv_no, TO_CHAR(aprv_dt, 'yyyymmdd') FROM " + param.getProperty( "TabName" ) +
				   " WHERE h_csh_rcpt_iss_seq = ? " +
				   " AND cash_rcpt_aprv_clf = ? "
		   );

		   pstmt.setString( 1, param.getProperty( "H_Seq" ) );
		   pstmt.setString( 2, "11" );

		   rs = pstmt.executeQuery();

		   if ( rs.next() )	{
			   oIssueNO = rs.getString(1);
			   oIssueDate = rs.getString(2);

			   param.setProperty( "oIssueNO", oIssueNO );
			   param.setProperty( "oIssueDate", oIssueDate.substring(2) );
		   } else {
			   param.setProperty( "oIssueNO", "" );
			   param.setProperty( "oIssueDate", "" );
		   }

	   } catch ( Exception e ) {
		   StdOut.log( "getCancelData", e.getMessage() );
	   } finally {
		   DBHandler.closeDBResource(rs);
           DBHandler.closeDBResource(pstmt);
	   }

       return param;
   }
*/

	   private Properties getCancelData( Connection conn, Properties param ) throws Exception  {

	       PreparedStatement pstmt = null;
	       ResultSet rs = null;
           String oIssueNO = "";
           String oIssueDate = "";

	       StdOut.log("getCancelData", "Properties=" + param.toString() );

	   try {
		   pstmt = conn.prepareStatement(
				   " SELECT aprv_no, TO_CHAR(NVL(aprv_dt, sysdate - 1) , 'yyyymmdd') FROM " + param.getProperty( "TabName" ) +
				   " WHERE h_csh_rcpt_iss_seq = ? " +
				   " AND cash_rcpt_aprv_clf = ? "
		   );

		   pstmt.setString( 1, param.getProperty( "H_Seq" ) );
		   pstmt.setString( 2, "11" );

		   rs = pstmt.executeQuery();

		   if ( rs.next() )	{
			   oIssueNO = rs.getString(1);
			   oIssueDate = rs.getString(2);

			   param.setProperty( "oIssueNO", oIssueNO );
			   param.setProperty( "oIssueDate", oIssueDate.substring(2) );
		   } else {
			   param.setProperty( "oIssueNO", "" );
			   param.setProperty( "oIssueDate", "" );
		   }

	   } catch ( Exception e ) {
		   StdOut.log( "getCancelData", e.getMessage() );
	   } finally {
		   DBHandler.closeDBResource(rs);
           DBHandler.closeDBResource(pstmt);
	   }

       return param;
   }

}
