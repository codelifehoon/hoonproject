package skt.tmall.daemon.escrow;

import java.io.IOException;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.util.Properties;

import skt.tmall.daemon.common.util.DBHandler;

import com.ibatis.common.resources.Resources;

public class E52_MailOpenTargetUpdate{

	private Properties props = null;
	private static final String PROP_FILE_PATH = "";
	private static final String SQLMAP_PATH = "";
	private String dbUrl, dbId, dbPasswd,dbDriver;

	public E52_MailOpenTargetUpdate() {


//		props = new Properties();
//		try {
//			props.load(Resources.getResourceAsStream(PROP_FILE_PATH));
//
//			dbDriver = props.getProperty("tmall.sqlMap.driver");
//			dbUrl = props.getProperty("tmall.sqlMap.url");
//			dbId = props.getProperty("tmall.sqlMap.username");
//			dbPasswd = props.getProperty("tmall.sqlMap.password");
//
//		} catch (IOException e) {
//			e.printStackTrace();
//		}

		DBHandler.initSqlMap(SQLMAP_PATH);
	}

	public void update() {
		//������� amailadmin����
		Connection con = null;
		PreparedStatement pstmt = null;

		DBHandler.initDriver(dbDriver);
		DBHandler.initSqlMap(SQLMAP_PATH);
		try {
			con = DBHandler.getConnection(dbUrl,dbId,dbPasswd);
			pstmt = con.prepareStatement("");
			pstmt.executeUpdate();

		} catch (Exception e) {
			e.printStackTrace();
		}


	}

	public static void main(String arg[]){
		E52_MailOpenTargetUpdate obj = new E52_MailOpenTargetUpdate();
		obj.update();

	}
}
