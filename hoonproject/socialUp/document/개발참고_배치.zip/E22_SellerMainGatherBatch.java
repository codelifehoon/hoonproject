package skt.tmall.daemon.escrow;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

import skt.tmall.daemon.common.util.DBHandler;

/**
 * Email SMS ���� ��ġ
 * 	�ֱ� : �� 1ȸ
 *  : ���˸��� �߼�
 *  : ����SMS �߼�
 * @author ZZ07237
 *
 */
public class E22_SellerMainGatherBatch extends EscrowBaseDaemon {

	/**
	 * @param args
	 * @throws SQLException 
	 */
	public static void main(String[] args) throws SQLException {
	    E22_SellerMainGatherBatch mainBath = new E22_SellerMainGatherBatch();
	    mainBath.run();
	}

	public void run() throws SQLException {
		batch_no = 2522;
		batchID = "tmba_bo_12A";
		this.batchName = "Seller Main��ġ";
		
//		/* ��ø ���� ����  */
//		if (isRunning(batch_no)) {
//			String errMsg = "�̹� �������Դϴ�";
//			log.error(errMsg);
//			batchLogPrint(batch_no, null, null, "-1", "User Define Error", "N/A", "Y", errMsg, errMsg);
//			return;
//		}
		
		run_email();
		
	}

	public void run_email() throws SQLException {
		

		//batchLogStart(batch_no,"Email ���� ��ġ");

		log.debug("===== "+batchName+" START =====");

		Connection conn = null;
		PreparedStatement pstmt = null;
		
		
		StringBuffer buff = new StringBuffer();
		buff.append("	BEGIN 									         \n");
		buff.append("   	SP_PD_SELLER_SELL_SUMMARY;					 \n");
		buff.append("	END;									         \n");

		try {
			conn = DBHandler.getConnection(dbUrl,dbId,dbPwd);
			if (conn == null) {
				log.error("Connection is NULL !!!");
				throw new Exception("Connection is NULL !!!");
			}
			
			pstmt = conn.prepareStatement(buff.toString());
			pstmt.execute();
			//batchLogEnd(batch_no, "0", "Success", "N/A", "N", "���˸��� ������ ����", null);
			
		} catch (Exception e) {
			//batchLogEnd(batch_no, "-1", "ERROR", "N/A", "Y", "���˸��� ������  ����", "���˸��� ������  ����");
			log.error(e.toString());
		} finally {
		    //conn.commit();
		    pstmt.close();
            conn.close();
			log.debug("===== "+batchName+" END =====");
		}
	}

	
} // end of class
