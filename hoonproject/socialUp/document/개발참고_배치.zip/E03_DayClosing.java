package skt.tmall.daemon.escrow;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.util.Date;

import skt.tmall.common.util.EDate;
import skt.tmall.daemon.common.util.DBHandler;

/**
 * �����ϸ��� ��ġ
 * @author ZZ07237
 *
 */
public class E03_DayClosing extends EscrowBaseDaemon {

	/**
	 * @param args
	 */
	public static void main(String[] args) {
		E03_DayClosing dm = new E03_DayClosing();
		String yesterday = "";
		if (args != null && args.length > 0) {
			yesterday = args[0];
		}
		dm.run(yesterday);
	}

	public void run(String yesterday) {
		batch_no = 2503;
		batchID = "tmba_bo_03";
		batchName = "���� �ϸ��� ��ġ";
		
		/* ��ø ���� ����  */
		if (isRunning(batch_no)) {
			String errMsg = "�̹� �������Դϴ�:" + yesterday;
			log.error(errMsg);
			batchLogPrint(batch_no, null, null, "-1", "User Define Error", "N/A", "Y", errMsg, errMsg);
			return;
		}
		
		run_sub(yesterday);
	}

	public void run_sub(String yesterday) {
		log.debug("===== "+batchName+" START =====");

		if (yesterday == null || yesterday.length() != 8) {
			Date dt = EDate.offset(new Date(), 0, 0, -1);
			yesterday = this.dateFormat(dt, "yyyyMMdd");
		}
		String stlDy = "(��������:"+yesterday+")";
		log.debug(stlDy);
		
		batchLogStart(batch_no,stlDy);

		Connection conn = null;
		PreparedStatement pstmt = null;
		ResultSet rs = null;
		
		StringBuffer buff = new StringBuffer();
		buff.append("	BEGIN 							\n");
		buff.append("		/* ���� �ϸ��� ��ġ (/05.tMallETCProject/src/skt/tmall/daemon/escrow/DayClosing.java) */	 \n");
		buff.append("   	SP_SE_BATCH_SCHEDULE(TO_DATE(?||'000000','YYYYMMDDHH24MISS'));	\n");
		buff.append("	END;							\n");

		try {
			conn = DBHandler.getConnection(dbUrl,dbId,dbPwd);
			if (conn == null) {
				log.error("Connection is NULL !!!");
				throw new Exception("Connection is NULL !!!");
			}
			
			pstmt = conn.prepareStatement(buff.toString());
			pstmt.setString(1, yesterday);
			pstmt.execute();
			
			DBHandler.closeDBResource(rs,pstmt);
			DBHandler.closeDBResource(conn);
			
			batchLogEnd(batch_no, "0", "Success", "N/A", "N", "��������:"+yesterday, null);
		} catch (Exception e) {
			String err = "��������:"+yesterday;
			err += " Err:"+e.toString();
			batchLogEnd(batch_no, "-1", "Error", "N/A", "Y", err, "[�ϸ�������] ��������:"+yesterday);
			log.error(err);
		} finally {
			try {
				DBHandler.closeDBResource(rs,pstmt);
				DBHandler.closeDBResource(conn);
			} catch (Exception e) {}

			log.debug("===== "+batchName+" END =====");
		}
	}
} // end of class
