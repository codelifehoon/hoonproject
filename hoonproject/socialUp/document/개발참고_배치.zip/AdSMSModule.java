package skt.tmall.daemon.escrow;

import java.io.FileWriter;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.Date;
import java.util.HashMap;
import java.util.Map;
import java.util.List;

import skt.tmall.bdt.transfer.mail.EmailRequestBO;
import skt.tmall.bdt.transfer.mail.EmailUserInfo;
import skt.tmall.bdt.transfer.sms.SmsRequestBO;
import skt.tmall.common.TmallException;
import skt.tmall.common.util.EDate;
import skt.tmall.daemon.common.util.DBHandler;

import skt.tmall.process.share.remittance.remittancesummary.service.EmailService;
import skt.tmall.process.share.remittance.remittancesummary.service.EmailServiceImpl;
import com.skt.omp.common.util.DateTime;

public class AdSMSModule extends EscrowBaseDaemon {


    private static SmsRequestBO smsRequest = null;
    private static List<SmsRequestBO> smsReqeuestList = null;
    private EmailService service = null;

    private boolean debugMode = false;

    //�޼����� 80byte�Դϴ�.

    private long defaultSellerNo = 10000005;
    private volatile int send_count = 0;
    private static final int update_limit = 50;
    private long totalcount = 0;

    //private final StringBuilder selectSQL = null;

    public AdSMSModule(String today) throws Exception {
        batchName = "���ñ���/������ ���� SMS �߼�";
        batch_no = 2522;
        String[] userList = null;

		/* ��ø ���� ����  */
		if (isRunning(batch_no)) {
			String errMsg = "�̹� �������Դϴ�";
			log.error(errMsg);
			batchLogPrint(batch_no, null, null, "-1", "User Define Error", "N/A", "Y", errMsg, errMsg);
			return;
		}


        try {
        	userList = getSendSmsList(today);

    		log.debug("===== "+batchName+" START =====");
    		batchLogStart(batch_no,batchName);

            if(userList != null){
	            super.initSqlMap();
	            smsReqeuestList = new ArrayList();
	            service = new EmailServiceImpl();

	            for(int i = 0; i < userList.length; i++) {
	                String[] userInfo = userList[i].split(",");

	                sendEmailSummery(userInfo);
	                sendSMSService();

	                Thread.sleep(100);
	            }
            }else{
System.out.println("userList is null!!!!!!!!!!!!!!!!!!!!!!!!!");
            }

            batchLogEnd(batch_no, "0", "Success", "N/A", "N", "�������:"+today, null);

        } catch(Exception e) {
            log.error(batchName + " FATAL : SqlMapLoader.init()");
            throw new TmallException(e.toString());
        } finally {
            smsRequest = null;
            service = null;
            log.error("SMS�� ���� �Ǹ��� �� : " + send_count);
        }

    }

    private void sendSMSService() throws Exception  {

        long errCnt = service.sendSMSChecked(smsReqeuestList); //���⸸ �ּ� ������ ���� �߼� ����.

        if(errCnt > 0) {
            log.error("���� ���� sms �߼� ����  - ������ ���� ");
            throw new Exception("���� ���� sms �߼� ����  - ������ ���� ");

        }

        smsReqeuestList = new ArrayList();

    }


    /**
     * @param args
     * @throws Exception
     */
    public static void main( String[] args ) throws Exception {

		String today = "";
		if (args != null && args.length > 0) {
			today = args[0];
		}

    	AdSMSModule selelrEscrow = new AdSMSModule(today);
    }



    /**
     *
     * <P/>
     * email �߼� ���̺��� �ش� �Ǹ��ڸ� insert �Ѵ�.
     * ȸ�����°�(MB_MEM.mem_stat_cd = 01) �����϶��� �߼� ó�� �Ѵ�.
     * @param conn
     * @param rs
     * @return
     * @throws Exception
     */
    private boolean sendEmailSummery(String[] smsLog) throws Exception {

        String[] content = smsLog;
        String phoneNum = null;
        String smsSellerSubject = null;

        boolean commitTime = false;

        try {

        if(content[0] != null && !"".equals(content[1])) {

            smsRequest = new SmsRequestBO();
            smsRequest.setTemplateId(0);                       // ���ø� ���̵� ����. �Ϲ� �߼��� 0�� ����.
            smsRequest.setType("7");                           // SMS ����. 7: ������, 8: ������, 9: MO
            smsRequest.setSmsType("7");                        // Callback ����. 7: 1way, 8: 2way :callback URL
            smsRequest.setCampaign("�����ı�");                 // ķ���� ��

            phoneNum = content[0].trim().replaceAll("-", "");
            smsSellerSubject = content[1];

            //log.error(phoneNum);
            //log.error(smsSellerSubject);

            smsRequest.setCellPhoneNum(phoneNum);           // �޴� ��� �ڵ��� ��ȣ
            smsRequest.setMessage(smsSellerSubject);        // ���� �޼���
            //smsRequest.setCallback("15990110,http://dev-m.11st.co.kr/176_wap.jsp");             // ������ ����� �ڵ��� ��ȣ
            smsRequest.setCallback("15990110");             // ������ ����� �ڵ��� ��ȣ
            if(phoneNum.matches("\\d+")) {
                send_count++;
                smsReqeuestList.add(smsRequest);
            } else {
                log.error("�Ǹ��� ���� Ȯ�� : " + content[0]);
            }
        }

        } catch(Exception ex) {
            log.error("�Ǹ��� ���� Ȯ�� : " + content[0]);
        }

        if(send_count == update_limit) {
            commitTime = true;
        }
        return commitTime;
    }








	public String[] getSendSmsList(String today) {
		log.debug("===== "+batchName+" START =====");

		String[] userList = null;
		String result = "";
		String smsTxt = "";
		long amtFee = 0;

today = null;

		if (today == null || today.length() != 8) {
			Date dt = EDate.offset(new Date(), 0, 0, -1);
			today = this.dateFormat(dt, "yyyyMMdd");
		}
System.out.println("today =================> " + today);
		System.out.println("������� : " + today);

		Connection conn = null;
		PreparedStatement pstmt = null;
		ResultSet rs = null;

		StringBuffer buff = new StringBuffer();
		buff.append(" SELECT '���� '||to_char(to_date(A.STL_DY,'yyyymmdd'),'MM/DD')||'('||SUBSTR(TO_CHAR(TO_DATE(A.STL_DY,'YYYYMMDD'),'DAY'),1,1)||') '||                                      \n");
		buff.append("         trim(to_char(A.AMT_VFEE,'9999990D99'))||'��(���ִ��'||CASE WHEN A.AMT_FEE-B.PRE_AMT_FEE > 0 THEN '+' END||trim(to_char(ROUND(((A.AMT_FEE-B.PRE_AMT_FEE) / B.PRE_AMT_FEE) * 100 ,2),'9999990D99'))||'%) �������� '|| \n");
		buff.append("         C.MON_AMT_FEE||'����� '||                                                                                                                                     \n");
		buff.append("         trim(to_char(A.AMT_DISP_FEE,'9999990D99'))||'��/���� '||trim(to_char(A.AMT_REG_FEE,'9999990D99'))||'��' SND_TXT,                                                  \n");
		buff.append("         nvl(AMT_VFEE,0) AMT_VFEE                                                                                                                           \n");
		buff.append(" FROM (                                                                                                                                                                   \n");
		buff.append("         SELECT ? STL_DY,                                                                                                                                        \n");
		buff.append("                ROUND(SUM(NVL(PRD_DISP_FEE,0)+NVL(PRD_REG_FEE,0)+NVL(ETC_FEE,0)) / 1.1 / 100000000,2) AMT_VFEE,                                                           \n");
		buff.append("                ROUND(SUM(NVL(PRD_DISP_FEE,0)) / 1.1 / 100000000,2) AMT_DISP_FEE,                                                                                         \n");
		buff.append("                ROUND(SUM(NVL(PRD_REG_FEE,0)) / 1.1 / 100000000,2) AMT_REG_FEE,                                                                                           \n");
		buff.append("                SUM(NVL(PRD_DISP_FEE,0)+NVL(PRD_REG_FEE,0)+NVL(ETC_FEE,0)) AMT_FEE                                                                                        \n");
		buff.append("         FROM SE_MO_FEE_STL_DY@TMDB_LINK                                                                                                                                  \n");
		buff.append("         WHERE STL_DY = ?                                                                                                                                                 \n");
		buff.append("      ) A,                                                                                                                                                                \n");
		buff.append("      (                                                                                                                                                                   \n");
		buff.append("         SELECT ? STL_DY,                                                                                                                                        \n");
		buff.append("                SUM(NVL(PRD_DISP_FEE,0)+NVL(PRD_REG_FEE,0)+NVL(ETC_FEE,0)) PRE_AMT_FEE                                                                                    \n");
		buff.append("         FROM SE_MO_FEE_STL_DY@TMDB_LINK                                                                                                                                 \n");
		buff.append("         WHERE STL_DY = TO_DATE(?,'YYYYMMDD') -7                                                                                                                 \n");
		buff.append("      ) B,                                                                                                                                                                \n");
		buff.append("      (                                                                                                                                                                   \n");
		buff.append("         SELECT ? STL_DY,                                                                                                                                        \n");
		buff.append("                ROUND(SUM(NVL(PRD_DISP_FEE,0)+NVL(PRD_REG_FEE,0)+NVL(ETC_FEE,0)) / 1.1 / 100000000,2) MON_AMT_FEE                                                         \n");
		buff.append("         FROM SE_MO_FEE_STL_DY@TMDB_LINK                                                                                                                                \n");
		buff.append("         WHERE STL_DY BETWEEN TO_DATE(TO_CHAR(SYSDATE,'YYYYMM')||'01000000','YYYYMMDDHH24MISS')                                                                           \n");
		buff.append("                      AND TO_DATE(?||'235959','YYYYMMDDHH24MISS')                                                                     \n");
		buff.append("      ) C                                                                                                                                                                 \n");
		buff.append(" WHERE A.STL_DY = B.STL_DY                                                                                                                                                \n");
		buff.append(" AND A.STL_DY = C.STL_DY                                                                                                                                                  \n");


		try {

			conn = DBHandler.getConnection(dbUrl,dbId,dbPwd);

			if (conn == null) {
				log.error("Connection is NULL !!!");
				throw new Exception("Connection is NULL !!!");
			}else{

			}

			pstmt = conn.prepareStatement(buff.toString());
            pstmt.setString(1, today);
            pstmt.setString(2, today);
            pstmt.setString(3, today);
            pstmt.setString(4, today);
            pstmt.setString(5, today);
            pstmt.setString(6, today);

			rs = pstmt.executeQuery();

			while( rs.next() ) {
				result = rs.getString("SND_TXT");
				amtFee = rs.getLong("AMT_VFEE");
			}

System.out.println("result ----------> " + result);
System.out.println("amtFee  ----------> " + amtFee);
			if(amtFee < 1){
				userList = null;
			}

			smsTxt = "010-4623-3489,"+result;


/*
			smsTxt = "010-5382-3754,"+result;
			smsTxt += "��010-4028-3900,"+result;
			smsTxt += "��010-6251-9258,"+result;
			smsTxt += "��010-4169-6500,"+result;
			smsTxt += "��010-3553-3388,"+result;
			smsTxt += "��010-5302-2010,"+result;
*/

			userList = smsTxt.split("��");

			DBHandler.closeDBResource(rs,pstmt);
			DBHandler.closeDBResource(conn);

		} catch (Exception e) {
			batchLogEnd(batch_no, "-1", "Error", "N/A", "Y", e.toString(), "��������  SMS �߼� ���� :"+today);
			log.error(e.toString());
		} finally {
			try {
				DBHandler.closeDBResource(rs,pstmt);
				DBHandler.closeDBResource(conn);
			} catch (Exception e) {}

			log.debug("===== "+batchName+" ���� END =====");
		}
		return userList;
	}





}
