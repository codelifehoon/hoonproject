package skt.tmall.daemon.escrow;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

import com.skt.omp.common.db.SqlMapLoader;

import skt.tmall.BOFactory;
import skt.tmall.ServiceFactory;
import skt.tmall.business.event.domain.EventOcb512BO;
import skt.tmall.daemon.common.util.DBHandler;
import skt.tmall.process.share.escrow.buymng.service.BuyManagementService;
import skt.tmall.process.share.escrow.buymng.service.BuyManagementServiceImpl;

/**
 * 512 OCB �̺�Ʈ 5�� ����� ����
 *
 */
public class E60_Ocb512Event extends EscrowBaseDaemon {
    /**
     * @param args
     */
    public static void main(String[] args) {
        EscrowBaseDaemon.initSqlMap();
        E60_Ocb512Event dm = new E60_Ocb512Event();
        dm.run();
    }


	public void run() {
		batch_no = 2560;
    	batchID = "tmba_bo_60";
    	batchName = "512 OCB �̺�Ʈ 5�� ����� ����";

		/* ��ø ���� ����  */
		if (isRunning(batch_no)) {
			String errMsg = "�̹� �������Դϴ�";
			log.error(errMsg);
			batchLogPrint(batch_no, null, null, "-1", "User Define Error", "N/A", "Y", errMsg, errMsg);
			return;
		}

		run_sub();
	}

	@SuppressWarnings("unchecked")
	public void run_sub() {
    	log.debug("===== "+batchName+" START =====");

		batchLogStart(batch_no,"512 OCB �̺�Ʈ 5�� ����� ����");

        Connection conn = null;
        PreparedStatement pstmt = null;
        ResultSet rs = null;

        long sTime = 0;
        long eTime = 0;

        StringBuffer buff = new StringBuffer();
        buff.append("	select ord_no																																								  ");
        buff.append("	     , ord_prd_seq                                                                                                                                                            ");
        buff.append("	     , buy_mem_no                                                                                                                                                             ");
        buff.append("	     , to_char(ord_dt,'yyyy-MM-dd HH24:mi:ss') ord_dt                                                                                                                         ");
        buff.append("	     , case when exp_save_pnt + cooppnt_save_pnt > 3000 then 3000 - cooppnt_save_pnt									                                                      ");
        buff.append("			when exp_save_pnt > 3000 then 3000 else exp_save_pnt end as exp_save_pnt									                                                          ");
        buff.append("	     , cooppnt_save_pnt                                                                                                                                                       ");
        buff.append("	from                                                                                                                                                                          ");
        buff.append("	(                                                                                                                                                                             ");
        buff.append("	    select rownum rm,                                                                                                                                                                ");
        buff.append("		   ord_no ,																																							      ");
        buff.append("		   ord_prd_seq ,                                                                                                                                                          ");
        buff.append("		   buy_mem_no ,                                                                                                                                                           ");
        buff.append("		   ord_dt ,                                                                                                                                                               ");
        buff.append("		   cooppnt_save_pnt,                                                                                                                                                      ");
        buff.append("		   trunc( case                                                                                                                                                            ");
        buff.append("			  when SELLER_MEM_NO = 19439146 then save_pnt * 0.07                                                                                                                      ");
        buff.append("			  when SELLER_MEM_NO = 14569837 then save_pnt * 0.08                                                                                                                      ");
        buff.append("			  when SELLER_MEM_NO = 14569839 then save_pnt * 0.08                                                                                                                      ");
        buff.append("			  when SELLER_MEM_NO = 14569880 then save_pnt * 0.08                                                                                                                      ");
        buff.append("			  when SELLER_MEM_NO = 14569843 then save_pnt * 0.08                                                                                                                      ");
        buff.append("			  when SELLER_MEM_NO = 14569844 then save_pnt * 0.08                                                                                                                      ");
        buff.append("			  when SELLER_MEM_NO = 14569847 then save_pnt * 0.08                                                                                                                      ");
        buff.append("			  when SELLER_MEM_NO = 14569849 then save_pnt * 0.08                                                                                                                      ");
        buff.append("			  when SELLER_MEM_NO = 14569850 then save_pnt * 0.08                                                                                                                      ");
        buff.append("			  when SELLER_MEM_NO = 14569853 then save_pnt * 0.08                                                                                                                      ");
        buff.append("			  when SELLER_MEM_NO = 14569871 then save_pnt * 0.08                                                                                                                      ");
        buff.append("			  when SELLER_MEM_NO = 19697345 then save_pnt * 0.08                                                                                                                      ");
        buff.append("			  when SELLER_MEM_NO = 19697349 then save_pnt * 0.08                                                                                                                      ");
        buff.append("			  when SELLER_MEM_NO = 19697352 then save_pnt * 0.08                                                                                                                      ");
        buff.append("			  when SELLER_MEM_NO = 19697356 then save_pnt * 0.08                                                                                                                      ");
        buff.append("			  when SELLER_MEM_NO = 19697361 then save_pnt * 0.08                                                                                                                      ");
        buff.append("			  when SELLER_MEM_NO = 19697364 then save_pnt * 0.08                                                                                                                      ");
        buff.append("			  when SELLER_MEM_NO = 19697368 then save_pnt * 0.08                                                                                                                      ");
        buff.append("			  when SELLER_MEM_NO = 19697370 then save_pnt * 0.08                                                                                                                      ");
        buff.append("			  when SELLER_MEM_NO = 19697372 then save_pnt * 0.08                                                                                                                      ");
        buff.append("			  when SELLER_MEM_NO = 20085643 then save_pnt * 0.08                                                                                                                      ");
        buff.append("			  when SELLER_MEM_NO = 20085656 then save_pnt * 0.08                                                                                                                      ");
        buff.append("			  when SELLER_MEM_NO = 20085665 then save_pnt * 0.08                                                                                                                      ");
        buff.append("			  when SELLER_MEM_NO = 20085688 then save_pnt * 0.08                                                                                                                      ");
        buff.append("			  when SELLER_MEM_NO = 20085692 then save_pnt * 0.08                                                                                                                      ");
        buff.append("			  when SELLER_MEM_NO = 20085698 then save_pnt * 0.08                                                                                                                      ");
        buff.append("			  when SELLER_MEM_NO = 20085701 then save_pnt * 0.08                                                                                                                      ");
        buff.append("			  when SELLER_MEM_NO = 20085731 then save_pnt * 0.08                                                                                                                      ");
        buff.append("			  when SELLER_MEM_NO = 20085791 then save_pnt * 0.08                                                                                                                      ");
        buff.append("			  when SELLER_MEM_NO = 20085830 then save_pnt * 0.08                                                                                                                      ");
        buff.append("			  else save_pnt * 0.05 end) exp_save_pnt                                                                                                                                  ");
        buff.append("	    from   (select *                                                                                                                                                          		");
        buff.append("		    from   (select                                                                                                                                                				");
        buff.append("				   a.BUY_MEM_NO,                                                                                                                                                        ");
        buff.append("				   b.ord_no,                                                                                                                                                            ");
        buff.append("				   b.ord_prd_seq,                                                                                                                                                       ");
        buff.append("				   a.ord_dt ,                                                                                                                                                           ");
        buff.append("				   (b.sel_prc*(b.ord_qty-b.ord_cn_qty) + b.ord_opt_won_stl-b.ord_opt_cn_amt) - (select nvl(sum(seller_dsc_prc), 0) + nvl(sum(tmall_dsc_prc), 0) from   tr_ord_prd_dsc_dtls opdd where  b.ord_no = opdd.ord_no and    b.ord_prd_seq = opdd.ord_prd_seq and    opdd.dsc_clf in ('09', '01') and    opdd.cn_yn = 'N') as save_pnt ,                                                                         ");
        buff.append("				   (select count(mem_no)                                                                                                                   			                    ");
        buff.append("				    from   MT_EVNT_100512_OCB st                                                                                                                  	                    ");
        buff.append("				    where  st.mem_no = a.BUY_MEM_NO) cnt ,                                                                                                                              ");
        buff.append("				   (select nvl(sum(ext_pnt), 0)                                                                                                          			                    ");
        buff.append("				    from   MT_EVNT_100512_OCB st                                                                                                                  	                    ");
        buff.append("				    where  st.mem_no = a.BUY_MEM_NO                                                                                                                                     ");
        buff.append("				    and    CREDATE_DT >= to_date(to_char(sysdate, 'yyyymmdd')||'000000', 'yyyymmddhh24miss')                                                                            ");
        buff.append("				    and    CREDATE_DT <= to_date(to_char(sysdate, 'yyyymmdd')||'235959', 'yyyymmddhh24miss')) cooppnt_save_pnt ,                                                        ");
        buff.append("				   b.DISP_CTGR_NO ,                                                                                                                                                     ");
        buff.append("				   b.SELLER_MEM_NO,                                                                                                                                                     ");
        buff.append("				   ROW_NUMBER() over(partition by a.buy_mem_no                                                                                                                          ");
        buff.append("				    order by (b.sel_prc*(b.ord_qty-b.ord_cn_qty) + b.ord_opt_won_stl-b.ord_opt_cn_amt) - (select nvl(sum(seller_dsc_prc), 0) + nvl(sum(tmall_dsc_prc), 0) from   tr_ord_prd_dsc_dtls opdd where  b.ord_no = opdd.ord_no and    b.ord_prd_seq = opdd.ord_prd_seq and    opdd.dsc_clf in ('09', '01') and    opdd.cn_yn = 'N') desc) rn                                                                         ");
        buff.append("			    from   tr_ord a ,                                                                                                                       				                ");
        buff.append("				   tr_ord_prd b ,                                                                                                                        			                    ");
        buff.append("							   mb_mem c																																			      ");
        buff.append("			    where  a.ord_no = b.ord_no                                                                                                                                            ");
        buff.append("			    and    (b.DISP_CTGR_NO in ( select distinct DISP_CTGR_NO                                                                                                              ");
        buff.append("	                                                from                                                                                                                          ");
        buff.append("	                                                (                                                                                                                             ");
        buff.append("	                                                    select DISP_CTGR_NO                                                                                                       ");
        buff.append("	                                                    from dp_disp_ctgr_list                                                                                          		  ");
        buff.append("	                                                    where disp_ctgr1_no in ( '1454', '14605', '1611', '1683',                                                                 ");
        buff.append("	                                                    '14608', '4659', '14615', '1930', '8286')                                                                                 ");
        buff.append("	                                                    union all                                                                                                                 ");
        buff.append("	                                                    select DISP_CTGR_NO                                                                                                       ");
        buff.append("	                                                    from dp_disp_ctgr_list                                                                                          		  ");
        buff.append("	                                                    where disp_ctgr2_no in ( '15929', '15913','15914', '15932',                                                               ");
        buff.append("	                                                    '15918', '15912','15937', '15955',                                                                                        ");
        buff.append("	                                                    '15952', '15941','108875','15938')                                                                                        ");
        buff.append("	                                                )  )                                                                                                                          ");
        buff.append("				    or     SELLER_MEM_NO in (select mem_no                                                                                                                              ");
        buff.append("					    from   mb_mem                                                                                                                                                     ");
        buff.append("					    where  mem_id in ('scinic', 'cp0001', 'cp0002', 'cp0003',                                                                                                         ");
        buff.append("							   'cp0004' , 'cp0005', 'cp0006', 'cp0007',                                                                                                                       ");
        buff.append("							   'cp0008',  'cp0009', 'cp0010' ,'cp0011',                                                                                                                       ");
        buff.append("							   'cp0012',  'cp0013', 'cp0014', 'cp0014',                                                                                                                       ");
        buff.append("							   'cp0016' , 'cp0017', 'cp0018', 'cp0019',                                                                                                                       ");
        buff.append("							   'cp0020',  'cp0021', 'cp0022' ,'cp0023',                                                                                                                       ");
        buff.append("							   'cp0024',  'cp0025', 'cp0026', 'cp0027',                                                                                                                       ");
        buff.append("							   'cp0028',  'cp0029', 'cp0030')))                                                                                                                               ");
        buff.append("			    and    a.ord_dt >= to_date(to_char(sysdate-1/24, 'yyyymmddHH24')||'0000', 'yyyymmddhh24miss')                                                                         ");
        buff.append("			    and    a.ord_dt <= to_date(to_char(sysdate-1/24, 'yyyymmddHH24')||'5959', 'yyyymmddhh24miss')                                                                         ");
        buff.append("			    and    b.ord_qty - b.ord_cn_qty > 0                                                                                                                                   ");
        buff.append("			    and    a.buy_mem_no > -1                                                                                                                                              ");
        buff.append("						and    a.buy_mem_no = c.mem_no																															      ");
        buff.append("						and (nvl(a.ocb_card_num, c.ocb_card_num) is not null or a.ocb_rsdnt_no is not null)																		      ");
        buff.append("			    order by a.ord_dt ) m                                                                                                                                                 ");
        buff.append("		    where  rn < 2 ) k                                                                                                                                                       ");
        buff.append("	    where  cnt < 2                                                                                                                                                            ");
        buff.append("	    and    cooppnt_save_pnt < 3000                                                                                                                                            ");
        buff.append("	) tt                                                                                                                                                                          ");
        buff.append("	where rm <= 256                                                                                                                                                               ");

        List arOrdNo 		= new ArrayList();
        List arOrdPrdSeq	= new ArrayList();
        List arMemNo		= new ArrayList();
        List arOrdDt		= new ArrayList();
        List arExpSavePnt	= new ArrayList();
        int cnt = 0;

        try {

            conn = DBHandler.getConnection(dbUrl,dbId,dbPwd);
            if (conn == null) {
                log.error("Connection is NULL !!!");
                throw new Exception("Connection is NULL !!!");
            }

            log.info(buff.toString());
            pstmt = conn.prepareStatement(buff.toString());
            sTime = System.currentTimeMillis();
            log.error("512 OCB �̺�Ʈ 5�� ����� ���� ���ǰ������� ����");
            rs = pstmt.executeQuery();
            while( rs.next() ) {
            	arOrdNo.add(rs.getString("ord_no"));
            	arOrdPrdSeq.add(rs.getString("ord_prd_seq"));
            	arMemNo.add(rs.getString("buy_mem_no"));
            	arOrdDt.add(rs.getString("ord_dt"));
            	arExpSavePnt.add(rs.getString("exp_save_pnt"));
            	cnt++;
            }
            eTime = System.currentTimeMillis();
            log.error("���Ǽ�===>"+cnt);
            log.error("512 OCB �̺�Ʈ 5�� ����� ���� ���ǰ������� ���� : ����ð� ===> "+((double)(eTime-sTime) / (double)1000)+" sec");

            DBHandler.closeDBResource(rs,pstmt);
            DBHandler.closeDBResource(conn);

        } catch (Exception e) {
			batchLogEnd(batch_no, "-1", "ERROR", "step.01", "Y", "512 OCB �̺�Ʈ 5�� ����� ���� ��ȸ ����", "512 OCB �̺�Ʈ 5�� ����� ���� ��ȸ ����");
            e.printStackTrace();
            log.error(e.toString());
            return;
        } finally {
            try {
                DBHandler.closeDBResource(rs,pstmt);
                DBHandler.closeDBResource(conn);
            } catch (Exception e) {}
        }


        /******************************
         * 512 OCB �̺�Ʈ 5�� ����� ����
         */

        if (arOrdNo.size() <= 0) {
			batchLogEnd(batch_no, "0", "Success", "N/A", "N", "512 OCB �̺�Ʈ 5�� ����� ���� ���� : ������", "512 OCB �̺�Ʈ 5�� ����� ���� ���� : ������");
			return;
        }

        String msg = "512 OCB �̺�Ʈ 5�� ����� ����";
        try {
        	BuyManagementService buyManagementService = (BuyManagementService)ServiceFactory.createService( BuyManagementServiceImpl.class );
		    EventOcb512BO		 paramBO              = null;


            long cntSucc = 0;
            long cntFail = 0;
            int cntProc = 0;

            for(int i=0; i<arOrdNo.size(); i++)
            {
            	sTime = System.currentTimeMillis();
                cntProc ++;
                log.info("############################################################");
                log.info("### [" + cntProc + "] �ֹ���ȣ : " + (String)arOrdNo.get(i) + "/�ֹ����� : " + (String)arOrdPrdSeq.get(i) + " START~!!");
                log.info("############################################################");
                try {
                    paramBO = (EventOcb512BO)BOFactory.createBO(EventOcb512BO.class);
                    paramBO.setOrdNo( (String)arOrdNo.get(i) );
                    paramBO.setOrdPrdSeq( (String)arOrdPrdSeq.get(i) );
                    paramBO.setMemNo( (String)arMemNo.get(i) );
                    paramBO.setOrdDt( (String)arOrdDt.get(i) );
                    paramBO.setExpSavePnt( (String)arExpSavePnt.get(i) );
                    paramBO.setExpSavePntYn("N");

                    buyManagementService.insertOcb512Event(paramBO);

                    cntSucc++;

                } catch (SQLException e) {
                    log.error("512 OCB �̺�Ʈ 5�� ����� ���� ����!");
                    log.error(e.getMessage());
                    log.error("### 1�ֹ���ȣ : " + (String)arOrdNo.get(i) + "/�ֹ����� : " + (String)arOrdPrdSeq.get(i));
                    cntFail++;
                } catch (Exception e) {
                    log.error("512 OCB �̺�Ʈ 5�� ����� ���� ����!");
                    log.error(e.getMessage());
                    log.error("### 2�ֹ���ȣ : " + (String)arOrdNo.get(i) + "/�ֹ����� : " + (String)arOrdPrdSeq.get(i));
                    cntFail++;
                }
                eTime = System.currentTimeMillis();
                if ( ((i+1)%5000) == 0 )
                {
                	log.error("[" + String.valueOf(i+1) + "/" + String.valueOf(arOrdNo.size()) + "] 512 OCB �̺�Ʈ 5�� ����� ����("+(String)arOrdNo.get(i)+","+(String)arOrdPrdSeq.get(i)+") ����ð�===> "+((double)(eTime-sTime) / (double)1000)+" sec");
                }
                log.info("############################################################");
                log.info("### [" + cntProc + "] �ֹ���ȣ : " + (String)arOrdNo.get(i) + "/�ֹ����� : " + (String)arOrdPrdSeq.get(i) + " END~!!");
                log.info("############################################################");
            }

            msg += " : ���� " + cntSucc + "��";
            msg += " : ���� " + cntFail + "��";
            String errYN = (cntFail > 0) ? "Y" : "N";

        	batchLogEnd(batch_no, "0", "Success", "step.02", errYN, msg, msg);
        } catch (Exception e) {
			batchLogEnd(batch_no, "-1", "ERROR", "step.03", "Y", "512 OCB �̺�Ʈ 5�� ����� ���� ����", "512 OCB �̺�Ʈ 5�� ����� ���� ����");
            e.printStackTrace();
            log.error(e.toString());
        } finally {
            log.error("===== "+msg+" END =====");
        }
    }

} // end of class