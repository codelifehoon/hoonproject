package skt.tmall.daemon.escrow;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.text.SimpleDateFormat;
import java.util.Date;

import skt.tmall.daemon.common.util.DBHandler;

/**
 * �ϳ� ��� �ϳ� �ݰ� �̺�Ʈ
 * �߰� 50% ����Ʈ ����
 * @author ZZ07237
 *
 */
public class SaveAdd50Pnt extends EscrowBaseDaemon {

	/**
	 * @param args
	 */
	public static void main(String[] args) {
		String inStart = null;
		String inEnd = null;

		if (args != null && args.length > 0) {
			inStart = args[0];
		}
		else {
			SimpleDateFormat SDF = new SimpleDateFormat("yyyyMMddHH");
			inStart = SDF.format(new Date());
		}

		if (args != null && args.length > 1) {
			inEnd = args[1];
		}

		EscrowBaseDaemon.initSqlMap();
		SaveAdd50Pnt dm = new SaveAdd50Pnt();
		dm.run(inStart, inEnd);
	}

	public void run(String inStart, String inEnd) {

		run_sub(inStart, inEnd);
	}

	public void run_sub(String inStart, String inEnd) {
		Connection conn = null;
		PreparedStatement pstmt = null;
		ResultSet rs = null;

		StringBuffer buff = new StringBuffer();
		buff.append("declare\n");
		buff.append("    in_start       DATE;\n");
		buff.append("    in_end   		DATE;\n");
		buff.append("begin\n");
//		buff.append("SP_TR_SAVE_ADD50_EVT(to_date('" + inStart + "', 'YYYYMMDD'),to_date('" + inEnd + "', 'YYYYMMDD'));\n");
		buff.append("SP_TR_SAVE_ADD50_EVT(null, null);\n");
		buff.append("end;\n");

		try {
			conn = DBHandler.getConnection(dbUrl, dbId, dbPwd);

			if (conn == null) {
				log.error("Connection is NULL !!!");
				throw new Exception("Connection is NULL !!!");
			}

			pstmt = conn.prepareStatement(buff.toString());

			pstmt.execute();

			DBHandler.closeDBResource(rs,pstmt);
			DBHandler.closeDBResource(conn);

		} catch (Exception e) {
			System.out.println("����~~~~~~~~~" + e);
		} finally {
			try {
				DBHandler.closeDBResource(rs,pstmt);
				DBHandler.closeDBResource(conn);
			} catch (Exception e) {}

		}
	}
} // end of class
