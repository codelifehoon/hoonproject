package skt.tmall.daemon.escrow;

import java.io.File;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.util.ArrayList;
import java.util.List;

import skt.tmall.BOFactory;
import skt.tmall.ServiceFactory;
import skt.tmall.business.remittance.itemfee.domain.SeFeeItmBO;
import skt.tmall.business.remittance.itemfee.domain.SeFeeStlBO;
import skt.tmall.business.remittance.itemfee.domain.SeFeeStlObjBO;
import skt.tmall.common.util.EFileFilter;
import skt.tmall.daemon.common.util.DBHandler;
import skt.tmall.process.share.remittance.itemfee.service.FeeShareService;
import skt.tmall.process.share.remittance.itemfee.service.FeeShareServiceImpl;

import com.ibatis.sqlmap.client.SqlMapClient;
import com.skt.omp.common.db.SqlMapLoader;
import com.skt.omp.common.util.StringUtil;

/**
 * TEST
 * @author ZZ07237
 *
 */
public class E99_Test extends EscrowBaseDaemon {

	/**
	 * @param args
	 */
	public static void main(String[] args) {
        //EscrowBaseDaemon.initSqlMap();
		E99_Test dm = new E99_Test();

		try {
			String arg1 = (args != null && args.length > 0) ? args[0] : "";
			String arg2 = (args != null && args.length > 1) ? args[1] : "";
			dm.run(arg1, arg2);
		} catch (Exception e) {
		}
	}

	public void run(String arg1,String arg2) {
		batchID = "tmba_bo_99";
		batchName = "TEST";
		
		String ingFile = "E99_Test.ing";
		log.debug("ingFile : "+ingFile);
		
		/* ��ø ���� ����  */
		if (isFileExist(ingFile)) {
			log.error("�̹� �������Դϴ�. : " + ingFile);
			batchLog(batchID, "N", "�̹� �������Դϴ�. : " + ingFile);
			return;
		}
		
		/* ���� ���� */
		createFile(ingFile);
		
		run_test02(arg1,arg2);
		
		/* ���� ���� */
		deleteFile(ingFile);
	}
	
	public void run_test01(String arg1,String arg2) {
		File myDir = new File("/data1/upload/InterfaceData_dev/goods/operation/");
		File[] contents = myDir.listFiles(new EFileFilter("GoodsFlowRequestShipInfo_20071226"));
		log.info("contents size : " + contents.length);
	}

	public void run_test02(String arg1,String arg2) {
		log.debug("debug log");
		log.error("error log");
		log.info("info log");
		log.warn("warn log");
	}

	public void run_sub(String arg1,String arg2) {
		log.debug("===== "+batchName+" START =====");

		Connection conn = null;
		PreparedStatement pstmt = null;
		ResultSet rs = null;
		
		StringBuffer buff = new StringBuffer();
		buff.append("	BEGIN 							\n");
		buff.append("   	SP_TR_ORD_STLMNT_DTLS(?,?);	\n");
		buff.append("	END;							\n");

		try {
			conn = DBHandler.getConnection(dbUrl,dbId,dbPwd);
			if (conn == null) {
				log.error("Connection is NULL !!!");
				throw new Exception("Connection is NULL !!!");
			}
			
			String result = "";
			
			pstmt = conn.prepareStatement(buff.toString());
			pstmt.setString(1, arg1);
			pstmt.setString(2, result);
			pstmt.execute();
			
			DBHandler.closeDBResource(rs,pstmt);
			DBHandler.closeDBResource(conn);

			String msg = "";
			msg += "agr1:" + arg1;
			msg += " agr2:" + arg2;
			msg += " result:" + result;
				
			batchLog(batchID, "Y", msg);
		} catch (Exception e) {
			String err = "arg1:" + arg1;
			err += " arg2:" + arg2;
			err += " Err:"+e.toString();
			batchLog(batchID, "N", err);
			log.error(err);
		} finally {
			try {
				DBHandler.closeDBResource(rs,pstmt);
				DBHandler.closeDBResource(conn);
			} catch (Exception e) {}

			log.debug("===== "+batchName+" END =====");
		}
	}

    public void runExtendBatch() throws Exception {
        System.out.println("��ǰ �ڵ����� Batch start!");
        log.warn("��ǰ �ڵ����� Batch start!");
        
        try {
            //sqlMapCllientȹ��
        	SqlMapClient sqlMapClientTmall = SqlMapLoader.getInstance();
        	if (sqlMapClientTmall == null) {
        		log.error("sqlMapClientTmall == null");
        		return;
        	}
            

            // �ڵ����� ��� ��ǰ ��� ���ϱ�
            System.out.println("�ڵ����� ��� ��ǰ ��� ���ϱ� Start...");
            System.out.println("�ڵ����� ��� ��ǰ ��� ���ϱ� End...");
            
            long prdNo = 3004160;
            long memNo = 10000005;
            
            // �߰��� exception�� �����ص� ���� ���� ��� ó��.
            for(int i=0; i<5; i++) {
                
                try {
                    //Ʈ����� ����
                    sqlMapClientTmall.startTransaction();

                    /*
                     * �������� ���̹� �Ӵ� ���� ó�� Ȯ��
                     */
                    if (1>0)
                    {
                    	List seFeeStlObjList = new ArrayList();
                    	
                    	FeeShareService feeService = (FeeShareService)ServiceFactory.createService(FeeShareServiceImpl.class);
                    	SeFeeItmBO seFeeItmParamBO = (SeFeeItmBO)BOFactory.createBO(SeFeeItmBO.class);
                        seFeeItmParamBO.setFeeKdCd("01");
                        seFeeItmParamBO.setFeeTypCd("01201");
                        SeFeeItmBO getFeeItm = feeService.getFeeItm(sqlMapClientTmall, seFeeItmParamBO);
                        
                        SeFeeStlObjBO seFeeStlObjBo = (SeFeeStlObjBO)BOFactory.createBO(SeFeeStlObjBO.class);
                        seFeeStlObjBo.setFeeItmNo(getFeeItm.getFeeItmNo());                      // ������ �׸� ��ȣ
                        seFeeStlObjBo.setFeeStlObjNo1(""+prdNo);                     // ���� ��� ��ȣ1
                        seFeeStlObjBo.setFeeStlObjNo2("");                      // ���� ��� ��ȣ2
                        seFeeStlObjBo.setFeeStlAplBgnDy(StringUtil.left("20080305"+"000000",14));      // ������ ���� ���� ���� ����
                        seFeeStlObjBo.setFeeStlAplEndDy(StringUtil.left("20080305"+"000000",14));      // ������ ���� ���� ���� ����
                        seFeeStlObjBo.setFeeItmAplQty("1");                     // ������ �׸� ���� ����
                        seFeeStlObjBo.setFeeStlAmt(""+getFeeItm.getFee());                      // ������ ���� �ݾ�
                        seFeeStlObjBo.setCreateNo(""+memNo);
                        seFeeStlObjList.add(seFeeStlObjBo);
                        
                        
                        SeFeeStlBO seFeeStlBO = (SeFeeStlBO)BOFactory.createBO(SeFeeStlBO.class);
                        seFeeStlBO.setMemNo(""+memNo);               // ȸ�� ��ȣ
                        seFeeStlBO.setFeeStlAmt(""+getFeeItm.getFee());               // ������ ������ 
                        seFeeStlBO.setFeeStlStatCd("02");       // ������ ���� ���� �ڵ� (01: ������, 02:�����Ϸ�)
                        
                        seFeeStlBO.setCybrMnyStlAmt(""+getFeeItm.getFee());     // ���̹� �Ӵ� ������
                        seFeeStlBO.setPntStlAmt("0");         // ����Ʈ ������
                        seFeeStlBO.setCupnDscAmt("0");        // ���� ���ξ�
                        seFeeStlBO.setCreateNo(""+memNo);
                        
                        seFeeStlBO.setSeFeeStlObjList(seFeeStlObjList);
                        log.error("[���] step1");
                        feeService.doFeeSettlement(sqlMapClientTmall, seFeeStlBO, false);
                    }
                    
                    
                	log.error("[���] step2");
//                	sqlMapClientTmall.commitTransaction();

                	//                    // commit
                    try{
                    	sqlMapClientTmall.commitTransaction();
                    } catch(Exception e) {}
                    
                    log.error("[���] step3");
                    
                }catch(Exception e) {
                    // �����Ǽ� ����
                	log.error("[���] �����Ǽ� ����");
                    System.out.println(e.getMessage());
                    e.printStackTrace();
                    log.error(e);
                }
                finally {
                	log.error("[���] endTransaction");
                    try{sqlMapClientTmall.endTransaction();}catch(Exception e) {}
                }
                
                log.warn("[�ڵ����� Batch] ��ǰ��ȣ ��ȣ : "+prdNo + " ó���Ϸ�");
                
            }//end for
            
        }
        catch(Exception e) {
            System.out.println(e.getMessage());
            e.printStackTrace();
            log.error(e);
            throw e;
        }

        log.warn("�ڵ����� Batch End!");
    }

} // end of class
