package skt.tmall.daemon.escrow;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.HashMap;
import java.util.List;

import skt.tmall.BOFactory;
import skt.tmall.ServiceFactory;
import skt.tmall.bdt.transfer.mail.EmailRequestBO;
import skt.tmall.bdt.transfer.mail.EmailUserInfo;
import skt.tmall.business.escrow.trade.domain.CashSettlementManagerBO;
import skt.tmall.business.escrow.trade.domain.EscrowCancelBO;
import skt.tmall.business.escrow.trade.domain.EscrowSearchBO;
import skt.tmall.business.escrow.trade.domain.OrderBO;
import skt.tmall.business.escrow.trade.domain.OrderProductBO;
import skt.tmall.business.escrow.trade.domain.OrderProductCancelBO;
import skt.tmall.business.escrow.trade.domain.OrderProductOptionBO;
import skt.tmall.business.escrow.trade.domain.SettlementBO;
import skt.tmall.business.escrow.trade.domain.SettlementManagerBO;
import skt.tmall.business.escrow.trade.domain.SettlementOnlineBO;
import skt.tmall.daemon.common.util.DBHandler;
import skt.tmall.process.share.escrow.buymng.service.BuyManagementService;
import skt.tmall.process.share.escrow.buymng.service.BuyManagementServiceImpl;
import skt.tmall.process.share.escrow.sell.service.SellingService;
import skt.tmall.process.share.escrow.sell.service.SellingServiceImpl;
import skt.tmall.process.share.remittance.remittancesummary.service.EmailService;
import skt.tmall.process.share.remittance.remittancesummary.service.EmailServiceImpl;

import com.ibatis.sqlmap.client.SqlMapClient;
import com.skt.omp.common.db.SqlMapLoader;
import com.skt.omp.common.util.DataBox;
import com.skt.omp.common.util.DateTime;
import com.skt.omp.common.util.DateUtil;
import com.skt.omp.common.web.RequestUtil;

public class E65_AutoCancelApproveBatch  extends EscrowBaseDaemon {
    private final String _OPT_SEQ = "_SEQ";
    private final String _OPT_QTY = "_QTY";

    public static void main( String[] args ) {
        EscrowBaseDaemon.initSqlMap();
        E65_AutoCancelApproveBatch dm = new E65_AutoCancelApproveBatch();
        dm.run();
    }

	public void run() {
		batch_no = 2567;
    	batchID = "Escrow";
    	batchName = "�ֹ���� ��û�� �ڵ� ���� ��ġ";


    	log.error("################## batch_no : " + batch_no);

		/* ��ø ���� ����  */
		if (isRunning(batch_no)) {
			String errMsg = "�̹� �������Դϴ�";
			log.error(errMsg);
			batchLogPrint(batch_no, null, null, "-1", "User Define Error", "N/A", "Y", errMsg, errMsg);
			return;
		}
		run_sub();
	}

    /**
     * �ֹ���� ��û�� ���� �ڵ����� �������ִ� ��ġ <P/>
     * 1. ���ó��
     *
     * @param date : ������¥( "20071212" ���·� �־�� ��)
     */
    public void run_sub() {
    	log.info("===== "+batchName+" START =====");

		batchLogStart(batch_no,"�ֹ���� ��û�� �ڵ� ���� ��ġ");

        Connection conn = null;
        PreparedStatement pstmt = null;
        ResultSet rs = null;

        String ordNo       = "";
        String ordPrdSeq   = "";
        String ordPrdCnSeq = "";
        int totCnt = 0;
        int failCnt = 0;
        int successCnt = 0;

        ArrayList<String> arSucc = null;
        ArrayList<String> arFail = null;

		Date date = new Date();
		long currDate = date.getTime();
		SimpleDateFormat formatter = new SimpleDateFormat("yyyyMMddHHmmss");
		String sCurrentDate = "";
		String msg = "�ֹ���� ��û ���� ��ġ";

        try {
            // ----------------------------------------------------------------
            // Ŀ�ؼ� ���
            conn = DBHandler.getConnection(dbUrl, dbId, dbPwd);
            if (conn == null) {
                log.error("Connection is NULL !!!");
                throw new Exception("Connection is NULL !!!");
            }
            pstmt = conn.prepareStatement(this.getCancelOrdersQuery()); //1
            if (log.isDebugEnabled()) {
                log.info(this.getCancelOrdersQuery());
            }
            rs = pstmt.executeQuery();

            // ----------------------------------------------------------------
            // ���ÿɼ� ��� ���� ��ȸ�� ����ֹ� ����Ʈ�� ����
            // ----------------------------------------------------------------
            // ��ҽ���

            List<EscrowCancelBO> allList = new ArrayList<EscrowCancelBO>();
            EscrowCancelBO cancelBo = null;

            while (rs.next()) {

            	ordNo = rs.getString("ord_no");
                ordPrdSeq = rs.getString("ord_prd_seq");
                ordPrdCnSeq = rs.getString("ord_prd_cn_seq");

                cancelBo = (EscrowCancelBO)BOFactory.createBO(EscrowCancelBO.class);

                cancelBo.setOrdNo(ordNo);
                cancelBo.setOrdPrdSeq(ordPrdSeq);
                cancelBo.setOrdPrdCnSeq(ordPrdCnSeq);
                allList.add(cancelBo);
            }
            SellingService service = (SellingService)ServiceFactory.createService(SellingServiceImpl.class );

            OrderBO   paramBO = (OrderBO)BOFactory.createBO(OrderBO.class);
            OrderProductBO     orderProductBO  = (OrderProductBO)BOFactory.createBO(OrderProductBO.class);
            OrderProductCancelBO cancelBO = (OrderProductCancelBO)BOFactory.createBO(OrderProductCancelBO.class);
            OrderProductOptionBO optBO = (OrderProductOptionBO)BOFactory.createBO(OrderProductOptionBO.class);

            totCnt = allList.size();

            boolean resultVal = false;

            for(int i=0;i<totCnt;i++) {
               cancelBo = (EscrowCancelBO)allList.get(i);

               //1������
               currDate = currDate + (1000);
               sCurrentDate = formatter.format(currDate);


 	    	   DataBox dataBox2 = new DataBox();
	    	   dataBox2.put("ordNo", cancelBo.getOrdNo());
	    	   dataBox2.put("ordPrdSeq", cancelBo.getOrdPrdSeq());
	    	   dataBox2.put("ordPrdCnSeq", cancelBo.getOrdPrdCnSeq());

	    	   dataBox2.put("updateDt", sCurrentDate);
	    	   dataBox2.put("updateNo", "0");
	    	   dataBox2.put("createIp","127.0.0.1");
	    	   dataBox2.put("ordCnMnbdCd", "11"); //�ý��� ó��


	           RequestUtil.populate(paramBO, dataBox2);
	           RequestUtil.populate(orderProductBO, dataBox2);
	           RequestUtil.populate(cancelBO, dataBox2);
	           RequestUtil.populate(optBO, dataBox2);

	           /**********************************************
	            * ��ҿ�û����
	            **********************************************/
	           paramBO.setOrderProductBO(orderProductBO);
	           paramBO.setOrderProductCancelBO(cancelBO);//(��ҿ�û�Ϸù�ȣ,��Ҽ���)

	           try{
	        	   resultVal = service.approvalOrderCancelRequestProcess(paramBO);
	        	   successCnt++;
	           }catch(Exception e){
	        	   failCnt++;
	           }

            }

            DBHandler.closeDBResource(rs, pstmt);
            msg += " : ���� " + successCnt + "��";
            msg += " : ���� " + failCnt + "��";
            String errYN = (successCnt >= 0) ? "Y" : "N";
			batchLogEnd(batch_no, "0", "Success", "N/A", errYN, msg, msg);
			DBHandler.closeDBResource(conn);
        } catch (SQLException e) {
        	batchLogEnd(batch_no, "-1", "ERROR", "N/A", "Y", "�ֹ���� ��û ���� ��ġ ����!" + msg , "�ֹ���� ��û ���� ��ġ ����!"+ msg);
            log.error("�ֹ���� ��û ���� ��ġ ����!");
            log.error(e);
        } catch (Exception e) {
        	batchLogEnd(batch_no, "-1", "ERROR", "N/A", "Y", "�ֹ���� ��û ���� ��ġ ����!"+ msg, "�ֹ���� ��û ���� ��ġ ����!"+ msg);
            log.error("�ֹ���� ��û ���� ��ġ ����!");
            log.error(e);
        } finally {
        	if(conn != null){
        		DBHandler.closeDBResource(conn);
        	}
        }

        log.info(DateUtil.getDate() + " �ֹ���� ��û ���� �����Ǽ�:" + successCnt);
        log.info(DateUtil.getDate() + " �ֹ���� ��û ���� ���аǼ�:" + failCnt);
        log.info("===== "+batchName+" End =====");
    }


    /**
     * �ֹ���� ��û�� ������ ��ȸ
     *
     * @return
     */
    private String getCancelOrdersQuery() {
        StringBuffer buff = new StringBuffer();

        // 2008.02.23 - �Աݱ������ڸ� �������� �ڵ����Űź� ó�� ��� �� ��ȸ
        buff.append("\n SELECT 	/* E65_AutoCancelApproveBatch.java getCancelOrdersQuery */  					  ");
        buff.append("\n 		a.ord_prd_cn_seq,      															  ");
        buff.append("\n 		a.ord_no,      																	  ");
        buff.append("\n 		a.ord_prd_seq,     																  ");
        buff.append("\n 		a.ord_cn_req_dt      															  ");
        buff.append("\n  FROM   tr_ord_prd_cn_dtls a, mb_mem b, tr_ord_prd c, dp_disp_ctgr d       				  ");
        buff.append("\n  WHERE  to_date(FN_SY_CALENDAR('+', '3', a.ord_cn_req_dt), 'YYYYMMDD') =  trunc(sysdate)  ");
        buff.append("\n  AND    a.ord_cn_stat_cd = '01'                                                           ");
        buff.append("\n  AND    a.seller_mem_no_de = b.mem_no                                                        ");
        buff.append("\n  AND    a.ord_no = c.ord_no                                                               ");
        buff.append("\n  AND    a.ord_prd_seq = c.ord_prd_seq                                                     ");
        buff.append("\n  AND    c.disp_ctgr_no = d.disp_ctgr_no                                                   ");
        buff.append("\n  AND    d.auto_cancel_yn = 'Y'                                                            ");
        buff.append("\n  AND    nvl(b.auto_cancel_yn, 'Y') = 'Y'                                                  ");
        buff.append("\n  AND    a.ord_cn_req_dt > to_date('20100723000000', 'yyyymmddhh24miss')                   ");
        buff.append("\n  AND    a.ord_cn_req_dt > SYSDATE - 10                                                    ");

        return buff.toString();
    }


}
