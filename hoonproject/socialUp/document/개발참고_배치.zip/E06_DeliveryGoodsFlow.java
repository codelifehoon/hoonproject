package skt.tmall.daemon.escrow;

import java.io.File;

import skt.tmall.ServiceFactory;
import skt.tmall.common.util.EDate;
import skt.tmall.process.share.escrow.shipping.service.ShippingInterfaceService;
import skt.tmall.process.share.escrow.shipping.service.ShippingInterfaceServiceImpl;

/**
 * GoodsFlow ��۰�� ��ġ
 * @author ZZ07237
 * @version 0.1
 */
public class E06_DeliveryGoodsFlow extends EscrowBaseDaemon {

	/**
	 * @param args
	 */
	public static void main(String[] args) {
        EscrowBaseDaemon.initSqlMap();
		E06_DeliveryGoodsFlow dm = new E06_DeliveryGoodsFlow();
		dm.run();
	}

	public void run() {
    	batchID = "tmba_bo_06";
		batchName = "GoodsFlow ��۰�� ��ġ";
        batch_no = 2506;


        /* ��ø ���� ����  */
        if (isRunning(batch_no)) {
            String errMsg = "�̹� �������Դϴ�:";
            log.error(errMsg);
            batchLogPrint(batch_no, null, null, "-1", "User Define Error", "N/A", "Y", errMsg, errMsg);
            return;
        }

		run_sub();
	}

	public void run_sub() {
		log.debug("===== "+batchName+" START =====");

//		SqlMapClient sqlMapClient = SqlMapLoader.getInstance();
//		log.debug("sqlMapClient : " + sqlMapClient);

    	log.info("��۰�� ���� ������Ʈ ����!!!!!!!!!");
        batchLogStart(batch_no,"��ġ ����");

        try {
            ShippingInterfaceService shippingInterfaceService = (ShippingInterfaceService)ServiceFactory.createService( ShippingInterfaceServiceImpl.class );
            shippingInterfaceService.setProperties(prop);
            shippingInterfaceService.updateGoodsFlowDeliveryState();

            batchLogEnd(batch_no, "0", "Success", "N/A", "N", "��ġ��", null);
        }
        catch(Exception e) {
            String err="";
            err += " Err:"+e.toString();
            batchLogEnd(batch_no, "-1", "Error", "N/A", "Y", err, "[GF�������������Ʈ ����] ");
            log.error(e);
		} finally {
			log.debug("===== "+batchName+" END =====");
		}
        log.info("��۰�� ���� ������Ʈ ����!!");
    }

} // end of class
