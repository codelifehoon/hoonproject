package skt.tmall.daemon.escrow;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;

import skt.tmall.business.bulkSmsSender.domain.BulkSmsSenderMessageProperites;
import skt.tmall.daemon.common.util.DBHandler;

public class E39_BulkSmsResult extends EscrowBaseDaemon {
	public static void main(String[] args) {
		E39_BulkSmsResult dm = new E39_BulkSmsResult();
		dm.run();
	}

	public void run() {
		batch_no = 2547;
		batchID = "bulksms_E39";
		batchName = "SMS �߼� ��� ������Ʈ ��ġ";

		/* ��ø ���� ����  */
		if (isRunning(batch_no)) {
			String errMsg = "�̹� �������Դϴ�";
			log.error(errMsg);
			batchLogPrint(batch_no, null, null, "-1", "User Define Error", "N/A", "Y", errMsg, errMsg);
			return;
		}

		process();
	}

	public void process() {
		batchLogStart(batch_no,"SMS �߼� ��� ������Ʈ ��ġ ");

		log.debug("===== "+batchName+" START =====");

		Connection conn = null;
		PreparedStatement pstmt = null;
		ResultSet rs = null;

		StringBuffer buff = new StringBuffer();
		buff.append("	BEGIN 									\n");
		buff.append("   	SP_SMS_EVNT_RESULT;					\n");
		buff.append("	END;									\n");

		try {
			//�ַ�ǵ�� ���� ��������
			BulkSmsSenderMessageProperites prop = BulkSmsSenderMessageProperites.getInstance();
			String soldbUrl = prop.getProperty("tmall.sqlMap.url", "jdbc:oracle:thin:@220.103.232.110:1525:DEV");
			String soldbId = prop.getProperty("tmall.sqlMap.username", "tmall_cp");
			String soldbPasswd = prop.getProperty("tmall.sqlMap.password","tmall_cp");

			conn = DBHandler.getConnection(soldbUrl,soldbId,soldbPasswd);
			if (conn == null) {
				log.error("Connection is NULL !!!");
				throw new Exception("Connection is NULL !!!");
			}

			pstmt = conn.prepareStatement(buff.toString());
			pstmt.execute();

			DBHandler.closeDBResource(rs,pstmt);
			DBHandler.closeDBResource(conn);

			batchLogEnd(batch_no, "0", "Success", "N/A", "N", "SMS �߼۰�� ������Ʈ ����", null);

		} catch (Exception e) {
			batchLogEnd(batch_no, "-1", "ERROR", "N/A", "Y", "SMS �߼۰�� ������Ʈ ����", "SMS �߼۰�� ������Ʈ ����");
			log.error(e.toString());
		} finally {
			try {
				DBHandler.closeDBResource(rs,pstmt);
				DBHandler.closeDBResource(conn);
			} catch (Exception e) {}

			log.debug("===== "+batchName+" END =====");
		}

	}

}
