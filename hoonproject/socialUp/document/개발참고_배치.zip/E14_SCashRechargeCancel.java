package skt.tmall.daemon.escrow;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;

import skt.tmall.daemon.common.util.DBHandler;

/**
 * S-ĳ�� �������
 * @author ZZ07237
 *
 */
public class E14_SCashRechargeCancel extends EscrowBaseDaemon {

	/**
	 * @param args
	 */
	public static void main(String[] args) {
		E14_SCashRechargeCancel dm = new E14_SCashRechargeCancel();
		dm.run();
	}

	public void run() {
		batch_no = 2514;
		batchID = "tmba_bo_14";
		batchName = "S-ĳ�� �������";
		
		/* ��ø ���� ����  */
		if (isRunning(batch_no)) {
			String errMsg = "�̹� �������Դϴ�";
			log.error(errMsg);
			batchLogPrint(batch_no, null, null, "-1", "User Define Error", "N/A", "Y", errMsg, errMsg);
			return;
		}
		
		run_sub();
	}

	public void run_sub() {
		log.debug("===== "+batchName+" START =====");
		batchLogStart(batch_no,"S-ĳ�� �������");

		Connection conn = null;
		PreparedStatement pstmt = null;
		ResultSet rs = null;
		
		StringBuffer buff = new StringBuffer();
		buff.append("	BEGIN						\n");
		buff.append("   	SP_TR_CYBER_MNY_CANCEL;	\n");
		buff.append("	END;						\n");

		try {
			conn = DBHandler.getConnection(dbUrl,dbId,dbPwd);
			if (conn == null) {
				log.error("Connection is NULL !!!");
				throw new Exception("Connection is NULL !!!");
			}
			
			pstmt = conn.prepareStatement(buff.toString());
			pstmt.execute();
			
			DBHandler.closeDBResource(rs,pstmt);
			DBHandler.closeDBResource(conn);
			
			batchLogEnd(batch_no, "0", "Success", "N/A", "N", "S-ĳ�� ������� ����", null);
			
		} catch (Exception e) {
			batchLogEnd(batch_no, "-1", "ERROR", "N/A", "Y", "S-ĳ�� ������� ����", "S-ĳ�� ������� ����");
			log.error(e.toString());
		} finally {
			try {
				DBHandler.closeDBResource(rs,pstmt);
				DBHandler.closeDBResource(conn);
			} catch (Exception e) {}

			log.debug("===== "+batchName+" END =====");
		}
	}
} // end of class
