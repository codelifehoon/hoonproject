package skt.tmall.daemon.escrow;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.util.ArrayList;
import java.util.List;

import skt.tmall.ServiceFactory;
import skt.tmall.business.escrow.trade.domain.OrderClaimDeliveryListBO;
import skt.tmall.daemon.common.util.DBHandler;
import skt.tmall.process.share.escrow.shipping.service.ShippingInterfaceService;
import skt.tmall.process.share.escrow.shipping.service.ShippingInterfaceServiceImpl;

import com.ibatis.sqlmap.client.SqlMapClient;
import com.skt.omp.common.db.SqlMapLoader;

/**
 * GoodsFlow ��ġ��ȯ
 * ������ �Ǹ��ڰ� �߼�ó�� �ϸ�, �ǽð� �½��÷ο� ���ۿ��� 5�д����� ��ġ ��ȯ�Ѵ�
 * 2009.01.04
 * @author �ȿ
 * @version 0.1
 */
public class E26_DeliveryGoodsFlowBatch extends EscrowBaseDaemon {

	/**
	 * @param args
	 */
	public static void main(String[] args) {
        EscrowBaseDaemon.initSqlMap();
        E26_DeliveryGoodsFlowBatch dm = new E26_DeliveryGoodsFlowBatch();
		dm.run();
	}

	public void run() {
		batchName = "GoodsFlow ��ġ��ȯ";
        batch_no = 2526;


        /* ��ø ���� ����  */
        if (isRunning(batch_no)) {
            String errMsg = "GoodsFlow �߼۹�ġ �̹� �������Դϴ�:";
            log.error(errMsg);
            batchLogPrint(batch_no, null, null, "-1", "User Define Error", "N/A", "Y", errMsg, errMsg);
            return;
        }

		run_sub();
	}

	public void run_sub() {
		log.debug("===== "+batchName+" START =====");

    	log.info("��۰�� ���� ������Ʈ ����!!!!!!!!!");
        batchLogStart(batch_no,"��ġ ����");

        SqlMapClient sqlMapClient = null;

        try {
        	List<OrderClaimDeliveryListBO> list = getResendList();
        	if (list != null && list.size() > 0) {
				sqlMapClient = SqlMapLoader.getInstance();
	        	sqlMapClient.startTransaction();
				log.debug("sqlMapClient : " + sqlMapClient);

				ShippingInterfaceService shippingInterfaceService = (ShippingInterfaceService)ServiceFactory.createService( ShippingInterfaceServiceImpl.class );
	            shippingInterfaceService.setProperties(prop);
				shippingInterfaceService.getDeliveryFileSend(sqlMapClient, list);

				sqlMapClient.commitTransaction();
        	}

            batchLogEnd(batch_no, "0", "Success", "N/A", "N", "ó���Ǽ�:"+list.size(), null);
        }
        catch(Exception e) {
        	if (sqlMapClient != null) {
        		try {
        			sqlMapClient.endTransaction();
        		} catch (Exception e2) {}
        	}

        	e.printStackTrace();
        	log.error(e.toString());

            String err="";
            err += " Err:"+e.toString();
            batchLogEnd(batch_no, "-1", "Error", "N/A", "Y", err, batchName + " ����");
            log.error(e);
		} finally {
		    try {sqlMapClient.endTransaction();} catch (Exception trnas) {}
			log.debug("===== "+batchName+" END =====");
		}
        log.info(batchName + " ����!!");
    }

	public List<OrderClaimDeliveryListBO> getResendList() {

		List<OrderClaimDeliveryListBO> list = new ArrayList<OrderClaimDeliveryListBO>();

		Connection conn = null;
		PreparedStatement pstmt = null;
		ResultSet rs = null;

		StringBuffer buffer = new StringBuffer();
        buffer.append(" SELECT  /*+ INDEX (a PK_TR_ORD) */                                 										\n");
        buffer.append("       distinct(d.dlv_no) as dlv_no                                 										\n");
        buffer.append(" FROM    tr_ord a                                                   										\n");
        buffer.append("         , tr_ord_prd b                                             										\n");
        buffer.append("         , tr_ord_clm_delvplace c                                   										\n");
        buffer.append("         , tr_ord_clm_dlv_dtls d                                    										\n");
        buffer.append("         , TR_TRSNP_ETPRS_EXTR e																			\n");
        buffer.append(" WHERE   a.ord_no = b.ord_no                                        										\n");
        buffer.append("         and c.delvplace_seq = b.delvplace_seq                      										\n");
        buffer.append("         and d.dlv_no = b.dlv_no                                    										\n");
        buffer.append("         and c.del_yn = 'N'                                         										\n");
        buffer.append("         and d.dlv_etprs_cd is not null                             										\n");
        buffer.append("         and d.del_yn = 'N'                                         										\n");
        buffer.append("         and d.dlv_etprs_cd = e.dlv_etprs_cd	                                                            \n");
        buffer.append("         and e.GOODSFLOW_TRACE_YN = 'Y'                                                                  \n");
//        buffer.append("         and d.dlv_etprs_cd NOT IN ('00099', '00023', '00024', '00025')                        			\n");
        buffer.append("         and d.DLV_OCCR_TY = '01'               /* �߼���ü : 01 : �����, 02: ��ȯ�߼�, 04 : ��ǰ�߼� */    \n");
        buffer.append("         and b.ORD_PRD_STAT = '401'            /* �߼ۿϷ� */                  							\n");
//        buffer.append("         and b.prd_typ_cd = '01'                /* ��ǰ�ֹ��ڵ�(PD018) */      \n");
        buffer.append("         and d.DLV_MTHD_CD in ('01','02','03')     /* ��۹��(TR044) */                                  \n");
        buffer.append("         and d.GOODSFLOW_SEND_DT is null       /* �½��÷����� ���� */                                      \n");
        buffer.append("         and d.SND_END_DT > sysdate - 12/24      /* �߼ۿϷ��� 3�ð� ���� */                                 \n");
        buffer.append("         and (b.CHINA_SALE_YN is null or b.CHINA_SALE_YN = 'N')    /*þ�Ż�ǰ����*/                        \n");
        buffer.append("         and rownum <= 1500                                                                                \n");

		try {
			conn = DBHandler.getConnection(dbUrl,dbId,dbPwd);
			if (conn == null) {
				log.error("Connection is NULL !!!");
				throw new Exception("Connection is NULL !!!");
			}

			pstmt = conn.prepareStatement(buffer.toString());
			rs = pstmt.executeQuery();
			//rs.setFetchSize(200);
			while( rs.next() ) {
				OrderClaimDeliveryListBO bo = new OrderClaimDeliveryListBO();
				bo.setDlvNo(rs.getString("dlv_no"));
				list.add(bo);
			}

			DBHandler.closeDBResource(rs,pstmt);
			DBHandler.closeDBResource(conn);

		} catch (Exception e) {
			e.printStackTrace();
			log.error(e.toString());
		} finally {
			try {DBHandler.closeDBResource(rs,pstmt); } catch (Exception rse) {}
			try {DBHandler.closeDBResource(conn); } catch (Exception conne) {}
			log.debug("===== "+batchName+" ���� END =====");
		}

		return list;
	}

/**
 * ��� �߻��� �Ʒ� dlv_no �� �ϵ��ڵ��Ͽ� �߼� �� �� �ִ�.
 *
 * @return
 */
public List<OrderClaimDeliveryListBO> Not_work_getResendList() {

        List<OrderClaimDeliveryListBO> list = new ArrayList<OrderClaimDeliveryListBO>();

        String[] dlv_no = {
                "8247341"
        };

        try {
               for(int i = 0; i < dlv_no.length; i++) {
                OrderClaimDeliveryListBO bo = new OrderClaimDeliveryListBO();
                bo.setDlvNo(dlv_no[i]);
                list.add(bo);
               }

        } catch (Exception e) {
            e.printStackTrace();
            log.error(e.toString());
        } finally {

            log.debug("===== "+batchName+" ���� END =====");
        }

        return list;
    }

} // end of class
