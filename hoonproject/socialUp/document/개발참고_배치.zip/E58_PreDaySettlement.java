package skt.tmall.daemon.escrow;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.util.Date;

import skt.tmall.common.util.EDate;
import skt.tmall.daemon.common.util.DBHandler;

/**
 * ���� 00:30�� ���� 23:00~23:39:59 ������ ���굥���� ó��
 * @author ZZ07237
 *
 */
public class E58_PreDaySettlement extends EscrowBaseDaemon {

	/**
	 * @param args
	 */
	public static void main(String[] args) {
		E58_PreDaySettlement dm = new E58_PreDaySettlement();
		dm.run(args);
	}


	public void run(String[] args) {
		batch_no = 2558;
		batchID = "tmba_bo_58";
		batchName = "�ǸŴ�����곻�� ����";

		/* ��ø ���� ����  */
		if (isRunning(batch_no)) {
			String errMsg = "�̹� �������Դϴ�";
			log.error(errMsg);
			batchLogPrint(batch_no, null, null, "-1", "User Define Error", "N/A", "Y", errMsg, errMsg);
			return;
		}

		run_sub(args);
	}

	public void run_sub(String[] args) {
		log.debug("===== "+batchName+" START =====");
		batchLogStart(batch_no,"������");

		String yesterday = "";
		if (args != null && args.length > 0) {
			yesterday = args[0];
		}


		if (yesterday == null || yesterday.length() != 8) {
			Date dt = EDate.offset(new Date(), 0, 0, -1);
			yesterday = this.dateFormat(dt, "yyyyMMdd");
		}


		Connection conn = null;
		PreparedStatement pstmt = null;
		ResultSet rs = null;

		StringBuffer buff = new StringBuffer();
		buff.append("	BEGIN 											\n");
		buff.append("   	SP_SE_STL_HOUR( to_date(?,'yyyymmdd') );	\n");
		buff.append("	END;											\n");

		try {
			conn = DBHandler.getConnection(dbUrl,dbId,dbPwd);
			if (conn == null) {
				log.error("Connection is NULL !!!");
				throw new Exception("Connection is NULL !!!");
			}

			pstmt = conn.prepareStatement(buff.toString());
			pstmt.setString(1, yesterday);
			pstmt.execute();

			DBHandler.closeDBResource(rs,pstmt);
			DBHandler.closeDBResource(conn);

			batchLogEnd(batch_no, "0", "Success", "N/A", "N", "�������:"+yesterday, null);

		} catch (Exception e) {
			batchLogEnd(batch_no, "-1", "ERROR", "N/A", "Y", "�������:"+yesterday +" ERROR:" + e.toString(), "�������:"+yesterday);
			e.printStackTrace();
			log.error(e.toString());
		} finally {
			try {
				DBHandler.closeDBResource(rs,pstmt);
				DBHandler.closeDBResource(conn);
			} catch (Exception e) {}

			log.debug("===== "+batchName+" END =====");
		}
	}
} // end of class
