package skt.tmall.daemon.escrow;

import skt.tmall.daemon.smsSender.SmsSenderUploader;

public class E41_SmsSenderBatch extends EscrowBaseDaemon {

	/**
	 * @param args
	 */
	public static void main(String[] args) {
		   EscrowBaseDaemon.initSqlMap();
		   E41_SmsSenderBatch batch = new E41_SmsSenderBatch();
		   batch.run();

	}

	public void run() {
		batchName = "SmsSender ��ġ��ȯ";
        batch_no = 2541;


        /* ��ø ���� ����  */
        if (isRunning(batch_no)) {
            String errMsg = "SmsSender �̹� �������Դϴ�:";
            log.error(errMsg);
            batchLogPrint(batch_no, null, null, "-1", "User Define Error", "N/A", "Y", errMsg, errMsg);
            return;
        }

		run_sub();
	}

	public void run_sub() {
		log.debug("===== "+batchName+" START =====");
		batchLogPrint(batch_no, null, null, "-1", "User Define Error", "N/A", "Y", "����", batchName + "����");
    	log.info("SmsSender ����!!!!!!!!!");
        batchLogStart(batch_no,"��ġ ����");
        SmsSenderUploader uploader = null;
        try {
        	uploader = new SmsSenderUploader();
        	uploader.SmsSender();

        	batchLogEnd(batch_no, "0", "Success", "N/A", "N", "ó���Ǽ�:"+0, null);
        	batchLogPrint(batch_no, null, null, "-1", "User Define Error", "N/A", "Y", "����", batchName + "�Ϸ�");
        } catch(Exception e) {

        	e.printStackTrace();
        	log.error(e.toString());

            String err="";
            err += " Err:"+e.toString();
            batchLogEnd(batch_no, "-1", "Error", "N/A", "Y", err, batchName + " ����");
            log.error(e);
		} finally {
			log.debug("===== "+batchName+" END =====");
		}
        log.info(batchName + " ����!!");


	}

	public void sendBatchSMS(String message, String fileName) {
		batchLogPrint(batch_no, null, null, "-1", "User Define Error", "N/A", "Y", message, fileName + "��ó��");
	}

}
