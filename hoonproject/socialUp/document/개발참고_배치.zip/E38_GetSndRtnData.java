package skt.tmall.daemon.escrow;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.util.Date;

import skt.tmall.common.util.EDate;
import skt.tmall.daemon.common.util.DBHandler;


/**
 * �߼�,��ǰ DATA ����
 * @author ggong0819
 *
 */
public class E38_GetSndRtnData extends EscrowBaseDaemon {

	/**
	 * @param args
	 */
	public static void main(String[] args) {
		E38_GetSndRtnData dm = new E38_GetSndRtnData();
		String yesterday = "";
		if (args != null && args.length > 0) {
			yesterday = args[0];
		}
		dm.run(yesterday);
	}

	public void run(String yesterday) {
		batch_no = 2539;
		batchName = "�߼�,��ǰ DATA ����";

		/* ��ø ���� ����  */
		if (isRunning(batch_no)) {
			String errMsg = "�̹� �������Դϴ�:" + yesterday;
			log.error(errMsg);
			batchLogPrint(batch_no, null, null, "-1", "User Define Error", "N/A", "Y", errMsg, errMsg);
			return;
		}

		run_sub(yesterday);
	}

	public void run_sub(String yesterday) {
		log.debug("===== "+batchName+" START =====");

		if (yesterday == null || yesterday.length() != 8) {
			Date dt = EDate.offset(new Date(), 0, 0, -1);
			yesterday = this.dateFormat(dt, "yyyyMMdd");
		}
		String stlDy = "(��������:"+yesterday+")";
		log.debug(stlDy);

		//�̹� ���ν��� �ȿ� ����.
		//batchLogStart(batch_no,stlDy);

		Connection conn = null;
		PreparedStatement pstmt = null;
		ResultSet rs = null;

		StringBuffer buff = new StringBuffer();
		buff.append("	BEGIN 							\n");
		buff.append("		/* �߼�,��ǰ DATA ���� ��ġ (/05.tMallETCProject/src/skt/tmall/daemon/escrow/E38_GetSndRtnData.java) */	 \n");
		buff.append("   	SP_SE_SND_RTN_MONTHLY(TO_DATE(?||'01000000','YYYYMMDDHH24MISS'));	\n");
		buff.append("	END;							\n");

		try {
			conn = DBHandler.getConnection(dbUrl,dbId,dbPwd);
			if (conn == null) {
				log.error("Connection is NULL !!!");
				throw new Exception("Connection is NULL !!!");
			}

			pstmt = conn.prepareStatement(buff.toString());
			pstmt.setString(1, yesterday.substring(0,6));
			pstmt.execute();

			DBHandler.closeDBResource(rs,pstmt);
			DBHandler.closeDBResource(conn);

			//�̹� ���ν��� �ȿ� ����.
			//batchLogEnd(batch_no, "0", "Success", "N/A", "N", "��������:"+yesterday, null);
		} catch (Exception e) {
			String err = "��������:"+yesterday;
			err += " Err:"+e.toString();
			//�̹� ���ν��� �ȿ� ����.
			//batchLogEnd(batch_no, "-1", "Error", "N/A", "Y", err, "[����Ʈ ���� DATA �������] ��������:"+yesterday);
			log.error(err);
		} finally {
			try {
				DBHandler.closeDBResource(rs,pstmt);
				DBHandler.closeDBResource(conn);
			} catch (Exception e) {}

			log.debug("===== "+batchName+" END =====");
		}
	}
} // end of class
