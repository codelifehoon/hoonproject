/**
 * ��õ���� �ֹ� DATA ���� ��ġ
 */
package skt.tmall.daemon.escrow;

import java.io.FileWriter;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.util.Date;

import skt.tmall.common.util.EDate;
import skt.tmall.daemon.common.util.DBHandler;

public class E04_RecommendService extends EscrowBaseDaemon {

	/**
	 * @param args
	 */
	public static void main(String[] args) {
		E04_RecommendService dm = new E04_RecommendService();
		String today = "";
		if (args != null && args.length > 0) {
			today = args[0];
		}
		dm.run(today);
	}

	public void run(String today) {
		batch_no = 2504;
		batchID = "tmba_bo_04";
		batchName = "��õ���� DATA ����";
		
		/* ��ø ���� ����  */
		if (isRunning(batch_no)) {
			String errMsg = "�̹� �������Դϴ�. : " + today;
			log.error(errMsg);
			batchLogPrint(batch_no, null, null, "-1", "User Define Error", "N/A", "Y", errMsg, errMsg);
			return;
		}
		
		run_sub(today);
	}

	public void run_sub(String today) {
		log.debug("===== "+batchName+" START =====");
		
		if (today == null || today.length() != 8) {
			Date dt = EDate.offset(new Date(), 0, 0, -1);
			today = this.dateFormat(dt, "yyyyMMdd");
		}
		
		log.debug("������� : " + today);
		
		batchLogStart(batch_no, "������� : " + today);

		Connection conn = null;
		PreparedStatement pstmt = null;
		ResultSet rs = null;
		
		StringBuffer buff = new StringBuffer();
		buff.append("SELECT /* ��õ���� DATA ���� (����� 2007.11.22) 05.tMallETCProject/src/skt/tmall/daemon/escrow/RecommendService.java */   \n");
		buff.append("	/*+ USE_NL(top, toc, tsp, tor) INDEX(tsp IX1_TR_SLCT_PRD_OPT) INDEX(tor PK_TR_ORD) */                                \n");
		buff.append("				ord_no,                             -- �ֹ���ȣ       �ʼ�                                                                                                         \n");
		buff.append("				ord_prd_seq,                        -- �ֹ���ǰ����   �ʼ�                                                                                                         \n");
		buff.append("				MAX(ord_dt) ord_dt,                 -- �����Ͻ�       �ʼ�                                                                                                         \n");
		buff.append("				MAX(buy_mem_no) buy_mem_no,         -- ����ȸ����ȣ   �ʼ�                                                                                                         \n");
		buff.append("				MAX(mem_yn) mem_yn,                 -- ȸ������       �ʼ�                                                                                                         \n");
		buff.append("				MAX(ord_stl_stat) ord_stl_stat,     -- �ֹ���������   �ʼ�                                                                                                         \n");
		buff.append("				MAX(mall_clf) mall_clf,             -- mall����       reserved                                                                                                     \n");
		buff.append("				MAX(seller_mem_no) seller_mem_no,   -- �Ǹ���ȸ����ȣ �ʼ�                                                                                                         \n");
		buff.append("				MAX(prd_no) prd_no,                 -- ��ǰ��ȣ       �ʼ�                                                                                                         \n");
		buff.append("				MAX(add_prd_no) add_prd_no,         -- �߰���ǰ��ȣ   �ʼ�                                                                                                         \n");
		buff.append("				MAX(ord_qty) ord_qty,               -- �ֹ�����       �ʼ�                                                                                                         \n");
		buff.append("				MAX(sel_prc) sel_prc,               -- �ǸŰ�         reserved                                                                                                     \n");
		buff.append("				MAX(buy_prc) buy_prc,               -- ���Ű�         �ʼ�                                                                                                         \n");
		buff.append("				MAX(prd_clf_cd) prd_clf_cd,         -- �ǸŹ���ڵ�   reserved                                                                                                     \n");
		buff.append("		        MAX(dlv_cst_stl_typ) dlv_cst_stl_typ, --	��ۺ� ���� ���� reserved                                                                                              \n");
		buff.append("		        MAX(dlv_cst) dlv_cst,	              -- ��ۺ� reserved                                                                                                           \n");
		buff.append("				'' AS opt_type1,                      -- �ֹ���ǰ�ɼǱ���1 reserved                                                                                                \n");
		buff.append("		        MAX(case when rnum = 1 then ' '||opt_value1 end) opt1, -- �ֹ���ǰ�ɼǰ�1 reserved                                                                                 \n");
		buff.append("				'' AS opt_type2,                      -- �ֹ���ǰ�ɼǱ���2 reserved                                                                                                \n");
		buff.append("		        MAX(case when rnum = 1 then ' '||opt_value2 end) opt2, -- �ֹ���ǰ�ɼǰ�2 reserved                                                                                 \n");
		buff.append("				'' AS opt_type3,                      -- �ֹ���ǰ�ɼǱ���3 reserved                                                                                                \n");
		buff.append("		        MAX(case when rnum = 1 then ' '||opt_value3 end) opt3, -- �ֹ���ǰ�ɼǰ�3 reserved                                                                                 \n");
		buff.append("			    MAX(std_ctgr_no) AS std_ctgr_no,	  -- ǥ��ī�װ�����ȣ reserved                                                                                                 \n");
		buff.append("		 	    MAX(std_ctgr_cd) AS std_ctgr_cd,	  -- ǥ��ī�װ����ڵ� �ʼ�                                                                                                     \n");
		buff.append("			    MAX(disp_ctgr_no) AS disp_ctgr_no,    -- ����ī�װ�����ȣ reserved                                                                                                 \n");
		buff.append("			    MAX(disp_ctgr_cd) AS disp_ctgr_cd,    -- ����ī�װ����ڵ� �ʼ�                                                                                                     \n");
		buff.append("			    MAX(svc_cupn_crtf_no) svc_cupn_crtf_no,	-- ��������������ȣ reserved                                                                                             \n");
		buff.append("			    '' AS co_path_cd,	                  -- ���ް���ڵ� reserved                                                                                                     \n");
		buff.append("			    '' AS co_path_dtls_cd,	              -- ���ް�λ��ڵ� reserved                                                                                                 \n");
		buff.append("			    MAX(ord_path_clf) ord_path_clf        -- �ֹ���α��� reserved                                                                                                     \n");
		buff.append("		FROM (                                                                                                                                                                     \n");
		buff.append("				SELECT                                                                                                                                                             \n");
		buff.append("						row_number() over(PARTITION BY top.ord_no, top.ord_prd_seq ORDER BY top.ord_no, top.ord_prd_seq) rnum,                                                     \n");
		buff.append("						top.ord_no,          -- �ֹ���ȣ       �ʼ�                                                                                                                \n");
		buff.append("						top.ord_prd_seq,     -- �ֹ���ǰ����   �ʼ�                                                                                                                \n");
		buff.append("						to_char(tor.ord_dt, 'YYYY-MM-DD HH24:MI:SS') ord_dt,  -- �����Ͻ� �ʼ�                                                                                     \n");
		buff.append("						tor.buy_mem_no,      -- ����ȸ����ȣ   �ʼ�                                                                                                                \n");
		buff.append("						tor.mem_yn,          -- ȸ������       �ʼ�                                                                                                                \n");
		buff.append("						tor.ord_stl_stat,    -- �ֹ���������   �ʼ�                                                                                                                \n");
		buff.append("						tor.mall_clf,        -- mall����       reserved                                                                                                            \n");
		buff.append("						top.seller_mem_no,   -- �Ǹ���ȸ����ȣ �ʼ�                                                                                                                \n");
		buff.append("						top.prd_no,          -- ��ǰ��ȣ       �ʼ�                                                                                                                \n");
		buff.append("						top.add_prd_no,      -- �߰���ǰ��ȣ   �ʼ�                                                                                                                \n");
		buff.append("						top.ord_qty,         -- �ֹ�����       �ʼ�                                                                                                                \n");
		buff.append("						top.sel_prc,         -- �ǸŰ�         reserved                                                                                                            \n");
		buff.append("						top.buy_prc,         -- ���Ű�         �ʼ�                                                                                                                \n");
		buff.append("						top.prd_clf_cd,      -- �ǸŹ���ڵ�   reserved                                                                                                            \n");
		buff.append("				        toc.dlv_cst_stl_typ, --	��ۺ� ���� ���� reserved                                                                                                          \n");
		buff.append("				        toc.dlv_cst,	     -- ��ۺ� reserved                                                                                                                    \n");
		buff.append("				        lead(tsp.slct_prd_opt_nm,0) over(PARTITION BY top.ord_no, top.ord_prd_seq ORDER BY top.ord_no, top.ord_prd_seq) opt_value1, -- �ֹ���ǰ�ɼǰ�1 reserved    \n");
		buff.append("				        lead(tsp.slct_prd_opt_nm,1) over(PARTITION BY top.ord_no, top.ord_prd_seq ORDER BY top.ord_no, top.ord_prd_seq) opt_value2, -- �ֹ���ǰ�ɼǰ�2 reserved    \n");
		buff.append("				        lead(tsp.slct_prd_opt_nm,2) over(PARTITION BY top.ord_no, top.ord_prd_seq ORDER BY top.ord_no, top.ord_prd_seq) opt_value3, -- �ֹ���ǰ�ɼǰ�3 reserved    \n");
		buff.append("					    top.std_ctgr_no,	               -- ǥ��ī�װ�����ȣ reserved                                                                                            \n");
		buff.append("					    ( SELECT std_ctgr_cd FROM pd_std_ctgr A                                                                                                                    \n");
		buff.append("						  WHERE  A.std_ctgr_no = top.std_ctgr_no                                                                                                                   \n");
		buff.append("						) AS std_ctgr_cd,	               -- ǥ��ī�װ����ڵ� �ʼ�                                                                                                \n");
		buff.append("					    top.disp_ctgr_no,                  -- ����ī�װ�����ȣ reserved                                                                                            \n");
		buff.append("					    ( SELECT disp_ctgr_cd FROM dp_disp_ctgr A                                                                                                                  \n");
		buff.append("						  WHERE  A.disp_ctgr_no = top.disp_ctgr_no                                                                                                                 \n");
		buff.append("						) AS disp_ctgr_cd,                 -- ����ī�װ����ڵ� �ʼ�                                                                                                \n");
		buff.append("					    top.svc_cupn_crtf_no,	           -- ��������������ȣ reserved                                                                                          \n");
		buff.append("					    top.ord_path_clf	               -- �ֹ���α��� reserved                                                                                                \n");
		buff.append("				FROM tr_ord tor,                                                                                                                                                   \n");
		buff.append("				     tr_ord_prd top,                                                                                                                                               \n");
		buff.append("					 tr_ord_clm_dlv_dtls toc,                                                                                                                                      \n");
		buff.append("					 tr_slct_prd_opt tsp                                                                                                                                           \n");
		buff.append("				WHERE tor.ord_no = top.ord_no                                                                                                                                      \n");
		buff.append("				AND   top.dlv_no = toc.dlv_no                                                                                                                                      \n");
		buff.append("				AND   top.ord_no       = tsp.slct_prd_seq(+) -- ���û�ǰ�Ϸù�ȣ                                                                                                   \n");
		buff.append("				AND   top.ord_prd_seq  = tsp.ord_no(+)  -- �ֹ���ǰ����                                                                                                            \n");
//		buff.append("				AND   tor.ord_stl_stat    = '04' -- �ֹ��������� (�����Ϸ�)                                                                                                        \n");
//		buff.append("				AND   tor.ord_stl_stat_dt >= TO_DATE(?||'000000','YYYYMMDDHH24MISS')                                                                   \n");
//		buff.append("				AND   tor.ord_stl_stat_dt <= TO_DATE(?||'235959','YYYYMMDDHH24MISS')                                                                   \n");
		/* 2008-01-28 �߰� ���� */
		buff.append("				AND   top.ord_no >= to_number(?||'0000000')                                                                   \n");
		buff.append("				AND   top.ord_no <= to_number(?||'9999999')                                                                   \n");
		/* 2008-01-28 �߰� �Ϸ� */
		buff.append("				AND   top.ord_dt >= TO_DATE(?||'000000','YYYYMMDDHH24MISS')                                                                   \n");
		buff.append("				AND   top.ord_dt <= TO_DATE(?||'235959','YYYYMMDDHH24MISS')                                                                   \n");
		buff.append("				AND   tsp.slct_prd_opt_clf(+) = '01' -- ���û�ǰ�ɼǱ���(�ֹ���ǰ)                                                                                                 \n");
		buff.append("		)                                                                                                                                                                          \n");
		buff.append("		GROUP BY ord_no,                                                                                                                                                           \n");
		buff.append("				 ord_prd_seq                                                                                                                                                       \n");

		FileWriter fw = null;

		try {
			conn = DBHandler.getConnection(dbUrl,dbId,dbPwd);
			if (conn == null) {
				log.error("Connection is NULL !!!");
				throw new Exception("Connection is NULL !!!");
			}
			
			String dir = this.prop.getProperty("rec_ap.dir");
			String fileName = dir + "/tmall_ord_" + today.substring(2) + ".dat";
			
			String[] fd = {
				 "ord_no"
				,"ord_prd_seq"
				,"ord_dt"
				,"buy_mem_no"
				,"mem_yn"
				,"ord_stl_stat"
				,"mall_clf"
				,"seller_mem_no"
				,"prd_no"
				,"add_prd_no"
				,"ord_qty"
				,"sel_prc"
				,"buy_prc"
				,"prd_clf_cd"
				,"dlv_cst_stl_typ"
				,"dlv_cst"
				,"opt_type1"
				,"opt1"
				,"opt_type2"
				,"opt2"
				,"opt_type3"
				,"opt3"
				,"std_ctgr_no"
				,"std_ctgr_cd"
				,"disp_ctgr_no"
				,"disp_ctgr_cd"
				,"svc_cupn_crtf_no"
				,"co_path_cd"
				,"co_path_dtls_cd"
				,"ord_path_clf"
			};

			/* ������� */
			StringBuffer result = new StringBuffer();
			for (int i=0; i<fd.length; i++) {
				if (i > 0) {
					result.append("	");
				}
				result.append(fd[i]);
			}
			result.append(LF);

			fw = new FileWriter(fileName,false);
			fw.write(result.toString());

			pstmt = conn.prepareStatement(buff.toString());
            pstmt.setString(1, today);
            pstmt.setString(2, today);
            
            /* 2008-01-28 �߰� ���� */
            pstmt.setString(3, today);
            pstmt.setString(4, today);
            /* 2008-01-28 �߰� �Ϸ� */
            
            long cnt = 0;

			rs = pstmt.executeQuery();
			while( rs.next() ) {
				/* ������ ���� */
				result = new StringBuffer();
				for (int i=0; i<fd.length; i++) {
					if (i > 0) {
						result.append("	");
					}
					String str = rs.getString(fd[i]);
					if (str == null)
						str = "";
					result.append(str);
				}
				result.append(LF);
				
				fw.write(result.toString());
				cnt++;
			}
			fw.close();

			DBHandler.closeDBResource(rs,pstmt);
			DBHandler.closeDBResource(conn);

			/* OK File ����  */
			String okFileName = dir + "/tmall_ord_" + today.substring(2) + "_ok.txt";
			fw = new FileWriter(okFileName,false);
			fw.close();
			
			log.debug("ó���Ǽ� : "+cnt);
			log.debug("file : " + fileName);
			log.debug("okFile : " + okFileName);
			
			String msg = "";
			msg += " �������:" + today;
			msg += " ó���Ǽ�:" + cnt;
			
			batchLogEnd(batch_no, "0", "Success", "N/A", "N", msg, null);
		} catch (Exception e) {
			batchLogEnd(batch_no, "-1", "Error", "N/A", "Y", e.toString(), "��õAP����:"+today);
			log.error(e.toString());
		} finally {
			try {
				DBHandler.closeDBResource(rs,pstmt);
				DBHandler.closeDBResource(conn);
			} catch (Exception e) {}

			try {
				if (fw != null) {
					fw.close();
				}
			} catch (Exception e) {}

			log.debug("===== "+batchName+" ���� END =====");
		}
	}
} // end of class
