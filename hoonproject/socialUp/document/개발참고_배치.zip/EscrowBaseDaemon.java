package skt.tmall.daemon.escrow;

import java.io.File;
import java.io.FileWriter;
import java.io.IOException;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.Properties;

import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;
import org.apache.log4j.xml.DOMConfigurator;

import skt.tmall.common.util.CmnUtil;
import skt.tmall.common.util.EDate;
import skt.tmall.daemon.common.util.BatchAppLog;
import skt.tmall.daemon.common.util.DBHandler;

import com.ibatis.common.resources.Resources;

/**
 * Java ��ġ�� ���� �θ�Ŭ����
 * @author ZZ07237
 * @version 0.1
 */
public class EscrowBaseDaemon {
	public static final String CR = "\r";
	public static final String LF = "\n";
	public static final String CRLF = "\r\n";

	public static final String HOST_DEV = "dev";
	public static final String HOST_LOCAL = "local";
	public static final String HOST_STG = "stg";
	public static final String HOST_REAL = "tmbatch";

	private final String CONFIG_LOCAL = "skt/tmall/daemon/escrow/config/escrow-batch-config-local.properties";
	private final String CONFIG_DEV = "skt/tmall/daemon/escrow/config/escrow-batch-config-dev.properties";
	private final String CONFIG_STG = "skt/tmall/daemon/escrow/config/escrow-batch-config-stg.properties";
	private final String CONFIG_REAL = "skt/tmall/daemon/escrow/config/escrow-batch-config-real.properties";

	protected Log log = LogFactory.getLog(EscrowBaseDaemon.class);
	protected Properties prop = null;

	protected String dbDriver = null;
	protected String dbUrl = null;
	protected String dbId = null;
	protected String dbPwd = null;
	protected String sqlMapConfigList = null;
	protected String batchName = "";
	protected String batchID = "";
	protected long	batch_no = 0;

	protected Date bgnDt = EDate.today();
	protected Date endDt = EDate.today();

	public EscrowBaseDaemon() {
		try {
			// log4j
			DOMConfigurator.configure(Resources.getResourceURL("skt/tmall/daemon/escrow/config/escrow-batch-log4j.xml"));

			String configFile = CONFIG_REAL;

			String hostName = System.getProperty("host.name", HOST_REAL);

			if 		(HOST_LOCAL.equals(hostName)) 	configFile = CONFIG_LOCAL;
			else if (HOST_DEV.equals(hostName)) 	configFile = CONFIG_DEV;
			else if (HOST_STG.equals(hostName)) 	configFile = CONFIG_STG;
			else if (HOST_REAL.equals(hostName))	configFile = CONFIG_REAL;

			log.info("----------------------------");
			log.info("hostname : "+hostName);
			log.info("configFile : "+configFile);

			/* Properties �ʱ�ȭ */
			prop = new Properties();
			prop.load(Resources.getResourceAsStream(configFile));

			dbDriver	= prop.getProperty("tmall.sqlMap.driver");
			dbUrl 		= prop.getProperty("tmall.sqlMap.url");
			dbId 		= prop.getProperty("tmall.sqlMap.username");
			dbPwd		= prop.getProperty("tmall.sqlMap.password");

			DBHandler.initDriver(dbDriver);

			log.info("----------------------------");
			log.info("dbDriver : " +dbDriver);
			log.info("dbUrl : " +dbUrl);
			log.info("dbId : " +dbId);
			log.info("dbPwd : " +dbPwd);
			log.info("----------------------------");

		} catch (Exception e) {
			System.out.println(e.toString());
		}
	}

	public static void initSqlMap() {
		String hostName = System.getProperty("host.name", HOST_REAL);

		String sqlMapFile = "skt/tmall/daemon/escrow/config/sql-map-config-list-real.xml";

		if 		(HOST_LOCAL.equals(hostName)) 	sqlMapFile = "skt/tmall/daemon/escrow/config/sql-map-config-list-local.xml";
		else if (HOST_DEV.equals(hostName)) 	sqlMapFile = "skt/tmall/daemon/escrow/config/sql-map-config-list-dev.xml";
		else if (HOST_STG.equals(hostName)) 	sqlMapFile = "skt/tmall/daemon/escrow/config/sql-map-config-list-stg.xml";
		else if (HOST_REAL.equals(hostName))	sqlMapFile = "skt/tmall/daemon/escrow/config/sql-map-config-list-real.xml";

		DBHandler.initSqlMap(sqlMapFile);
		System.out.println("sqlMapFile = " + sqlMapFile);
	}

	protected void writeFile(String fileName, StringBuffer data) {
		FileWriter fw = null;
		try {
			fw = new FileWriter(fileName,false);
			fw.write(data.toString());
			fw.close();
		} catch (IOException e) {
			e.printStackTrace();
		}
	}

	protected String dateFormat(Date inDate, String format) {
		if (inDate == null)
			return "";

		if (format == null || format.length() <= 0) {
			format = "yyyyMMddHHmmss";
		}

		SimpleDateFormat SDF = new SimpleDateFormat(format);
		return SDF.format(inDate);
	}

	protected boolean isFileExist(String fileName) {
		File f = new File(fileName);
		if (f.isFile()) {
			return true;
		}

		return false;
	}

	protected void createFile(String fileName) {
		createFile(fileName,null);
	}

	protected void createFile(String fileName, String str) {
		try {
			FileWriter fw = new FileWriter(fileName,false);
			if (!CmnUtil.isEmpty(str)) {
				fw.write(str);
			}
			fw.close();
			log.debug("������ �����մϴ�. : " + fileName);
		} catch (Exception e) {
		}
	}

	protected void deleteFile(String fileName) {
		File f = new File(fileName);
		if (f.isFile()) {
			log.debug("������ �����մϴ�. : " + fileName);
			f.delete();
		}
	}

	/**
	 * ��ġ �α� ����ϱ�
	 * @param batchNo ��ġ��ȣ
	 * @param bgnDt �����Ͻ�
	 * @param endDt �����Ͻ�
	 * @param sqlCd SQLCODE
	 * @param sqlMsg SQLERRM
	 * @param haltPos �߻���ġ
	 * @param errYn ��������
	 * @param errMsg �����޽���
	 * @param smsMsg �����߻��� ������ SMS �޽���
	 */
	public void batchLogPrint(long batchNo, Date bgnDt, Date endDt, String sqlCd, String sqlMsg, String haltPos, String errYn, String errMsg, String smsMsg) {
		BatchAppLog appLog = new BatchAppLog(dbUrl,dbId,dbPwd);
		appLog.LogPrint(batchNo, bgnDt, endDt, sqlCd, sqlMsg, haltPos, errYn, errMsg, smsMsg);
	}

	public void batchLogEnd(long batchNo, String sqlCd, String sqlMsg, String haltPos, String errYn, String errMsg, String smsMsg) {
		BatchAppLog appLog = new BatchAppLog(dbUrl,dbId,dbPwd);
		appLog.LogEnd(batchNo, sqlCd, sqlMsg, haltPos, errYn, errMsg, smsMsg);
	}

	public void batchLogStart(long batchNo, String errMsg) {
		BatchAppLog appLog = new BatchAppLog(dbUrl,dbId,dbPwd);
		appLog.LogStart(batchNo, errMsg);
	}

	public boolean isRunning(long batchNo) {
		BatchAppLog appLog = new BatchAppLog(dbUrl,dbId,dbPwd);
		return appLog.isRunning(batchNo);
	}

	protected void batchLog(String batID, String succYN, String logText) {

		if (CmnUtil.isEmpty(batID)) {
			return;
		}

		if (CmnUtil.isEmpty(succYN)) {
			return;
		}

		if (logText == null) {
			logText = "";
		}

		Connection conn = null;
		PreparedStatement pstmt = null;
		ResultSet rs = null;

		StringBuffer buff = new StringBuffer();
		buff.append("  insert into SY_BATCH_LOG(batch_id, create_dy, create_dt, succ_yn, log)	");
		buff.append("  values (?, to_char(sysdate,'YYYYMMDDHH24MISS'), sysdate, ?, ?)			");

		try {
			conn = DBHandler.getConnection(dbUrl,dbId,dbPwd);
			if (conn == null) {
				log.error("Connection is NULL !!!");
				return;
			}

			pstmt = conn.prepareStatement(buff.toString());
			pstmt.setString(1, batID);
			pstmt.setString(2, succYN);
			pstmt.setString(3, logText);
			pstmt.execute();

			conn.commit();

			DBHandler.closeDBResource(rs,pstmt);
			DBHandler.closeDBResource(conn);
		} catch (Exception e) {
			log.error(e.toString());
		} finally {
			try {
				DBHandler.closeDBResource(rs,pstmt);
				DBHandler.closeDBResource(conn);
			} catch (Exception e) {}
		}
	}


	/**
	 * @param batID			: Ȯ���� ��ġ��ȣ
	 * @param intervalMin	: Ȯ���� ��������ð� ���� sysdate - intervalMin(��)
	 */
	protected String batchLogLastRunDt(long batID, long daemonchkInterval) throws Exception
	{


		String lastRunDt = "";
		Connection conn = null;
		PreparedStatement pstmt = null;
		ResultSet rs = null;

		StringBuffer buff = new StringBuffer();
		buff.append(" select  to_char(max(CREATE_DT),'YYYYMMDDHH24MISS') as CREATE_DT  from SY_BATCH_APP_LOG where batch_no in (?)  and CREATE_DT > sysdate - 1/24/60 * ?	");
		log.debug("batchLogLastRunDt :"   + buff);

		try {
			conn = DBHandler.getConnection(dbUrl,dbId,dbPwd);
			if (conn == null)
			{
				log.error("Connection is NULL !!!");
				return lastRunDt;
			}

			pstmt = conn.prepareStatement(buff.toString());
			pstmt.setLong(1, batID);
			pstmt.setLong(2, daemonchkInterval);
			rs = pstmt.executeQuery();

			if (rs != null)
			{
				while (rs.next())
				{
					lastRunDt = rs.getString("CREATE_DT");
				}
			}

			conn.commit();
			DBHandler.closeDBResource(rs,pstmt);
			DBHandler.closeDBResource(conn);
		} catch (Exception e) {
			log.error(e.toString());
			throw e;
		} finally {
			try {
				DBHandler.closeDBResource(rs,pstmt);
				DBHandler.closeDBResource(conn);
			} catch (Exception e) {}
		}

		return lastRunDt;
	}


} // end of class
