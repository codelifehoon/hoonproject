package skt.tmall.daemon.escrow;

import skt.tmall.bdt.transfer.ChannelType;
import skt.tmall.bdt.transfer.InterfaceData;
import skt.tmall.bdt.transfer.mms.MmsResponseBO;
import skt.tmall.bdt.transfer.ngcp.NgcpRequestBO;
import skt.tmall.bdt.transfer.ngcp.NgcpRequestType;
import skt.tmall.bdt.transfer.ngcp.NgcpResponseBO;
import skt.tmall.interfacehub.InterfaceHubFactory;
import skt.tmall.interfacehub.client.core.InterfaceHub;
import skt.tmall.interfacehub.exception.InterfaceHubException;
import skt.tmall.interfacehub.exception.ValidationException;

public class UapsTest {

	/**
	 * @param args
	 */
	public static void main(String[] args) {
		InterfaceHubFactory factory = InterfaceHubFactory.getInsatnce();
		InterfaceHub hub = factory.createChannelHub();
        InterfaceData data = new InterfaceData();

        NgcpResponseBO ngcpResponseBO = null;
        MmsResponseBO mmsResponseBO = null;

        //1. UAPROFILE (SKT, MMS, NGB)
        NgcpRequestBO ngcpRequestBO = new NgcpRequestBO();
        ngcpRequestBO.setRequestType(NgcpRequestType.UAPROFILE);
        ngcpRequestBO.setPrtblTlphnNo("0167780462".replaceAll("-", "").replaceAll(" ", ""));
        data.setRequestData(ngcpRequestBO, ChannelType.NGCP);

        try {
			ngcpResponseBO = (NgcpResponseBO)hub.process(data);
		} catch (InterfaceHubException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (ValidationException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}


        if (ngcpResponseBO.isSuccess() == false)
    	{
     		StringBuffer sb4 = new StringBuffer();
     		sb4.append("\nUAPROFILE.PhoneNumber  : ["+ngcpRequestBO.getPrtblTlphnNo()+"]");
    		sb4.append("\nUAPROFILE.Result : ["+ngcpResponseBO.isSuccess()+"]");
    		sb4.append("\nUAPROFILE.getResultCode : ["+ngcpResponseBO.getResultCode()+"]");
    		sb4.append("\nUAPROFILE.getResultMsg : ["+ngcpResponseBO.getResultMsg()+"]");
    		System.out.println(sb4.toString());
    	} else {
    		StringBuffer sb3 = new StringBuffer();
    		sb3.append("\nSKT : " + ngcpResponseBO.isSuccess());
    		sb3.append("\nUAPROFILE.PhoneNumber  : ["+ngcpRequestBO.getPrtblTlphnNo()+"]");
    		sb3.append("\nUAPROFILE.getModel : ["+ngcpResponseBO.getModel()+"]");
    		sb3.append("\nUAPROFILE.getBrowserVersion : ["+ngcpResponseBO.getBrowserVersion()+"]");
    		sb3.append("\nUAPROFILE.getMmsVersion : ["+ngcpResponseBO.getMmsVersion()+"]");
    		sb3.append("\nUAPROFILE.ScreenSize:"+ngcpResponseBO.getScreenSize());
    		sb3.append("\nUAPROFILE.BrowserName:"+ngcpResponseBO.getBrowserName());
    		sb3.append("\nUAPROFILE.BrowserVersion:"+ngcpResponseBO.getBrowserVersion());
    		sb3.append("\nUAPROFILE.MmsVersion:"+ngcpResponseBO.getMmsVersion());
    		sb3.append("\nUAPROFILE.SmilPresentationSize:"+ngcpResponseBO.getSmilPresentationSize());
    		System.out.println(sb3.toString());
    	}


	}

}
