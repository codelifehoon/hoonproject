package skt.tmall.daemon.escrow;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.SQLException;



import skt.tmall.common.TmallException;
import skt.tmall.daemon.common.util.DBHandler;


public class E62_Message_SolDB_Into extends EscrowBaseDaemon {


    private boolean debugMode = false;

    public E62_Message_SolDB_Into() throws Exception {
        batchName = "������ SMS�� ��ȯ";
        batch_no = 2562;
        int executeTotal = 0;
        try {


            super.initSqlMap();

            log.info("������ SMS�� ��ȯ !!!!!!!!!");
            if (isRunning(batch_no)) {
                String errMsg = "������ SMS�� ��ȯ �̹� �������Դϴ�:";
                log.error(errMsg);
                batchLogPrint(batch_no, null, null, "-1", "User Define Error", "N/A", "Y", errMsg, errMsg);
                return;
            }
            batchLogStart(batch_no,"��ġ ����");
            executeTotal = summeryBatch();
            batchLogEnd(batch_no, "0", "Success", "N/A", "N", "ó���Ǽ�:"+executeTotal, null);

        } catch(Exception e) {
        	batchLogEnd(batch_no, "-1", "Error", "N/A", "Y", e.toString(), batchName + " ����");
        	log.error(batchName + " FATAL : SqlMapLoader.init()");
            throw new TmallException(e.toString());
        } finally {
        	log.debug("===== "+batchName+" END ===�Ǽ� : " + executeTotal);
        }

    }

    /**
     * @param args
     * @throws Exception
     */
    public static void main( String[] args ) throws Exception {

    	E62_Message_SolDB_Into selelrEscrow = new E62_Message_SolDB_Into();
    }



    /**
     * seller_sell_summary�� ���̺��� truncate �ϰ�, �ش絥��Ÿ�� <br>
     * �������� insert ���� ��
     * @throws Exception
     */
    private int summeryBatch() throws Exception {
        Connection conn = null;
        int insertSum = 0;
        int deleteSum = 0;
        try {
            conn = DBHandler.getConnection(dbUrl,dbId,dbPwd);
            conn.setAutoCommit(false);

              insertSum = insertMessageSoldDB(conn);
              deleteSum = deleteMessageTmall(conn);

              if(insertSum == deleteSum) {
            	  conn.commit();
              } else {
            	  conn.rollback();
              }

        } catch (SQLException e) {
            conn.rollback();
            log.error(e.toString());
            throw new SQLException(e.toString());
        } finally {
            conn.setAutoCommit(true);
            DBHandler.closeDBResource(conn);
            //log.debug("===== "+batchName+" ���� END =====");
        }
        return deleteSum;
    }

    private int deleteMessageTmall(Connection conn) throws SQLException {
        PreparedStatement pstmt = null;
        String query = null;
        int deleteCnt = 0;

        try {
            query = this.getUpdateSQL().toString();
            pstmt = conn.prepareStatement(query.toString());
            deleteCnt = pstmt.executeUpdate();
        } finally {
            pstmt.close();
        }
        return deleteCnt;

    }

    private int insertMessageSoldDB(Connection conn) throws SQLException {
        PreparedStatement pstmt = null;
        String query = null;
        int insertCnt = 0;

        try {
            query = this.getInsertBatchSQL(debugMode).toString();
            pstmt = conn.prepareStatement(query.toString());
            insertCnt = pstmt.executeUpdate();
        } finally {
            pstmt.close();
        }

        return insertCnt;
    }

    private StringBuilder getInsertBatchSQL(boolean debugMode) {

    	final StringBuilder selectSQL = new StringBuilder();
		      selectSQL.append("  INSERT INTO  MESSAGE@DEVSOLDB_LINK ");
		      selectSQL.append("  	SELECT * FROM MESSAGE  WHERE MSGHEADERTYPE='7' AND MSGSTATUS='6' AND MSGTOBELOG = '8' ");
		      selectSQL.append("    AND TID IN (1052,1027,1054,1037)													  ");
if(debugMode) selectSQL.append("    AND MSGSENDTO = '01046187974'                                                         ");
	return selectSQL;
    }


    private StringBuilder getUpdateSQL() {
    	final StringBuilder updateSQL = new StringBuilder();
	       	  updateSQL.append(" DELETE MESSAGE WHERE MSGHEADERTYPE='7' AND MSGSTATUS='6' AND MSGTOBELOG = '8' ");
	       	  updateSQL.append(" AND TID IN (1052,1027,1054,1037) 	   										   ");
if(debugMode) updateSQL.append(" AND MSGSENDTO = '01046187974'                                                 ");
	return updateSQL;
    }



}
