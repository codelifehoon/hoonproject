/**
 * �̺�Ʈ ���� ������ ���� ��ġ
 * ���� �̺�Ʈ ��Ʈ���� F/U ���ּ���.
 */
package skt.tmall.daemon.escrow;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.util.Date;

import skt.tmall.common.util.EDate;
import skt.tmall.daemon.common.util.DBHandler;

public class E30_BuyKingEvent extends EscrowBaseDaemon {

	/**
	 * @param args
	 */
	public static void main(String[] args) {
		E30_BuyKingEvent dm = new E30_BuyKingEvent();
		dm.run(args);
	}
	public void run(String[] args) {

		if (args == null || args.length < 1) {
			log.error("�Ķ���Ͱ� �ùٸ��� �ʽ��ϴ�.");
			return;
		}

		// ���ſ� �̺�Ʈ
		if (!"".equals(args[0])) {
			run_090212_ranking(args);
			return;
		}

		log.error("ó���� �̺�Ʈ�� ã�� ���߽��ϴ�.");
	}
	/**
	 * ���ſ� ��ŷ ������ ����
	 * @param today
	 */
	public void run_090212_ranking(String[] args) {

		String today = "";
		String guBun = "";
		if (args != null && args.length > 1) {
			today = args[1];
		}

		batchName = "���ſ� �̺�Ʈ";
		log.debug("===== "+batchName+" START =====");

		if (today == null || today.length() != 10) {
			Date dt = EDate.offset(new Date(), 0, 0, 0);
			today = this.dateFormat(dt, "yyyyMMddHH");
		}

		log.error("������� : " + today);
		log.error("������� : " + today.substring(8));

		// �Ϸ��ѹ�
		// ���� ��������, ��ü �������� (���� 1�ÿ� ����ɶ�)
		boolean isOnce = false;
		if ( "090212_ranking_day".equals(args[0]) && "00".equals(today.substring(8)) )
		{
		    isOnce = true;
		    guBun = "D";
		}
		else if ( "090212_ranking_all".equals(args[0]) && "00".equals(today.substring(8)) )
		{
			isOnce = true;
		    guBun = "A";
		}
		else if ( "090212_ranking_all".equals(args[0]) )
		{
			isOnce = false;
		    guBun = "A";
		}
		else if ( "global_ranking_all".equals(args[0]) && "00".equals(today.substring(8)) )
		{
			isOnce = true;
		    guBun = "B";
		}
		else if ( "global_ranking_all".equals(args[0]) )
		{
			isOnce = false;
		    guBun = "B";
		}
		else
		{
			isOnce = false;
            guBun = "D";
		}

		Connection conn = null;
		PreparedStatement pstmt = null;
		ResultSet rs = null;

		StringBuffer buff = new StringBuffer();
        /**
         * �ش����� ������ ����
         */
        buff.append(" delete from mt_evnt_090212_buy_rank    \n ");
        buff.append(" where REG_YMDH = ? and GUBUN = ?       \n ");

        try {
            conn = DBHandler.getConnection(dbUrl,dbId,dbPwd);
            if (conn == null) {
                log.error("Connection is NULL !!!");
                throw new Exception("Connection is NULL !!!");
            }

            pstmt = conn.prepareStatement(buff.toString());
            pstmt.setString(1, today);
            pstmt.setString(2, guBun);
            pstmt.execute();

            conn.commit();

            DBHandler.closeDBResource(rs,pstmt);
            DBHandler.closeDBResource(conn);

        } catch (Exception e) {
            String err = "�������:"+today;
            err += " Err:"+e.toString();
            log.error(err);
            e.printStackTrace();
            return;
        } finally {
            try {
                DBHandler.closeDBResource(rs,pstmt);
                DBHandler.closeDBResource(conn);
            } catch (Exception e) {}
        }

		/**
		 * ��ŷ ����
		 */
		conn = null;
		pstmt = null;
		rs = null;

		buff.delete(0, buff.length());
		buff.append(" insert into mt_evnt_090212_buy_rank                                                                                                                                                           \n");
		buff.append(" select                                                                                                                                                                                        \n");
        if ( isOnce )
        {
            buff.append("       to_char(sysdate-1, 'yyyymmdd')||'24'                                                                                                                                                \n");
        }
        else
        {
            buff.append("       to_char(sysdate, 'yyyymmddhh24')                                                                                                                                                    \n");
        }
		buff.append("       ,?                                                                                                                                                                                      \n");
		buff.append("       ,rnk                                                                                                                                                                                    \n");
		buff.append("       ,buy_mem_no                                                                                                                                                                             \n");
		buff.append("       ,tot_amt                                                                                                                                                                                \n");
		buff.append(" from (                                                                                                                                                                                        \n");
		buff.append(" select                                                                                                                                                                                        \n");
		buff.append("        buy_mem_no ,                                                                                                                                                                           \n");
		buff.append("        mem_id,                                                                                                                                                                                \n");
		buff.append("        create_dt ,                                                                                                                                                                            \n");
		buff.append("        sum(aa+bb+cc+dd) tot_amt                                                                                                                                                               \n");
		buff.append("        ,row_number() over (order by sum(aa+bb+cc+dd) desc, create_dt) rnk                                                                                                                     \n");
		buff.append(" from   (select                                                                                                                                                                                \n");
		buff.append("                buy_mem_no ,                                                                                                                                                                   \n");
		buff.append("                mem_id,                                                                                                                                                                        \n");
		buff.append("                create_dt ,                                                                                                                                                                    \n");
		if ( "B".equals(guBun) )
		{
		buff.append("                        case                                                                                                                                                                   \n");
		buff.append("                          when tot_amt < 100000 then tot_amt                                                                                                                                   \n");
		buff.append("                          else 0                                                                                                                                                               \n");
		buff.append("                        end aa ,                                                                                                                                                               \n");
		buff.append("                        case                                                                                                                                                                   \n");
		buff.append("                          when tot_amt between 100000 and 299990 then round(tot_amt)                                                                                                       \n");
		buff.append("                          else 0                                                                                                                                                               \n");
		buff.append("                        end bb ,                                                                                                                                                               \n");
		buff.append("                        case                                                                                                                                                                   \n");
		buff.append("                          when tot_amt between 300000 and 999990 then round(tot_amt)                                                                                                       \n");
		buff.append("                          else 0                                                                                                                                                               \n");
		buff.append("                        end cc ,                                                                                                                                                               \n");
		buff.append("                        case                                                                                                                                                                   \n");
		buff.append("                          when tot_amt >= 1000000 then round(tot_amt)                                                                                                                      \n");
		buff.append("                          else 0                                                                                                                                                               \n");
		buff.append("                        end dd                                                                                                                                                                 \n");
		}
		else
		{
		buff.append("                prd_no ,                                                                                                                                                                       \n");
		buff.append("                        case                                                                                                                                                                   \n");
		buff.append("                          when tot_amt < 100000 then tot_amt                                                                                                                                   \n");
		buff.append("                          else 0                                                                                                                                                               \n");
		buff.append("                        end aa ,                                                                                                                                                               \n");
		buff.append("                        case                                                                                                                                                                   \n");
		buff.append("                          when tot_amt between 100000 and 299990 then round(tot_amt*0.5)                                                                                                       \n");
		buff.append("                          else 0                                                                                                                                                               \n");
		buff.append("                        end bb ,                                                                                                                                                               \n");
		buff.append("                        case                                                                                                                                                                   \n");
		buff.append("                          when tot_amt between 300000 and 999990 then round(tot_amt*0.2)                                                                                                       \n");
		buff.append("                          else 0                                                                                                                                                               \n");
		buff.append("                        end cc ,                                                                                                                                                               \n");
		buff.append("                        case                                                                                                                                                                   \n");
		buff.append("                          when tot_amt >= 1000000 then round(tot_amt*0.1)                                                                                                                      \n");
		buff.append("                          else 0                                                                                                                                                               \n");
		buff.append("                        end dd                                                                                                                                                                 \n");
		}
		buff.append("         from   (select                                                                                                                                                                        \n");
		buff.append("                        b.buy_mem_no                                                                                                                                                         \n");
		buff.append("                        ,c.mem_id                                                                                                                                                              \n");
		buff.append("                        ,c.create_dt                                                                                                                                                            \n");
		if ( "B".equals(guBun) )
		{
		buff.append("                        ,sum(a.ord_prd_won_stl-a.ord_cn_amt-a.ord_opt_cn_amt) as tot_amt                                                                                                        \n");
		}
		else
		{
		buff.append("                        ,a.prd_no                                                                                                                                                             \n");
		buff.append("                        ,max(round(a.sel_prc+(a.ord_opt_won_stl/a.ord_qty))) as tot_amt                                                                                                        \n");
		}
		buff.append("                 from   tr_ord_prd a ,                                                                                                                                                         \n");
		buff.append("                        tr_ord b ,                                                                                                                                                             \n");
		buff.append("                        mb_mem c                                                                                                                                                               \n");
		if ( "B".equals(guBun) )
		{
		buff.append("                        ,MT_EVNT_090402_EVNT_SEL d                                                                                                                                             \n");
		buff.append("                 WHERE d.EVNT_NO=200906220000                                                                                                                                             		\n");
		}
		else
		{
		buff.append("                        ,mt_evnt_090212_seller d                                                                                                                                               \n");
		buff.append("                 where  1=1                                                                                                                                                                    \n");
		}
		buff.append("                 and    a.seller_mem_no = d.seller_mem_no                                                                                                                                      \n");
		buff.append("                 and    a.add_prd_no = 0                                                                                                                                    					\n");
		buff.append("                 and    a.ord_qty-a.ord_cn_qty > 0                                                                                                                                             \n");
		buff.append("                 and    b.buy_mem_no > 0                                                                                                                                                       \n");
		buff.append("                 and    a.ord_no = b.ord_no                                                                                                                                                    \n");
		buff.append("                 and    b.buy_mem_no = c.mem_no                                                                                                                                                \n");
		if ( isOnce && "D".equals(guBun) )
		{
		    buff.append("                 and    a.ord_stl_end_dt between to_date(to_char(sysdate-1, 'yyyymmdd')||'000000', 'yyyymmddhh24miss') and to_date(to_char(sysdate-1, 'yyyymmdd')||'235959', 'yyyymmddhh24miss')	\n");
			buff.append("	              and    a.ord_stl_end_dt <= to_date('20091108235959', 'yyyymmddhh24miss')     \n");
		}
		else if ( isOnce && "A".equals(guBun) )
		{
		    buff.append("                 and    a.ord_stl_end_dt between to_date('20091030000000', 'yyyymmddhh24miss') and to_date(to_char(sysdate-1, 'yyyymmdd')||'235959', 'yyyymmddhh24miss')		\n");
		    buff.append("	              and    a.ord_stl_end_dt <= to_date('20091108235959', 'yyyymmddhh24miss')     \n");
		}
		else if ( "A".equals(guBun) )
        {
            buff.append("                 and    a.ord_stl_end_dt between to_date('20091030000000', 'yyyymmddhh24miss') and to_date(to_char(sysdate, 'yyyymmdd')||'235959', 'yyyymmddhh24miss')     \n");
            buff.append("	              and    a.ord_stl_end_dt <= to_date('20091108235959', 'yyyymmddhh24miss')     \n");
        }
		// �̺�Ʈ �ؿܱ��ſ�
		else if ( isOnce && "B".equals(guBun) )
		{
		    buff.append("                 and    a.ord_stl_end_dt between to_date('20090630000000', 'yyyymmddhh24miss') and to_date(to_char(sysdate-1, 'yyyymmdd')||'235959', 'yyyymmddhh24miss')		\n");
		    buff.append("	              and    a.ord_stl_end_dt <= to_date('20090712235959', 'yyyymmddhh24miss')     \n");
		}
		// �̺�Ʈ �ؿܱ��ſ�
		else if ( "B".equals(guBun) )
        {
            buff.append("                 and    a.ord_stl_end_dt between to_date('20090630000000', 'yyyymmddhh24miss') and to_date(to_char(sysdate, 'yyyymmdd')||'235959', 'yyyymmddhh24miss')     \n");
            buff.append("	              and    a.ord_stl_end_dt <= to_date('20090712235959', 'yyyymmddhh24miss')     \n");
        }
		else
		{
		    buff.append("                 and    a.ord_stl_end_dt between to_date(to_char(sysdate, 'yyyymmdd')||'000000', 'yyyymmddhh24miss') and to_date(to_char(sysdate, 'yyyymmdd')||'235959', 'yyyymmddhh24miss')	\n");
		    buff.append("	              and    a.ord_stl_end_dt <= to_date('20091108235959', 'yyyymmddhh24miss')     \n");
		}
		if ( "B".equals(guBun) )
		{
		buff.append("                 group by c.mem_id, b.buy_mem_no, c.create_dt ) )                                                                                                                    \n");
		}
		else
		{
		buff.append("                 group by c.mem_id, b.buy_mem_no, a.prd_no, c.create_dt ) )                                                                                                                    \n");
		}
		buff.append(" group by mem_id, buy_mem_no, create_dt                                                                                                                                                        \n");
		buff.append(" )                                                                                                                                                                                             \n");
		buff.append(" where rnk <= 11                                                                                                                                                                               \n");
//log.error(buff.toString());
		try
		{
			conn = DBHandler.getConnection(dbUrl,dbId,dbPwd);
			if (conn == null)
			{
				log.error("Connection is NULL !!!");
				throw new Exception("Connection is NULL !!!");
			}
			pstmt = conn.prepareStatement(buff.toString());
			pstmt.setString(1, guBun);
			//pstmt.setString(2, today);
			pstmt.execute();

			conn.commit();

			DBHandler.closeDBResource(rs,pstmt);
			DBHandler.closeDBResource(conn);

		} catch (Exception e) {
			log.error(e.toString());
			e.printStackTrace();
			return;
		} finally {
			try {
				DBHandler.closeDBResource(rs,pstmt);
				DBHandler.closeDBResource(conn);
			} catch (Exception e) {}

			log.debug("===== "+batchName+" ���� END =====");
		}
	}
} // end of class