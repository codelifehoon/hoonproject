package skt.tmall.daemon.escrow;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.util.ArrayList;
import java.util.List;

import skt.tmall.ServiceFactory;
import skt.tmall.business.escrow.trade.domain.OrderClaimDeliveryListBO;
import skt.tmall.daemon.common.util.DBHandler;
import skt.tmall.process.share.escrow.shipping.service.ShippingInterfaceService;
import skt.tmall.process.share.escrow.shipping.service.ShippingInterfaceServiceImpl;

import com.ibatis.sqlmap.client.SqlMapClient;
import com.skt.omp.common.db.SqlMapLoader;

/**
 * GoodsFlow ��ġ��ȯ
 * ������ �Ǹ��ڰ� �߼�ó�� �ϸ�, �ǽð� �½��÷ο� ���ۿ��� 5�д����� ��ġ ��ȯ�Ѵ�
 * 2009.01.04
 * @author �ȿ
 * @version 0.1
 */
public class E36_ExchangeGoodsFlowBatch extends EscrowBaseDaemon {

	/**
	 * @param args
	 */
	public static void main(String[] args) {
        EscrowBaseDaemon.initSqlMap();
        E36_ExchangeGoodsFlowBatch dm = new E36_ExchangeGoodsFlowBatch();
		dm.run();
	}

	public void run() {
		batchName = "GoodsFlow ��ġ��ȯ";
        batch_no = 2536;


        /* ��ø ���� ����  */
        if (isRunning(batch_no)) {
            String errMsg = "�̹� �������Դϴ�:";
            log.error(errMsg);
            batchLogPrint(batch_no, null, null, "-1", "User Define Error", "N/A", "Y", errMsg, errMsg);
            return;
        }

		run_sub();
	}

	public void run_sub() {
		log.debug("===== "+batchName+" START =====");

    	log.info("��ȯ ��۰�� ���� ������Ʈ ����!!!!!!!!!");
        batchLogStart(batch_no,"��ġ ����");

        SqlMapClient sqlMapClient = null;

        try {
        	List<OrderClaimDeliveryListBO> list = getResendList();
        	if (list != null && list.size() > 0) {
				sqlMapClient = SqlMapLoader.getInstance();
	        	sqlMapClient.startTransaction();
				log.debug("sqlMapClient : " + sqlMapClient);

				ShippingInterfaceService shippingInterfaceService = (ShippingInterfaceService)ServiceFactory.createService( ShippingInterfaceServiceImpl.class );
	            shippingInterfaceService.setProperties(prop);
				shippingInterfaceService.getExchangeFileSend(sqlMapClient, list);

				sqlMapClient.commitTransaction();
        	}

            batchLogEnd(batch_no, "0", "Success", "N/A", "N", "ó���Ǽ�:"+list.size(), null);
        }
        catch(Exception e) {
        	if (sqlMapClient != null) {
        		try {
        			sqlMapClient.endTransaction();
        		} catch (Exception e2) {}
        	}

        	e.printStackTrace();
        	log.error(e.toString());

            String err="";
            err += " Err:"+e.toString();
            batchLogEnd(batch_no, "-1", "Error", "N/A", "Y", err, batchName + " ����");
            log.error(e);
		} finally {
		    try {sqlMapClient.endTransaction();} catch (Exception trnas) {}
			log.debug("===== "+batchName+" END =====");
		}
        log.info(batchName + " ����!!");
    }

	public List<OrderClaimDeliveryListBO> getResendList() {

		List<OrderClaimDeliveryListBO> list = new ArrayList<OrderClaimDeliveryListBO>();

		Connection conn = null;
		PreparedStatement pstmt = null;
		ResultSet rs = null;

		StringBuffer buffer = new StringBuffer();
		buffer.append("select                                               ");
		buffer.append("      b.CLM_BNDL_DLV_SEQ                        ");
		buffer.append("      , min(b.DELVPLACE_SEQ) as DELVPLACE_SEQ        ");
		buffer.append("from  tr_ord_clm_dlv_dtls a, tr_ord_clm_delvplace b  ");
		buffer.append("where SND_END_DT > sysdate - 1                       ");
		buffer.append("and DLV_OCCR_TY = '02'                           /* �߼���ü : 01 : �����, 02: ��ȯ�߼�, 04 : ��ǰ�߼� */      ");
		buffer.append("and DLV_MTHD_CD in ('01', '02', '03')            /* ��۹��(TR044) */      ");
		buffer.append("and DLV_ETPRS_CD NOT IN ('00099', '00023', '00024', '00025')                         ");
		buffer.append("and INVC_NO is not null                              ");
		buffer.append("and GOODSFLOW_SEND_DT is null                    /* �½��÷����� ���� */        ");
		buffer.append("and b.CLM_BNDL_DLV_SEQ is not null                   ");
		buffer.append("and a.DELVPLACE_SEQ = b.DELVPLACE_SEQ                ");
		buffer.append("and b.ORD_CLM_DLV_CLF = '02'                         ");
		buffer.append("group by   b.CLM_BNDL_DLV_SEQ               ");

		try {
			conn = DBHandler.getConnection(dbUrl,dbId,dbPwd);
			if (conn == null) {
				log.error("Connection is NULL !!!");
				throw new Exception("Connection is NULL !!!");
			}

			pstmt = conn.prepareStatement(buffer.toString());
			rs = pstmt.executeQuery();
			while( rs.next() ) {
				OrderClaimDeliveryListBO bo = new OrderClaimDeliveryListBO();
				bo.setClmBndlDlvSeq(rs.getString("CLM_BNDL_DLV_SEQ"));
				bo.setDelvplaceSeq(rs.getString("DELVPLACE_SEQ"));
				list.add(bo);
			}

			DBHandler.closeDBResource(rs,pstmt);
			DBHandler.closeDBResource(conn);

		} catch (Exception e) {
			e.printStackTrace();
			log.error(e.toString());
		} finally {
			try {DBHandler.closeDBResource(rs,pstmt); } catch (Exception rse) {}
			try {DBHandler.closeDBResource(conn); } catch (Exception conne) {}
			log.debug("===== "+batchName+" ���� END =====");
		}

		return list;
	}

/**
 * ��� �߻��� �Ʒ� dlv_no �� �ϵ��ڵ��Ͽ� �߼� �� �� �ִ�.
 *
 * @return
 */
public List<OrderClaimDeliveryListBO> Not_work_getResendList() {

        List<OrderClaimDeliveryListBO> list = new ArrayList<OrderClaimDeliveryListBO>();

        String[] dlv_no = {
                "1451071"
                ,"1489570"
        };

        try {
               for(int i = 0; i < dlv_no.length; i++) {
                OrderClaimDeliveryListBO bo = new OrderClaimDeliveryListBO();
                bo.setDlvNo(dlv_no[i]);
                list.add(bo);
               }

        } catch (Exception e) {
            e.printStackTrace();
            log.error(e.toString());
        } finally {

            log.debug("===== "+batchName+" ���� END =====");
        }

        return list;
    }

} // end of class
