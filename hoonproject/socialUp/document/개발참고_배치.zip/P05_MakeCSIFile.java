package skt.tmall.daemon.escrow;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.sql.Timestamp;
import java.util.Properties;
import java.util.StringTokenizer;

import skt.tmall.common.security.TmallSecureManager;
import skt.tmall.daemon.common.util.DBHandler;
import skt.tmall.daemon.pas.*;


public class P05_MakeCSIFile extends EscrowBaseDaemon {

    public static void main(String args[]) throws Exception
    {
        StdOut.setDebug( false );

	    if (args.length != 3) {
	    	usage();
	    } else {
	        StdOut.log("main", "*** Begin - Service *** ");

	        EscrowBaseDaemon.initSqlMap();
	        P05_MakeCSIFile mcf = new P05_MakeCSIFile();

	        mcf.run( args[0], args[1], args[2] );

	        StdOut.log("main", "*** End   - Service *** ");
	    }
    }

    private static void usage() {
        StdOut.error("main", "Usage: java skt.tmall.daemon.escrow.P05_MakeCSIFile <capture date> <interface name> <opcode>");

        System.exit(-1);
	}

	public void run( String capdate, String iName, String oCode ) {
		batch_no = 2705;
    	batchID = "tmba_2705";
    	batchName = "���ݿ����� ������� ���ϻ��� 2�ܰ� (2/2)";

		/* ��ø ���� ����  */
		if (isRunning(batch_no)) {
			String errMsg = "�̹� �������Դϴ�";
			log.error(errMsg);
			batchLogPrint(batch_no, null, null, "-1", "User Define Error", "N/A", "Y", errMsg, errMsg);
			return;
		}

		run_sub( capdate, iName, oCode );
	}


    public void run_sub( String capdate, String interfacename, String opcode )
	{
		String captype    = null;

		int cap_seq       = 1;
		byte[] temp       = null;
		int logfiletype   = 1;

	      StdOut.log("makeFile", "CAPTURE DAY=" + capdate );


		Timestamp to_date = new Timestamp(System.currentTimeMillis());
		Timestamp yes_date = new Timestamp(to_date.getTime() - 24*60*60*1000);
		Timestamp tomorrow_date = new Timestamp(to_date.getTime() + 24*60*60*1000);

		String to_tmp  = to_date.toString();
		// ���� �Ͻ� : ex : 2010-06-10 18:13:29.81

		String yes_ext = yes_date.toString().substring(0, 4) + yes_date.toString().substring(5,7)+yes_date.toString().substring(8,10);
		// ���� ��¥ : ex : 20100609
		String req_date = to_date.toString().substring(0, 4) + to_date.toString().substring(5,7)+to_date.toString().substring(8,10);
		// ���� ��¥ : ex : 20100610
		String tomo_date = tomorrow_date.toString().substring(0, 4) + tomorrow_date.toString().substring(5,7)+tomorrow_date.toString().substring(8,10);
		// ���� ��¥ : ex : 20100611

		if ( ! capdate.equals(yes_ext) ) {
			capdate = yes_ext;
		}

		StdOut.debug("makeFile", "time="+to_tmp.substring(11,13) );

	//	String to_ext = to_date.toString().substring(2, 4) + to_date.toString().substring(5,7)+to_date.toString().substring(8,10);

		String to_ext = capdate.substring( 2 );
		// ���� ��¥�� �� ���ڸ� 2�� ���� : ex : 100609

		StdOut.log("makeFile", "to_ext=" + to_ext);

		// //////////////////////////////////////////////////////////
		// TODO :: DEBUG �Ҷ� ���
		if( false ) {  // if release
	//	if( true ) {  // if debug
    		StdOut.log("makeFile", "\n\n�������ڰ� ������ ���Ͽ� ���� �����Ǿ� �ֽ��ϴ�. �ݵ�� Ȯ���Ͻñ� �ٶ��ϴ�.\n\n" );
    //		to_ext = "091210";
		}
		// //////////////////////////////////////////////////////////

		//
		int idx = 0;

		//String up_edifile = "SKT_TAX_S_KSNET"+"."+to_ext;
		//String dn_edifile = "SKT_TAX_R_KSNET"+"."+yes_ext;

		// SKT�� ������ ���ϸ� ���� : ������ ������ SYSDATE�� ��û
		//CSI.NTSG.YYYYMMDD_01
		String up_edifile = "CSI.NTSG." + req_date + "_01";
		// SKT���� ������ ���ϸ� ����
		String dn_edifile = "CSO.NTSG." + tomo_date + "_01";

		StdOut.log("makeFile", "<Info><makeCsiFile> Upload   filename[0] =" + up_edifile );
		StdOut.log("makeFile", "<Info><makeCsiFile> Download filename[0] =" + dn_edifile );


		String[] memno_ar = null;
		String[] idno_ar = null;
		String[] regcd_ar = null;
		String[] reqdt_ar = null;
		String[] aprvno_ar = null;


		String qs1 =
			" SELECT MEM_NO, DECODEPARAM(MEM_IDNTY_NO), CSH_RCPT_REG_CD, CSH_RCPT_REQ_DT, CSH_RCPT_APRV_NO " +
			" FROM ";

		String qs_count =
			" SELECT COUNT(*) " +
			" FROM ";

		String qs2 =
			" MB_SELLER_INFO " +
			" WHERE CSH_RCPT_SENDFILE = ? AND CSH_RCPT_REG_CD = ? " +
			" ORDER BY CSH_RCPT_APRV_NO ASC";

		StdOut.debug("makeFile", "============ SQL =======================================");
		StdOut.debug("makeFile", qs1 + qs2 );
		StdOut.debug("makeFile", "=======================================================");


		String sql_req =
			" SELECT DISTINCT CSH_RCPT_REQ_DT " +
			" FROM MB_SELLER_INFO " +
			" WHERE CSH_RCPT_REG_CD = ? " +
			"   AND CSH_RCPT_REQ_DT <= TO_CHAR(SYSDATE, 'YYYYMMDD') " +
			" ORDER BY CSH_RCPT_REQ_DT ASC ";


		String dn_script = "";
		String ex_script = "";

		String dn_script_1 = "./file_get " + dq(interfacename) + " \"/ngmshr/data/batch/pay/sam\" " + dq(dn_edifile) + dq("/weblogic/pas/taxsave/EDI_FILE") + dq(dn_edifile) + dq(opcode) + " \nsleep 5 \n";
		String ex_script_1 = "java -classpath $1 skt.tmall.daemon.escrow.P06_RecvCSIFile /weblogic/batch/bin/pas/taxsave/EDI_FILE/"+ dn_edifile +"\nsleep 5\n";


		Connection con = null;
		PreparedStatement pstmt = null;
		ResultSet rs = null;

		int mrownum = 0;

		try {

			con = DBHandler.getConnection(dbUrl,dbId,dbPwd);
			pstmt = con.prepareStatement( qs_count + qs2 );

			pstmt.setString( 1,  up_edifile );
			pstmt.setString( 2,  "00" );

			rs = pstmt.executeQuery();

			if ( rs.next() ) {
				mrownum = rs.getInt( 1 );
				StdOut.log("makeFile", "Init. Array [" + mrownum +"]" );

				memno_ar 	   = new String[mrownum];
				idno_ar 	   = new String[mrownum];
				regcd_ar 	   = new String[mrownum];
				reqdt_ar 	   = new String[mrownum];
				aprvno_ar 	   = new String[mrownum];
			}

			DBHandler.closeDBResource(rs);
			DBHandler.closeDBResource(pstmt);


			pstmt = con.prepareStatement( sql_req );

			pstmt.setString( 1, "01" );
			rs = pstmt.executeQuery();

			while ( rs.next() ) {
				dn_edifile = "CSO.NTSG." + rs.getString(1) + "_01";
				StdOut.log("makeFile", "DownLoad EDI filename[" + (idx++) + "] = " +dn_edifile );

				//dn_script += "./edi_ftp D "+ vansite_no +" EDI_FILE/"+ dn_edifile+" "+ rs.getString(1) +  " 5 \nsleep 5\n";
				dn_script += "./file_get " + dq(interfacename) + dq("/ngmshr/data/batch/pay/sam") + dq(dn_edifile) + dq("/weblogic/pas/taxsave/EDI_FILE") + dq(dn_edifile) + dq(opcode) + " \nsleep 5 \n";

				ex_script += "java -classpath $1 skt.tmall.daemon.escrow.P06_RecvCSIFile /weblogic/batch/bin/pas/taxsave/EDI_FILE/"+ dn_edifile +"\nsleep 5\n";
			}

			if ( mrownum < 1 ){
				StdOut.error("makeFile", "EDI Data not found");

				throw new Exception ("EDI Data not found");
			}

		} catch( Exception e) {
		    StdOut.error("makeFile", "Exception : " +e.getMessage() );
			//throw e;
		} finally {

            DBHandler.closeDBResource( rs, pstmt );
            DBHandler.closeDBResource( con );


			if( dn_script == null || dn_script.equals("") || ex_script == null || ex_script.equals("") ) {
				dn_script = dn_script + dn_script_1;
				ex_script = ex_script + ex_script_1;
			}

			//
			// EDI ������ �۽��ϱ� ���� ���� �Ǿ�� �� Shell Script �� ���� �Ѵ�.
			StdOut.log( "makeFile", "Script File Create !" );




			saveTAXFile.saveFile( "./file_put " + dq("TMALL.COMM_PAY_FBT") + dq("/home/eaiadmin/pas/EDI_FILE") + dq(up_edifile) + dq("/ngmshr/data/batch/pay/sam") + dq(up_edifile) + dq(opcode), 3, "send_csi_cap" );

			saveTAXFile.saveFile(dn_script, 4, "recv_csi_cap");

			saveTAXFile.saveFile(ex_script, 5, "recv_csi_exe" );

			StdOut.log("makeFile", "File Create Success !"  );


		}






		int index2 = 0;
		try {
			con = DBHandler.getConnection(dbUrl,dbId,dbPwd);
			StdOut.log("makeFile", "Success ConnectionPool (Detail) !!! ");

	    	pstmt = con.prepareStatement( qs1 + qs2 );
	    	pstmt.setString( 1,  up_edifile );
	    	pstmt.setString( 2,  "00" );
	    	rs = pstmt.executeQuery();

			StdOut.log("makeFile", "Before Set Value.[" + mrownum +"]" );

			while ( rs.next() ) {

				try {
					memno_ar[index2] 	= getValue(rs.getString(1));
					idno_ar[index2] 	= getValue(rs.getString(2));
					regcd_ar[index2] = getValue(rs.getString(3));
					reqdt_ar[index2] = getValue(rs.getString(4));
					aprvno_ar[index2] 	= getValue(rs.getString(5));

				} catch(Exception e) {

				    StdOut.error("makeFile", "index : " + index2
										   + ", memno : " + memno_ar[index2]
		                                   + ", aprvno : " + aprvno_ar[index2]);

				    memno_ar[index2] 	= null;
				    idno_ar[index2] 	= null;
				    regcd_ar[index2] = null;
				    reqdt_ar[index2] = null;
				    aprvno_ar[index2] 	= null;

					continue;
				}

				index2++;

			}	 // End while()

			DBHandler.closeDBResource(rs);

		} catch(SQLException e) {
			 StdOut.error("makeFile", "" + e.getMessage() );
			 e.printStackTrace();
			//throw new SQLException(e.getMessage());
		} catch(Exception e) {
		    StdOut.error("makeFile", "Exception : " + e.getMessage());
			//throw new SQLException(e.getMessage());
		} finally {
			DBHandler.closeDBResource( pstmt );
			//DBHandler.closeDBResource( con );
		}


		int totalcnt = 0;
		int currentcnt = 0;

		Properties param = new Properties();
/*
		for ( int j = 0; j < index2; j++ ) {

			param.setProperty("MemNO", memno_ar[j]);
			param.setProperty("SBizNO", idno_ar[j]);
			param.setProperty("RegCode", regcd_ar[j]);
			param.setProperty("ReqDate", reqdt_ar[j]);
			param.setProperty("AprvNO", aprvno_ar[j]);

			totalcnt = index2;

			param.setProperty("totalcnt",   Integer.toString(totalcnt) );
			param.setProperty("currentcnt", Integer.toString(++currentcnt));

			StdOut.debug("makeFile", "Param : " + param.toString() );

			try {
				temp = CsiGetDATA1.getCapReq(param);
				StdOut.debug("makeFile", "CsigetDATA1.getCapReq");
			} catch(Exception e) {
				StdOut.error("makeFile", "error in CsigetDATA1.getCapReq() : "+e.getMessage() );
			}

			try {
				saveTAXFile.saveFile( Format.decodeLJFS(temp,0,600), logfiletype, up_edifile);
				StdOut.debug("makeFile", "saveCsiFile.saveFile");
		   	} catch(Exception e) {
				StdOut.error("makeFile", "error in saveCsiFile.saveFile call! ... "+e.getMessage());
		   	}
		} //for loop end!!


		if ( index2 == 0 ) {
			totalcnt = index2;
			param.setProperty("currentcnt", "1");
			param.setProperty("totalcnt", "0");

			try {
				temp = CsiGetDATA1.getCapReq(param);
			} catch(Exception e) {
				StdOut.error("makeFile", "error in CsigetDATA1.getCapReq() : "+e.getMessage());
			}
			try {
				saveTAXFile.saveFile( Format.decodeLJFS(temp,0,600), logfiletype, up_edifile);
			} catch(Exception e) {
					StdOut.error("makeFile","error in saveCsiFile.saveFile call! ... "+e.getMessage());
		   	}
		}
*/
		index2 = index2 + 2;

		for ( int j = -1; j < index2 - 1; j++ ) {

			if ( j > -1 && j < index2 - 2 ) {

				param.setProperty("MemNO", memno_ar[j]);
				param.setProperty("SBizNO", idno_ar[j]);
				param.setProperty("RegCode", regcd_ar[j]);
				param.setProperty("ReqDate", reqdt_ar[j]);
				param.setProperty("AprvNO", aprvno_ar[j]);

				try {
	            	if ( statusUpdate( con, param ) != 1 ) {
	            		throw new PGServiceException("99999999", "Unable to update" );
	            	}
	            	StdOut.debug("makeFile", "CsigetDATA1.getCapReq");
				} catch(Exception e) {
					StdOut.error("makeFile", "error in CsigetDATA1.getCapReq() : "+e.getMessage() );
				}


			}

			totalcnt = index2 - 2;

			param.setProperty("totalcnt",   Integer.toString(totalcnt) );
			param.setProperty("currentcnt", Integer.toString(currentcnt));
			currentcnt++;

			StdOut.debug("makeFile", "Param : " + param.toString() );

			try {
				temp = CsiGetDATA1.getCapReq(param);
				StdOut.debug("makeFile", "CsigetDATA1.getCapReq");
			} catch(Exception e) {
				StdOut.error("makeFile", "error in CsigetDATA1.getCapReq() : "+e.getMessage() );
			}

			try {
				saveTAXFile.saveFile( Format.decodeLJFS(temp,0,600), logfiletype, up_edifile);
				StdOut.debug("makeFile", "saveCsiFile.saveFile");
		   	} catch(Exception e) {
				StdOut.error("makeFile", "error in saveCsiFile.saveFile call! ... "+e.getMessage());
		   	}
		} //for loop end!!


		if ( index2 - 2 == 0 ) {
			totalcnt = index2;
			param.setProperty("currentcnt", "1");
			param.setProperty("totalcnt", "0");

			try {
				temp = CsiGetDATA1.getCapReq(param);
			} catch(Exception e) {
				StdOut.error("makeFile", "error in CsigetDATA1.getCapReq() : "+e.getMessage());
			}
			try {
				saveTAXFile.saveFile( Format.decodeLJFS(temp,0,600), logfiletype, up_edifile);
			} catch(Exception e) {
					StdOut.error("makeFile","error in saveCsiFile.saveFile call! ... "+e.getMessage());
		   	}
		}

		StdOut.log("makeFile", "File Create Success !"  );
		DBHandler.closeDBResource( con );

	} // function:makeFile end!!



	/**
	 *
	 * Get Value
	 * <P/>
	 * ���� �޼ҵ� ����.
	 *
	 * @param input
	 * @return
	 * @throws Exception
	 */
	public static String getValue(String input) throws Exception {
		if( input == null )
		    throw new Exception("getValue()::NullPointerException");

		return input;
	}

	// double quotation ����
	public static String dq(String input) {

			input = " \"" + input + "\" ";

		return input;
	}

    private int statusUpdate(Connection conn, Properties param ) {

        PreparedStatement pstmt = null;
        int     rows = 0;

        StdOut.debug("statusUpdate", "Properties = " + param.toString() );

        try {
            pstmt = conn.prepareStatement(
                    "UPDATE MB_SELLER_INFO " +
                    "   SET csh_rcpt_reg_cd = '01' " +
                    " WHERE mem_no = ? "
            );

            pstmt.setLong(1, Long.parseLong( param.getProperty("MemNO") ) );

            rows = pstmt.executeUpdate();

            if ( rows != 1 ) {
                StdOut.error("statusUpdate", "Unable to update ...  ["+param.getProperty("MemNO") +"]"  );

                throw new PGServiceException("99999999", "Unable to update ..." );
            }

        } catch ( Exception e) {
            StdOut.error("statusUpdate", e.getMessage() );
            rows = -1;
        } finally {
            DBHandler.closeDBResource(pstmt);
        }

        return rows;
    }

}