package skt.tmall.daemon.escrow;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;

import skt.tmall.daemon.common.util.DBHandler;

	/**
	 * ��Ű�� �̺�Ʈ
	 * @author ����ö
	 *
	 */

public class E70_BikiniEvnt extends EscrowBaseDaemon {
		/**
		 * @param args
		 */
		public static void main(String[] args) {
			E70_BikiniEvnt dm = new E70_BikiniEvnt();
			dm.run();
		}

		public void run() {
			batch_no = 2570;
			batchID = "tmba_bo_46";
			batchName = "��Ű���̺�Ʈ";

			/* ��ø ���� ����  */
			if (isRunning(batch_no)) {
				String errMsg = "�̹� �������Դϴ�";
				log.error(errMsg);
				batchLogPrint(batch_no, null, null, "-1", "User Define Error", "N/A", "Y", errMsg, errMsg);
				return;
			}

			run_sub();
		}

		public void run_sub() {
			log.debug("===== "+batchName+" START =====");

			batchLogStart(batch_no, batchName);

			Connection conn = null;
			PreparedStatement pstmt = null;
			ResultSet rs = null;

			StringBuffer buff = new StringBuffer();
			buff.append("	BEGIN /* ��Ű���̺�Ʈ (/05.tMallETCProject/src/skt/tmall/daemon/escrow/E70_BikiniEvnt.java) */	\n");
			buff.append("   	SP_TR_BIKINI_EVNT;	        \n");
			buff.append("	END;							\n");

			log.info("#######################");
			log.info("# ��Ű���̺�Ʈ ��ġ �۵� #");
			log.info("#######################");
			try {
				conn = DBHandler.getConnection(dbUrl,dbId,dbPwd);
				if (conn == null) {
					log.error("Connection is NULL !!!");
					throw new Exception("Connection is NULL !!!");
				}

				pstmt = conn.prepareStatement(buff.toString());
				pstmt.execute();

				DBHandler.closeDBResource(rs,pstmt);
				DBHandler.closeDBResource(conn);

				batchLogEnd(batch_no, "0", "Success", "N/A", "N", "��Ű���̺�Ʈ ��ġ ����", null);

			} catch (Exception e) {
				batchLogEnd(batch_no, "-1", "ERROR", "N/A", "Y", "��Ű���̺�Ʈ ��ġ ����", "��Ű���̺�Ʈ ��ġ ����");
				log.error(e.toString());
			} finally {
				try {
					DBHandler.closeDBResource(rs,pstmt);
					DBHandler.closeDBResource(conn);
				} catch (Exception e) {}

				log.debug("===== "+batchName+" END =====");
			}
		}
	} // end of class
