package skt.tmall.daemon.escrow;

import java.io.FileWriter;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.Date;
import java.util.HashMap;
import java.util.Map;
import java.util.List;

import skt.tmall.bdt.transfer.mail.EmailRequestBO;
import skt.tmall.bdt.transfer.mail.EmailUserInfo;
import skt.tmall.bdt.transfer.sms.SmsRequestBO;
import skt.tmall.common.TmallException;
import skt.tmall.common.util.EDate;
import skt.tmall.daemon.common.util.DBHandler;

import skt.tmall.process.share.remittance.remittancesummary.service.EmailService;
import skt.tmall.process.share.remittance.remittancesummary.service.EmailServiceImpl;
import com.skt.omp.common.util.DateTime;

public class E33_AdSMSModule extends EscrowBaseDaemon {


    private static SmsRequestBO smsRequest = null;
    private static List<SmsRequestBO> smsReqeuestList = null;
    private EmailService service = null;

    private boolean debugMode = false;

    //�޼����� 80byte�Դϴ�.

    private long defaultSellerNo = 10000005;
    private volatile int send_count = 0;
    private static final int update_limit = 50;
    private long totalcount = 0;

    //private final StringBuilder selectSQL = null;

    public E33_AdSMSModule(String today) throws Exception {
        batchName = "���ñ���/������ ���� SMS �߼�";
        batch_no = 2533;
        String[] userList = null;
        String yesterday = "";

		/* ��ø ���� ����  */
		if (isRunning(batch_no)) {
			String errMsg = "�̹� �������Դϴ�";
			log.error(errMsg);
			batchLogPrint(batch_no, null, null, "-1", "User Define Error", "N/A", "Y", errMsg, errMsg);
			return;
		}


        try {

    		if (today == null || today.length() != 8) {
    			Date dt = EDate.offset(new Date(), 0, 0, -1);
    			Date dt2 = EDate.offset(new Date(), 0, 0, -2);
    			today = this.dateFormat(dt, "yyyyMMdd");
    			yesterday = this.dateFormat(dt2, "yyyyMMdd");
    		}

        	userList = getSendSmsList(today,yesterday);

    		log.debug("===== "+batchName+" START =====");
    		batchLogStart(batch_no,batchName);

            if(userList != null){
	            super.initSqlMap();
	            smsReqeuestList = new ArrayList();
	            service = new EmailServiceImpl();

	            for(int i = 0; i < userList.length; i++) {
	                String[] userInfo = userList[i].split(",");

	                sendEmailSummery(userInfo);
	                sendSMSService();

	                Thread.sleep(100);
	            }
            }else{
            	batchLogEnd(batch_no, "-1", "Error", "N/A", "Y", "userList is null!!!!!!!!!!!!!!!!!!!!!!!!!", "��������  SMS �߼� ���� :"+today);
				System.out.println("userList is null!!!!!!!!!!!!!!!!!!!!!!!!!");
            }

            batchLogEnd(batch_no, "0", "Success", "N/A", "N", "�������:"+today, null);

        } catch(Exception e) {
            log.error(batchName + " FATAL : SqlMapLoader.init()");
            throw new TmallException(e.toString());
        } finally {
            smsRequest = null;
            service = null;
            log.debug("SMS�� ���� �Ǹ��� �� : " + send_count);
        }

    }

    private void sendSMSService() throws Exception  {

        long errCnt = service.sendSMSChecked(smsReqeuestList); //���⸸ �ּ� ������ ���� �߼� ����.

        if(errCnt > 0) {
            log.error("���� ���� sms �߼� ����  - ������ ���� ");
            throw new Exception("���� ���� sms �߼� ����  - ������ ���� ");

        }

        smsReqeuestList = new ArrayList();

    }


    /**
     * @param args
     * @throws Exception
     */
    public static void main( String[] args ) throws Exception {

		String today = "";
		if (args != null && args.length > 0) {
			today = args[0];
		}

		E33_AdSMSModule selelrEscrow = new E33_AdSMSModule(today);
    }



    /**
     *
     * <P/>
     * email �߼� ���̺��� �ش� �Ǹ��ڸ� insert �Ѵ�.
     * ȸ�����°�(MB_MEM.mem_stat_cd = 01) �����϶��� �߼� ó�� �Ѵ�.
     * @param conn
     * @param rs
     * @return
     * @throws Exception
     */
    private boolean sendEmailSummery(String[] smsLog) throws Exception {

        String[] content = smsLog;
        String phoneNum = null;
        String smsSellerSubject = null;

        boolean commitTime = false;

        try {

        if(content[0] != null && !"".equals(content[1])) {

            smsRequest = new SmsRequestBO();
            smsRequest.setTemplateId(0);                       // ���ø� ���̵� ����. �Ϲ� �߼��� 0�� ����.
            smsRequest.setType("7");                           // SMS ����. 7: ������, 8: ������, 9: MO
            smsRequest.setSmsType("7");                        // Callback ����. 7: 1way, 8: 2way :callback URL
            smsRequest.setCampaign("�����ı�");                 // ķ���� ��

            phoneNum = content[0].trim().replaceAll("-", "");
            smsSellerSubject = content[1];

            //log.error(phoneNum);
            //log.error(smsSellerSubject);

            smsRequest.setCellPhoneNum(phoneNum);           // �޴� ��� �ڵ��� ��ȣ
            smsRequest.setMessage(smsSellerSubject);        // ���� �޼���
            //smsRequest.setCallback("15990110,http://dev-m.11st.co.kr/176_wap.jsp");             // ������ ����� �ڵ��� ��ȣ
            smsRequest.setCallback("15990110");             // ������ ����� �ڵ��� ��ȣ
            if(phoneNum.matches("\\d+")) {
                send_count++;
                smsReqeuestList.add(smsRequest);
            } else {
                log.error("�Ǹ��� ���� Ȯ�� : " + content[0]);
            }
        }

        } catch(Exception ex) {
            log.error("�Ǹ��� ���� Ȯ�� : " + content[0]);
        }

        if(send_count == update_limit) {
            commitTime = true;
        }
        return commitTime;
    }








	public String[] getSendSmsList(String today, String yesterday) {
		log.debug("===== "+batchName+" START =====");

		String[] userList = null;
		String result = "";
		String smsTxt = "";
		long amtFee = 0;


		System.out.println("������� : " + today);

		Connection conn = null;
		PreparedStatement pstmt = null;
		ResultSet rs = null;

		StringBuffer buff = new StringBuffer();


		buff.append("  SELECT '���� '||TO_CHAR(TO_DATE(A.STL_DY,'YYYYMMDD'),'MM/DD')||'('||SUBSTR(TO_CHAR(TO_DATE(A.STL_DY,'YYYYMMDD'),'DAY'),1,1)||') '||                                                                                               \n");
		buff.append("          TRIM(TO_CHAR(A.AMT_VFEE,'9999990D99'))||'�� (���ִ��'||CASE WHEN (A.AMT_FEE+A.CHP_AMT)-B.PRE_AMT_FEE > 0 THEN '+' END||TRIM(TO_CHAR(ROUND((((A.AMT_FEE+A.CHP_AMT)-B.PRE_AMT_FEE) / B.PRE_AMT_FEE) * 100 ,1),'9999990D9'))||'%) �������� '||       \n");
		buff.append("          ROUND(((C.FEE+A.AMT_FEE)/1.1 + (C.SELLER_CHIP+A.CHP_AMT))/100000000,2)||'��' SND_TXT,                                                                                                                                    \n");
		buff.append("          (A.AMT_FEE+A.CHP_AMT) AMT_FEE                                                                                                                                                                                            \n");
		buff.append("  FROM (                                                                                                                                                                                                                           \n");
		buff.append("        /* ���� �ݾ� */                                                                                                                                                                                                              \n");
		buff.append("        SELECT ?  STL_DY,                                                                                                                                                                                                          \n");
		buff.append("               ROUND((SUM(NVL(PRD_DISP_FEE,0) + NVL(PRD_REG_FEE,0) + NVL(ETC_FEE,0)) / 1.1 + SUM(NVL(CHP_AMT,0)))/100000000,2)  AMT_VFEE,                                                                                                                      \n");
		buff.append("               SUM(NVL(PRD_DISP_FEE,0) + NVL(PRD_REG_FEE,0) + NVL(ETC_FEE ,0)) AMT_FEE,                                                                                                                                                        \n");
		buff.append("               SUM(NVL(CHP_AMT,0)) CHP_AMT                                                                                                                                                                                         \n");
		buff.append("        FROM (                                                                                                                                                                                                                     \n");
		buff.append("               SELECT SUM(CASE WHEN KIND = '02' THEN NVL(FEE,0) ELSE 0 END) PRD_DISP_FEE,         -- ��ǰ���ü�����                                                                                                                																		\n");
		buff.append("                      SUM(CASE WHEN KIND = '01' THEN NVL(FEE,0) ELSE 0 END) PRD_REG_FEE,         -- ��ǰ��ϼ�����                                                                                                                 																		\n");
		buff.append("                      SUM(CASE WHEN KIND IN ('04','09') THEN NVL(FEE,0) ELSE 0 END) ETC_FEE,  -- ��Ÿ������                                                                                                                        																			\n");
		buff.append("                      0 CHP_AMT                                                                                                                                                                                                    \n");
		buff.append("               FROM (                                                                                                                                                                                                              \n");
		buff.append("                      -- ����                                                                                                                                                                                                      																															\n");
		buff.append("                      SELECT /*+ leading(SFS SFSO SFI) use_hash(SFS SFSO SFI)                                                                                                                                                      \n");
		buff.append("                                 index(sfs IX1_SE_FEE_STL) parallel(SFSO 4) parallel(SFI 4)                                                                                                                                        \n");
		buff.append("                                 full(SFSO)                                                                                                                                                                                        \n");
		buff.append("                                 full(SFI)                                                                                                                                                                                         \n");
		buff.append("                                 pq_distribute(SFSO,hash,hash)                                                                                                                                                                     \n");
		buff.append("                              */                                                                                                                                                                                                   \n");
		buff.append("                             SFS.MEM_NO,                                                                                                                                                                                           \n");
		buff.append("                             SFSO.FEE_STL_AMT - SFSO.CUPN_DSC_AMT AS FEE,                                                                                                                                                          \n");
		buff.append("                             SFI.FEE_KD_CD KIND                                                                                                                                                                                    \n");
		buff.append("                      FROM SE_FEE_STL SFS,      -- ���������                                                                                                                                                                     																											\n");
		buff.append("                           SE_FEE_STL_OBJ SFSO, -- ������������                                                                                                                                                                 																										\n");
		buff.append("                           SE_FEE_ITM SFI       -- �������׸�                                                                                                                                                                     											 																\n");
		buff.append("                      WHERE SFS.FEE_STL_NO  = SFSO.FEE_STL_NO                                                                                                                                                                      \n");
		buff.append("                      AND   SFSO.FEE_ITM_NO = SFI.FEE_ITM_NO                                                                                                                                                                       \n");
		buff.append("                      AND  (SFS.FEE_STL_DT >= TO_DATE(?||'000000','YYYYMMDDHH24MISS')             -- ����������Ͻ�                                                                                                                																		\n");
		buff.append("                      AND   SFS.FEE_STL_DT <= TO_DATE(?||'235959','YYYYMMDDHH24MISS') )                                                                                                                                            \n");
		buff.append("                      AND   SFS.FEE_STL_STAT_CD  = '02'               -- 02:�����Ϸ�                                                                                                                                              																							\n");
		buff.append("                      AND   SFS.FEE_STL_CLF_CD   = '01'               -- ����                                                                                                                                                      																								\n");
		buff.append("                      UNION ALL                                                                                                                                                                                                    \n");
		buff.append("                      -- ȯ��                                                                                                                                                                                                      																															\n");
		buff.append("                      SELECT SFS.MEM_NO,                                                                                                                                                                                           \n");
		buff.append("                             -(SFSO.FEE_STL_AMT - SFSO.CUPN_DSC_AMT) AS FEE,                                                                                                                                                       \n");
		buff.append("                             SFI.FEE_KD_CD KIND                                                                                                                                                                                    \n");
		buff.append("                      FROM SE_FEE_STL SFS,      -- ���������                                                                                                                                                                      																											\n");
		buff.append("                           SE_FEE_STL_OBJ SFSO, -- ������������                                                                                                                                                                  																										\n");
		buff.append("                           SE_FEE_ITM SFI       -- �������׸�                                                                                                                                                                      																											\n");
		buff.append("                      WHERE SFS.FEE_STL_NO   = SFSO.RFND_STL_NO        -- ȯ�Ұ�����ȣ                                                                                                                                             																							\n");
		buff.append("                      AND   SFSO.FEE_ITM_NO  = SFI.FEE_ITM_NO                                                                                                                                                                      \n");
		buff.append("                      AND  (SFS.FEE_STL_DT >= TO_DATE(?||'000000','YYYYMMDDHH24MISS')              -- ����������Ͻ�                                                                                                               																		\n");
		buff.append("                      AND   SFS.FEE_STL_DT <= TO_DATE(?||'235959','YYYYMMDDHH24MISS') )                                                                                                                                            \n");
		buff.append("                      AND   SFS.FEE_STL_STAT_CD  = '02'                -- 02:�����Ϸ�                                                                                                                                             																							\n");
		buff.append("                      AND   SFS.FEE_STL_CLF_CD   = '02'                -- ȯ��                                                                                                                                                     																								\n");
		buff.append("             )                                                                                                                                                                                                                     \n");
		buff.append("        UNION ALL                                                                                                                                                                                                                  \n");
		buff.append("               SELECT 0 PRD_DISP_FEE,                                                                                                                                                                                              \n");
		buff.append("                      0 PRD_REG_FEE,                                                                                                                                                                                               \n");
		buff.append("                      0 ETC_FEE,                                                                                                                                                                                                   \n");
		buff.append("                      NVL(SUM(                                                                                                                                                                                                         \n");
		buff.append("                          CASE WHEN STR_OBJ_CD = '02' THEN NVL(SELLER_DFRM_CHP_CST_PRD,0) + NVL(SELLER_DFRM_CHP_CST_EVNT,0) -- �Ǹ��� Ĩ����(�Ǹ��� �δ� Ĩ���_��ǰ)                                                              	\n");
		buff.append("                               WHEN STR_OBJ_CD = '04' THEN 0-(NVL(SELLER_DFRM_CHP_CST_PRD,0) + NVL(SELLER_DFRM_CHP_CST_EVNT,0))                                                                                                    \n");
		buff.append("                          END                                                                                                                                                                                                      \n");
		buff.append("                         ),0) CHP_AMT                                                                                                                                                                                              \n");
		buff.append("               FROM SE_SEL_CHRG_STL_DTLS TOSD        -- �ֹ���ǰ���곻��                                                                                                                                                         							  																		\n");
		buff.append("               WHERE STR_OBJ_CD IN ('02','04')                                                                                                                                                                                     \n");
		buff.append("               AND  STL_DY BETWEEN TO_DATE(?||'000000','YYYYMMDDHH24MISS') AND TO_DATE(?||'235959','YYYYMMDDHH24MISS')    -- ����Ȯ���Ͻ�                                                                                          															\n");
		buff.append("        )                                                                                                                                                                                                                          \n");
		buff.append("       ) A,                                                                                                                                                                                                                        \n");
		buff.append("       (  /* ���� �ݾ� */                                                                                                                                                                                                          	\n");
		buff.append("          SELECT ? STL_DY,                                                                                                                                                                                                			\n");
		buff.append("                 NVL(SUM(NVL(PRD_DISP_FEE,0)+NVL(PRD_REG_FEE,0)+NVL(ETC_FEE,0)+NVL(SELLER_DFRM_CHP_CST_PRD,0)+NVL(SELLER_DFRM_CHP_CST_EVNT,0)),0) PRE_AMT_FEE                                                                      \n");
		buff.append("          FROM SE_MO_FEE_STL_DY                                                                                                                                                                                                    \n");
		buff.append("          WHERE STL_DY = TO_DATE(?,'YYYYMMDD') -7                                                                                                                                                                                  \n");
		buff.append("       ) B,                                                                                                                                                                                                                        \n");
		buff.append("       ( /* ���������ݾ� */                                                                                                                                                                                                         \n");
		buff.append("          SELECT ?  STL_DY,                                                                                                                                                                                               			\n");
		buff.append("                 NVL(FEE,0) FEE,                                                                                                                                                                                                   \n");
		buff.append("                 NVL(SELLER_CHIP,0) SELLER_CHIP                                                                                                                                                                                    \n");
		buff.append("          FROM(                                                                                                                                                                                                                    \n");
		buff.append("               SELECT /*+ full(a) parallel(a 4) */SUM(NVL(PRD_DISP_FEE,0)+NVL(PRD_REG_FEE,0)+NVL(ETC_FEE,0))  FEE,                                                                                                                 \n");
		buff.append("                      SUM(NVL(SELLER_DFRM_CHP_CST_PRD,0)+NVL(SELLER_DFRM_CHP_CST_EVNT,0)) SELLER_CHIP                                                                                                                              \n");
		buff.append("               FROM SE_MO_FEE_STL_DY a                                                                                                                                                                                             \n");
		buff.append("               WHERE STL_DY BETWEEN TO_DATE(TO_CHAR(SYSDATE,'YYYYMM')||'01000000','YYYYMMDDHH24MISS') AND TO_DATE(?||'235959','YYYYMMDDHH24MISS')                                                                                  \n");
		buff.append("              )                                                                                                                                                                                                                    \n");
		buff.append("       ) C                                                                                                                                                                                                                         \n");
		buff.append("  WHERE A.STL_DY = B.STL_DY                                                                                                                                                                                                        \n");
		buff.append("  AND A.STL_DY = C.STL_DY                                                                                                                                                                                                          \n");
		buff.append("                                                                                                                                                                                                                                   \n");


		try {

			conn = DBHandler.getConnection(dbUrl,dbId,dbPwd);

			if (conn == null) {
				log.error("Connection is NULL !!!");
				throw new Exception("Connection is NULL !!!");
			}else{

			}


			pstmt = conn.prepareStatement(buff.toString());
            pstmt.setString(1, today);
            pstmt.setString(2, today);
            pstmt.setString(3, today);
            pstmt.setString(4, today);
            pstmt.setString(5, today);
            pstmt.setString(6, today);
            pstmt.setString(7, today);
            pstmt.setString(8, today);
            pstmt.setString(9, today);
            pstmt.setString(10, today);
            pstmt.setString(11, yesterday);



			rs = pstmt.executeQuery();

			while( rs.next() ) {
				result = rs.getString("SND_TXT");
				amtFee = rs.getLong("AMT_FEE");
			}

System.out.println("result ----------> " + result);
System.out.println("amtFee  ----------> " + amtFee);
			if(amtFee < 1){
				userList = null;

			}else{
	  			smsTxt = "010-4623-3489,"+result;  //����
				smsTxt += "��010-5382-3754,"+result;  //������
				smsTxt += "��010-4028-3900,"+result;  //���ؼ�
				smsTxt += "��010-6251-9258,"+result;  //��ȫö
				smsTxt += "��010-3414-4450,"+result;  //������
				smsTxt += "��010-4169-6500,"+result;  //���κ�
				smsTxt += "��010-3553-3388,"+result;  //�ڰ���
				smsTxt += "��010-5302-2010,"+result;  //�̱�ȣ
				smsTxt += "��011-9961-4010,"+result;  //������
				smsTxt += "��010-3728-8432,"+result;  //�ڴ�ö  20100129
				smsTxt += "��010-3213-3463,"+result;  //����ȣ
				smsTxt += "��011-392-4219,"+result;  //����ȣ
				smsTxt += "��010-4339-8885,"+result;  //�̻���
				smsTxt += "��010-3712-9537,"+result;  //���ؿ�

				//2010.04.22 6�� �߰�
				smsTxt += "��010-4012-0300,"+result;  //�蹮��
				smsTxt += "��011-9724-2562,"+result;  //������
				smsTxt += "��010-9043-2046,"+result;  //������
				smsTxt += "��010-2704-3357,"+result;  //������
				smsTxt += "��010-6411-5664,"+result;  //������
				smsTxt += "��010-9228-3606,"+result;  //ȫ����

				//2010.05.02 2�� �߰�
				smsTxt += "��010-9250-4139,"+result;  //������
				smsTxt += "��010-3823-3269,"+result;  //�迵��

				//2010.07.06 1���߰�
				smsTxt += "��010-6349-5117,"+result;  //������

				userList = smsTxt.split("��");
			}


			DBHandler.closeDBResource(rs,pstmt);
			DBHandler.closeDBResource(conn);

		} catch (Exception e) {
			batchLogEnd(batch_no, "-1", "Error", "N/A", "Y", e.toString(), "��������  SMS �߼� ���� :"+today);
			log.error(e.toString());
		} finally {
			try {
				DBHandler.closeDBResource(rs,pstmt);
				DBHandler.closeDBResource(conn);
			} catch (Exception e) {}

			log.debug("===== "+batchName+" ���� END =====");
		}
		return userList;
	}





}
