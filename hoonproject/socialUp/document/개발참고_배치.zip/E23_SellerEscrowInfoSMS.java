package skt.tmall.daemon.escrow;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.List;

import skt.tmall.bdt.transfer.mail.EmailRequestBO;
import skt.tmall.bdt.transfer.mail.EmailUserInfo;
import skt.tmall.bdt.transfer.sms.SmsRequestBO;
import skt.tmall.common.TmallException;
import skt.tmall.daemon.common.util.DBHandler;

import skt.tmall.process.share.remittance.remittancesummary.service.EmailService;
import skt.tmall.process.share.remittance.remittancesummary.service.EmailServiceImpl;
import com.skt.omp.common.util.DateTime;

public class E23_SellerEscrowInfoSMS extends EscrowBaseDaemon {


    private static SmsRequestBO smsRequest = null;
    private static List<SmsRequestBO> smsReqeuestList = null;
    private EmailService service = null;
    private final String smsSubject = "[11����]�Ǹ��ڴ��� ���ϱ��� ����Ȯ���� �Ǽ� PROVIDE��,�߼�ó���� �Ǽ� DELIVERY���Դϴ�.";
    //private boolean useTrunc;
    //private long megaBytes = 1024 * 1024;
    private boolean debugMode = false;
    //private static final String dblink = "@scrt_link";

    /**
     * ������� ������ȣ
     */
    private long defaultSellerNo = 10000005;
    private volatile int send_count = 0;
    private static final int update_limit = 50;
    private long totalcount = 0;

    //private final StringBuilder selectSQL = null;

    public E23_SellerEscrowInfoSMS() throws Exception {
        batchName = "�������ǽ� ��� SMS ���ø�";
        batch_no = 2521;

        try {
            super.initSqlMap();

            /* ��ø ���� ����
            if (isRunning(batch_no)) {
                String errMsg = "�̹� �������Դϴ�:";
                log.error(errMsg);
                batchLogPrint(batch_no, null, null, "-1", "User Define Error", "N/A", "Y", errMsg, errMsg);
                return;
            }*/
            smsReqeuestList = new ArrayList();
            service = new EmailServiceImpl();

            boolean clearSummery = emailDefaultBatch();
            if(!clearSummery) {
                summeryBatch();
                clearSummery = emailDefaultBatch();
            }

        } catch(Exception e) {
            log.error(batchName + " FATAL : SqlMapLoader.init()");
            throw new TmallException(e.toString());
        } finally {
            smsRequest = null;
            service = null;
            log.error("SMS�� ���� �Ǹ��� �� : " + totalcount);
        }

    }

    private void sendSMSService() throws Exception  {

        long errCnt = service.sendSMSChecked(smsReqeuestList); //���⸸ �ּ� ������ ���� �߼� ����.

        if(errCnt > 0) {
            log.error("�Ǹ��� �Ǹ���Ȳ SMS �߼� ���� : �ȿ (�����)");
            throw new Exception("�Ǹ��� �Ǹ���Ȳ SMS �߼� ���� : �ȿ (�����)");

        }

        smsReqeuestList = new ArrayList();

    }


    /**
     * @param args
     * @throws Exception
     */
    public static void main( String[] args ) throws Exception {

        E23_SellerEscrowInfoSMS selelrEscrow = new E23_SellerEscrowInfoSMS();
    }

    /**
     *    SELLER_SELL_SUMMARY ���̺��� ���� �߼� ���� ���� <br>
     *    �Ǹ��ڸ� �ٽ� ���� �߼� ó�� �Ѵ�. <br>
     * @return boolean
     * @throws Exception
     */
    private boolean emailDefaultBatch()  throws Exception {
        Connection conn = null;
        PreparedStatement pstmt = null;
        String query = null;
        ResultSet rs = null;
        String sellerNo = null;
        boolean emailSend = false;

        try {

            conn = DBHandler.getConnection(dbUrl,dbId,dbPwd);
            //conn.setAutoCommit(false); DBHandler�� �ϰ� ����
            query = this.getEmailSendSQL().toString();              // step 1
            pstmt = conn.prepareStatement(query);
            pstmt.setLong(1, defaultSellerNo);
            rs = pstmt.executeQuery();



            /*
             * SELLER_SELL_SUMMARY�� ����Ÿ�� send_yn�� N�� ����Ÿ�� ������
             * �ش� ����Ÿ�� mail���� ���̺��� ���ε��Ѵ�.
             */
            if(rs.next()) {

                /**
                 * rs.next()��  �Ҷ� �Ź� ����Ÿ�� ���྿ ���� �������� ���� �ƴϸ�,
                 * ������ ��(data fefch size)��ƴ �����͸� ���ڿɴϴ�.
                 * ������ ũ���� ���� �����ϴ� ResultSet.setFetchSize(int rows)
                 * �� ���� �޼��尡 �ֽ��ϴ�.
                 */
                rs.setFetchSize(100);

                boolean hasNext = false;
                do {
                   sellerNo = rs.getString("SELLER_MEM_NO");
                   //log.debug(sellerNo);
                   boolean commitTime = sendEmailSummery(rs);    // step 2

                   if(commitTime) {
                       sendSMSService();                             // step 3
                       commitTime = updateSendSuccess(conn, sellerNo); // step 4
                       conn.commit();
                       //log.debug(sellerNo + " �������" );
                       totalcount = totalcount + send_count;
                       send_count = 0;
                   }
                }while(hasNext = rs.next());

                if(send_count > 0) {
                    sendSMSService();
                    updateSendSuccess(conn, sellerNo);
                    totalcount = totalcount + send_count;

                }
                emailSend = true;
            }

        } catch (SQLException e) {
            conn.rollback();
            log.error(e.toString());
            throw new SQLException(e.toString());
        } catch (Exception e) {
            conn.rollback();
            log.error(e.toString());
            throw new Exception(e.toString());
        } finally {
            conn.commit();
            conn.setAutoCommit(true);
            DBHandler.closeDBResource(rs,pstmt);
            DBHandler.closeDBResource(conn);
            log.debug("===== "+batchName+" ���� END =====");
        }
        return emailSend;
    }

    /**
     * seller_sell_summary�� ���̺��� truncate �ϰ�, �ش絥��Ÿ�� <br>
     * �������� insert ���� ��
     * @throws Exception
     */
    private void summeryBatch() throws Exception {
        Connection conn = null;
        try {
            conn = DBHandler.getConnection(dbUrl,dbId,dbPwd);
            //conn.setAutoCommit(false); DBHandler �� �ϰ� ����
            boolean commitTime = true; //truncateSummery(conn);

            if(commitTime) {
              commitTime = insertSummery(conn);
              conn.commit();
            }

        } catch (SQLException e) {
            conn.rollback();
            log.error(e.toString());
            throw new SQLException(e.toString());
        } finally {
            conn.commit();
            conn.setAutoCommit(true);
            DBHandler.closeDBResource(conn);
            log.debug("===== "+batchName+" ���� END =====");
        }
    }


    /**
     *
     * <P/>
     * email �߼� ���̺��� �ش� �Ǹ��ڸ� insert �Ѵ�.
     * ȸ�����°�(MB_MEM.mem_stat_cd = 01) �����϶��� �߼� ó�� �Ѵ�.
     * @param conn
     * @param rs
     * @return
     * @throws Exception
     */
    private boolean sendEmailSummery(ResultSet rs) throws Exception {

        ResultSet rset = rs;
        String phoneNum = null;
        String smsSellerSubject = null;

        boolean commitTime = false;

        try {

        if(rset.getString("MEM_STAT_CD").equals("01")
                && rset.getString("SMS_TRNS_RCV_YN").equals("Y")
                && rset.getString("PRTBL_TLPHN_NO") != null
                && !"".equals(rset.getString("PRTBL_TLPHN_NO"))) {

            smsRequest = new SmsRequestBO();
            smsRequest.setTemplateId(1037);                       // ���ø� ���̵� ����. �Ϲ� �߼��� 0�� ����. 1037
            smsRequest.setType("8");                           // SMS ����. 7: ������, 8: ������, 9: MO             MSGTOBELOG
            smsRequest.setSmsType("7");                        // Callback ����. 7: 1way, 8: 2way :callback URL   MSGHEADERTYPE
            smsRequest.setCampaign("�߼����");                 // ķ���� ��                                                                                 MSGTITLE

            phoneNum = rset.getString("PRTBL_TLPHN_NO").replaceAll("-", "").trim();
            //smsSellerSubject = smsSubject.replaceAll("PROVIDE", rset.getString("SETTLE")).replaceAll("DELIVERY", rset.getString("CONFIRM"));
            smsSellerSubject = rset.getString("SETTLE") + "," + rset.getString("CONFIRM");
            //log.error(phoneNum);
            //log.error(smsSellerSubject);

            smsRequest.setCellPhoneNum(phoneNum);         // �޴� ��� �ڵ��� ��ȣ
            smsRequest.setMessage(smsSellerSubject);  // ���� �޼���
            smsRequest.setCallback("15990110");             // ������ ����� �ڵ��� ��ȣ

            if(phoneNum.matches("\\d+")) {
                send_count++;
                smsReqeuestList.add(smsRequest);
                log.error("�Ǹ��� SMS ��ȣ : " + phoneNum);
            } else {
                log.error("�Ǹ��� ���� Ȯ�� : " + rset.getString("MEM_ID"));
            }
        }

        } catch(Exception ex) {
            log.error("�Ǹ��� ���� Ȯ�� : " + rset.getString("MEM_ID"));
        }

        if(send_count >= update_limit) {
            commitTime = true;
        }
        return commitTime;
    }

    /**
     *
     * <P/>
     * email ���̺��� ������Ʈ �Ǹ�, SELLER_SELL_SUMMERY�� Ư�� �Ǹ����� send_yn�� Y�� ������Ʈ ��.
     * @param conn
     * @param seller_mem_no
     * @return
     * @throws SQLException
     */
    private boolean updateSendSuccess(Connection conn, String seller_mem_no) throws SQLException {
        PreparedStatement pstmt = null;
        String query = null;
        String seller_no = null;
        int incnt = 0;
        boolean commitTime = false;

        try {
            query = this.getUpdateSQL().toString();
            seller_no = seller_mem_no;
            pstmt = conn.prepareStatement(query.toString());
            pstmt.setString(1, seller_no);

            incnt = pstmt.executeUpdate();

            if(incnt > 0) {
                commitTime = true;
            }

        } finally {
            pstmt.close();
        }
        return commitTime;

    }

    private boolean insertSummery(Connection conn) throws SQLException {
        PreparedStatement pstmt = null;
        String query = null;
        int incnt = 0;
        boolean commitTime = false;

        try {
            query = this.getInsertBatchSQL(debugMode).toString();
            pstmt = conn.prepareStatement(query.toString());
            incnt = pstmt.executeUpdate();
            commitTime = true;
        } finally {
            pstmt.close();
        }

        return commitTime;
    }



    /**
     * �Ǹ����� ��踦 ������ �ٷ� insert�Ѵ�
     * @param debugMode (Ư�������� �׽�Ʈ��)
     * @return
     */
    private StringBuilder getInsertBatchSQL(boolean debugMode) {

        final StringBuilder selectSQL = new StringBuilder();
            selectSQL.append("  insert   into SELLER_SELL_SUMMARY (SELLER_MEM_NO                       ");
            selectSQL.append("                                        ,SETTLE                          ");
            selectSQL.append("                                        ,CONFIRM                         ");
            selectSQL.append("                                        ,SEND_KIND_TYPE                  ");
            selectSQL.append("                                        ,CREATE_DT)                      ");
            selectSQL.append("  select                                                                 ");
            selectSQL.append("      seller_mem_no                                                      ");
            selectSQL.append("    ,sum(case stat when 'settle' then cnt else 0 end) as settle          ");
            selectSQL.append("    ,sum(case stat when 'confirm' then cnt else 0 end) as  confirm       ");
            selectSQL.append("    ,'S'                                                                 ");
            selectSQL.append("    ,'1111111113'                                                        ");
            selectSQL.append("  from (                                                                 ");
            selectSQL.append("      SELECT  seller_mem_no,                                             ");
            selectSQL.append("              case when ord_prd_stat = '202' then 'settle'               ");
            selectSQL.append("                 when ord_prd_stat = '301' then  'confirm'               ");
            selectSQL.append("             end as stat                                                 ");
            selectSQL.append("             ,count(1) as cnt                                            ");
            selectSQL.append("    FROM tr_ord_prd                                                      ");
            selectSQL.append("    WHERE  ORD_STL_END_DT >= to_char(sysdate - 1, 'yyyymmdd')            ");
            selectSQL.append("    AND ord_prd_stat in ('301', '202')                                   ");
if(debugMode) selectSQL.append("  AND seller_mem_no = 10000026                                         ");
            selectSQL.append("    group by seller_mem_no, ord_prd_stat                                 ");
            selectSQL.append("    )                                                                    ");
            //selectSQL.append("  where rownum <= 10                                                     ");
            selectSQL.append("  group by seller_mem_no                                                 ");
        return selectSQL;
    }


    private StringBuilder getUpdateSQL() {
        final StringBuilder updateSQL = new StringBuilder();
        updateSQL.append(" UPDATE /*+INDEX (SELLER_SELL_SUMMARY PK_SELLER_SELL_SUMMARY)*/ ");
        updateSQL.append("                  SELLER_SELL_SUMMARY                           ");
        updateSQL.append("              SET SEND_YN = 'Y'                                 ");
        updateSQL.append("              ,UPDATE_DT = SYSDATE                              ");
        updateSQL.append("              WHERE SELLER_MEM_NO <= :SELLER_MEM_NO             ");
        updateSQL.append("              AND CREATE_DT = '1111111113'                      ");
        updateSQL.append("              AND SEND_YN = 'N'                                 ");
        updateSQL.append("              AND send_kind_type = 'S'                          ");
        return updateSQL;
    }
    /**
     * <P/>
     * SELLER_SELL_SUMMERY ���� email ���̺��� ��ϵ��� ���� ����Ÿ�� �����Ѵ�.
     * @return
     */
    private StringBuilder getEmailSendSQL() {
        final StringBuilder emailSendSQL = new StringBuilder();
        emailSendSQL.append(" SELECT  /*+ ORDERED USE_NL(SUMMARY, MEM, CODE) INDEX (summary PK_SELLER_SELL_SUMMARY)*/ ");
        emailSendSQL.append("          summary.seller_mem_no                                                          ");
        emailSendSQL.append("         ,mem.mem_id                                                                     ");
        emailSendSQL.append("         ,mem.PRTBL_TLPHN_NO                                                             ");
        emailSendSQL.append("         ,summary.SETTLE                                                                 ");
        emailSendSQL.append("         ,summary.CONFIRM                                                                ");
        emailSendSQL.append("         ,mem.MEM_STAT_CD                                                                ");
        emailSendSQL.append("         ,mem.SMS_TRNS_RCV_YN                                                                 ");
        emailSendSQL.append("  FROM SELLER_SELL_SUMMARY summary, mb_mem mem                                           ");
        emailSendSQL.append("  WHERE summary.seller_mem_no > :sellerNo                                                ");
        emailSendSQL.append("  AND summary.SELLER_MEM_NO = mem.mem_no                                                 ");
        emailSendSQL.append("  AND summary.CREATE_DT = '1111111113'                                                   ");
        //emailSendSQL.append("  AND mem.mem_typ_cd = '02'                                                            ");
        emailSendSQL.append("  AND send_yn = 'N'                                                                      ");
        emailSendSQL.append("  AND send_kind_type = 'S'                                                               ");
        //emailSendSQL.append("  AND rownum <  2                                                                      ");

        return emailSendSQL;
    }





}
