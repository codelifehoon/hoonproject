package skt.tmall.daemon.escrow;

import java.io.*;
import java.sql.*;
import java.util.*;

import skt.tmall.daemon.common.util.DBHandler;
import skt.tmall.daemon.pas.*;


public class P03_RecvTAXFile extends EscrowBaseDaemon {

    public static void main( String[] args ) {

        StdOut.setDebug( false );

	    if ( args.length != 1 ) {
	    	usage();
	    } else {
	        StdOut.log("main", "*** Begin - Service *** ");

	        EscrowBaseDaemon.initSqlMap();
	        P03_RecvTAXFile rtf = new P03_RecvTAXFile();

	        rtf.run( args[0] );

	        StdOut.log("main", "*** End   - Service *** ");
	    }
    }

    private static void usage() {
        StdOut.error("main", "Usage: java skt.tmall.daemon.escrow.P03_RecvTAXFile <edifile>");

        System.exit(-1);
	}

	public void run( String edifile ) {
		batch_no = 2703;
    	batchID = "tmba_2703";
    	batchName = "���ݿ����� �������ó��";

		/* ��ø ���� ����  */
		if (isRunning(batch_no)) {
			String errMsg = "�̹� �������Դϴ�";
			log.error(errMsg);
			batchLogPrint(batch_no, null, null, "-1", "User Define Error", "N/A", "Y", errMsg, errMsg);
			return;
		}

		run_sub( edifile );
	}


	public void run_sub( String edifile )
	{
        int failCnt = 0;
        int totCnt  = 0;
        int count   = 0;

		StdOut.setDebug( false );


		try {
            Connection con          = null;
            PreparedStatement ps    = null;


            if( edifile == null || edifile.equals("")) {
                throw new Exception( "not Defined EDI file !!" );
            }

    		StdOut.log("main", "EDI Filename : " + edifile  );


    		String dn_filename    = edifile.substring( edifile.lastIndexOf(System.getProperty("file.separator")) + 1 );

    		Timestamp tdate       = new Timestamp(System.currentTimeMillis());
    		String date_tmp2      = tdate.toString();
    		String date2          = date_tmp2.substring(0,4)+date_tmp2.substring(5,7)+date_tmp2.substring(8,10);		// ���ó�¥ YYYYMMDD

    		BufferedReader in     = new BufferedReader(new FileReader(edifile));
    		BufferedWriter out    = new BufferedWriter(new FileWriter("procyon"));


    		// Header Record
    		String recordtype         = null;		// 1. ���ڵ屸��
    		String mxbizno        = null;			// 2. ���ݿ���������� ��Ϲ�ȣ
    		String filename 		= null;		// 3. ���ϸ�
    		String reqdate        = null;			// 4. ��������
    		String filler				= null;		// 5. FILLER


    		// Data Record
    		//String recordtype	= null;		// 1. ���ڵ屸�� : Header�� ���� ���� ���
    		String issueno			= null;		// 2. ���ι�ȣ
    		String sellerbizno		= null;		// 3. ������ ����ڵ�Ϲ�ȣ
    		String issuedate 	= null;			// 4. �ŷ�����
    		String tamount        = null;		// 5. �Ѱŷ� �ݾ�
    		String errcode        = null;	// 6. �����ڵ�(�����ڵ�)
    		//String filler				= null;		// 7. FILLER : Header�� ���� ���� ���


    		// Trailer Record
    		//String recordtype	= null;		// 1. ���ڵ屸�� : Header�� ���� ���� ���
    		String rectotalcnt    = null;   	// 2. �� ������ ���ڵ� �Ǽ�
    		//String filler				= null;		// 3. FILLER : Header�� ���� ���� ���


    		String replycode      = null;		// �����ڵ�
    		String replymessage   = null;	// ����޽���


            Properties param       = new Properties();


    	    try {
    	    	con = DBHandler.getConnection(dbUrl,dbId,dbPwd);
    	    	StdOut.debug("main", "Connection to the DB sucessfully stablished.");

    		    int offset = 0;


    		    // //////////////////////////////////////////////////////
    		    // FOR(;;)
    		    StdOut.log("main", "\n");
    		    StdOut.debug("main", "before for loop ...... (failure transaction update)");

    			for(String line; (line = in.readLine()) != null; count++ )
    			{
    				out.write(line);

    				offset = 0;
    				recordtype = line.substring(offset, offset + 1);
    				offset += 1;


    				if ( recordtype.equals("H") ) {		// Header Record

    					StdOut.debug("main", "Is header record.");

    					if ( line.length() != 50 ) {
        		                throw new Exception("error in Total.length() is not 50");
       					}

    					byte[] value = null;
    					value = line.getBytes();

    					mxbizno = new String(value, offset, 10, "KSC5601").trim();	// 2. ���ݿ����� ����ڹ�ȣ
    					offset += 10;

    					filename = new String(value, offset, 14, "KSC5601").trim();	// 3. ���ϸ�
    					offset += 14;

    					reqdate = new String(value, offset, 8, "KSC5601").trim();	// 4. ��������
    					offset += 8;

    					filler = new String(value, offset, 17, "KSC5601").trim();	// 5. FILLER
    					offset += 17;


    					// date2
    					param.setProperty("RecvDate", date2);				// �������� (���ó�¥)

    					param.setProperty("MxBizNO", mxbizno);			// ���ݿ���������� ��Ϲ�ȣ
    					param.setProperty("FileName", filename);			// ���ϸ�
    					param.setProperty("ReqDate", reqdate);			// ��������


    				} else if ( recordtype.equals("T") ) {		// Trailer Record

    					StdOut.debug("main", "Is tailer record.");

    					if ( line.length() != 50 ) {
    		                throw new Exception("error in Total.length() is not 50");
    					}

    					byte[] value = null;
    					value = line.getBytes();

    					rectotalcnt = new String(value, offset, 9, "KSC5601").trim();	// 2. �� ������ ���ڵ� �Ǽ�
    					offset += 9;
    					rectotalcnt = parseTAXFile.removeZ(rectotalcnt);

    					filler = new String(value, offset, 40, "KSC5601").trim();	// 3. FILLER
    					offset += 40;


    				} else if( line.substring(0,1).equals("D") ) {			// Data Record

    				    totCnt++;

    					byte[] value = null;
    					value = line.getBytes();

    					issueno = new String(value, offset, 9, "KSC5601").trim();	// 2. ���ι�ȣ
    					offset += 9;

    					sellerbizno = new String(value, offset, 10, "KSC5601").trim();	// 3. ������ ����ڵ�Ϲ�ȣ
    					offset += 10;

    					issuedate = new String(value, offset, 12, "KSC5601").trim();	// 4. �ŷ�����
    					offset += 12;

    					tamount = new String(value, offset, 9, "KSC5601");		// 5. �Ѱŷ� �ݾ�
    					offset += 9;
    					tamount = parseTAXFile.removeZ(tamount);
    					if ( tamount.length() == 0 ) {
    						throw new Exception("error : tamount must be over 0");
    					}

    					errcode = new String(value, offset, 3, "KSC5601").trim();		// 6. �����ڵ�
    					offset += 3;

    					filler = new String(value, offset, 6, "KSC5601").trim();		// 7. FILLER
    					offset += 6;


    					if ( errcode.equals("000") ) {
    						throw new Exception("errcode is 000. check the replycode.");
    					} else {
    						replymessage = TAXError.getError(errcode);
    					}


    					param.setProperty("IssueNO", issueno);		// ���ι�ȣ
    					param.setProperty("SellerBizNO", sellerbizno);	// ������ ����ڵ�Ϲ�ȣ
    					param.setProperty("IssueDate", issuedate);		// �ŷ�����
    					param.setProperty("TAmount", tamount.toString());		// �ŷ��ݾ� ���հ�
    					param.setProperty("ErrCode", errcode);		// ���������ڵ�

    					param.setProperty("ReplyCode", errcode);		// �����ڵ�
    					param.setProperty("ReplyMessage", replymessage);	// ����޽���

    					StdOut.log("main", "{"+totCnt+"}\t"+ param.toString() );


    					try {
    					    param = validateTR( con, param );
    					    if( param.getProperty( "tMallNO" ) == null || param.getProperty( "tMallNO" ).equals("") )
    					        throw new Exception("Orginal Tranasction Not Exist ! - tMallNO");

    					    if( param.getProperty( "MxID" ) == null || param.getProperty( "MxID" ).equals("") )
                                throw new Exception("Orginal Tranasction Not Exist ! - MxID");

    					    param = routeMerchant(con, param );

    						param = updateTR( con, param, dn_filename );

    						count += 1;
    	                    StdOut.log("main", "{MxID="+ param.getProperty("MxID")
                                       +", TxNO="+ param.getProperty("TxNO")
                                       +", IssueNO="+ param.getProperty("IssueNO")
                                       +", ReplyMessage="+ param.getProperty("ReplyMessage") +", ...} Good Success.\n");
    					} catch ( Exception e ) {
    						failCnt += 1;
    	                    StdOut.error("main", "{MxID="+ param.getProperty("MxID")
                                       +", TxNO="+ param.getProperty("TxNO")
                                       +", IssueNO="+ param.getProperty("IssueNO")
                                       +", ReplyMessage="+ param.getProperty("ReplyMessage") +", ...} Bad Success.");

    	                    StdOut.log("main", "Continue ...\n" );

    					}

    				} //else if(for Data) end!!

    			} // for-loop end!!


    			// ���� Data Update
    			param = updateSuccessTR( con, param, dn_filename );


    		    StdOut.log("main", "\n");
    		    StdOut.debug("main", "before the (success transaction update)");


    	    } catch (SQLException  e) {
    	        StdOut.error("main", "SQLException:" + e.getMessage() );
    	        e.printStackTrace();
    	    } catch (Exception  e) {
    	        StdOut.error("main", "Exception:" + e.getMessage() );
    		} finally {
    			// Clean-up resources
    			DBHandler.closeDBResource(ps);
    			DBHandler.closeDBResource(con);
    		}

    		out.close();
    		in.close();

		} catch ( Exception e ) {
		    e.printStackTrace();
		    StdOut.error("main", "Exception: " + e.getMessage() );
		}

		StdOut.log("main", "*** End   - Service *** (Total "+totCnt+" rows, "+count+" rows Success "+failCnt+" rows fail)" );
	}

	/**
	 *
	 * route Transaction
	 * <P/>
	 * ���� �޼ҵ� ����.
	 *
	 * @param conn
	 * @param param
	 * @return
	 * @throws Exception
	 */
	static Properties routeMerchant(Connection conn, Properties param) throws Exception {

	    /*  TODO::
	     *  �� �κ��� MM, OM �� ������ 11���� DBMS�� ����ϰ� ������ DB ��Ű���� ����Ѵٴ� �����Ͽ�
	     *  ���̺� ���� �ٸ��� �����ϱ� ���ؼ� ������ �κ��̴�.
	     *  �� �κа� ���� �� �κ��� TaxGetMxData Ŭ������ routeVan �޼ҵ� �̴�.
	     *
	     */
        if( param.getProperty("MxID").equals("tmall")) {
            param.setProperty("TabName",    "tr_csh_rcpt_rqst");    // ���ݿ����� ��û �� ��� ������Ʈ�� ���� CP�� ���̺�
        } else  if( param.getProperty("MxID").equals("tmall_book")) {
            // Add 2010.02.xx tmall_book
            param.setProperty("TabName",    "merchant.TBL_CSH_RCPT_RQST");    // ���ݿ����� ��û �� ��� ������Ʈ�� ���� CP�� ���̺�
        } else {
            StdOut.error("routeVan", "invalidate MxID");
        }

        StdOut.log("routeVan" , "TableName:" + param.getProperty("TabName") );
        StdOut.debug( "routeVan", "\t" + param );

        return param;
    }

	/**
	 *
	 * validate Transaction
	 * <P/>
	 * ���� �޼ҵ� ����.
	 *
	 * @param conn
	 * @param param
	 * @return
	 * @throws Exception
	 */
	static Properties validateTR(  Connection conn, Properties param ) throws Exception {

		String sql        = null;

		PreparedStatement pstmt = null;
		ResultSet rs      = null;


		String issueno = param.getProperty("IssueNO");		// ���ι�ȣ
		String mxbizno    = param.getProperty("MxBizNO");
		String tamount    = param.getProperty("TAmount");
		String sellerbizno    = param.getProperty("SellerBizNO");		// ������ ����ڵ�Ϲ�ȣ


		String apptype    = param.getProperty("AppType");
		String txno       = param.getProperty("TxNO");


		try {
			sql =
				" SELECT mxissueno, mxid, fitype, txno " +
				" FROM taxtr " +
				" WHERE issueno = ? " +
				" AND tamount = ? " +
				" AND txstatus IN (?, ?) " +
				" AND senddate != to_char(sysdate, 'YYYYMMDD') ";
				//" AND seller_bizno = encodeparam(?) ";

			pstmt = conn.prepareStatement(sql);

			pstmt.setString(1, getValue(issueno));
			pstmt.setString(2, getValue(tamount));
			pstmt.setString(3, PGCode.ST_TAX_REQING);
			pstmt.setString(4, PGCode.ST_TAX_REVING);
			//pstmt.setString(3, getValue(sellerbizno));


/*
			sql =
				"SELECT mxissueno, mxid " +
				 " FROM taxtr "  +
				" WHERE fitype = ? " +
				  " AND txno = ? "+
				  " AND bizno = ? "+
				  " AND tamount = ? ";

			pstmt = conn.prepareStatement(sql);
			pstmt.setString(1, getValue(apptype));
			pstmt.setString(2, getValue(txno));
			pstmt.setString(3, getValue(mxbizno));
			pstmt.setString(4, getValue(tamount));
*/

			rs = pstmt.executeQuery();
			if( rs.next() ) {
				param.setProperty("tMallNO", rs.getString(1) );
				param.setProperty("MxID", rs.getString(2) );
				param.setProperty("FiType", rs.getString(3) );
				param.setProperty("TxNO", rs.getString(4) );
			}
			if(  param.getProperty("tMallNO") == null ||  param.getProperty("tMallNO").equals("") ) {
				throw new Exception("Orginal Tranasction Not Exist !");
			}

		} catch (SQLException e ){
		    StdOut.error("validateTR", "SQLException:" + e.getMessage() + "\nSQL=" + sql );
		    e.printStackTrace();
		} catch (Exception e ){
		    StdOut.error("validateTR", "Exception:" + e.getMessage() + ", TxNO=" + txno );
		} finally {
			DBHandler.closeDBResource( rs, pstmt );
		}

		StdOut.debug("validateTR", "\t" + param.toString() );

		return param;
	}


	/**
	 *
	 * Update Transaction
	 * <P/>
	 * ���� �޼ҵ� ����.
	 *
	 * @param conn
	 * @param param
	 * @param dnfile
	 * @return
	 * @throws Exception
	 */
	static Properties updateTR( Connection conn, Properties param , String dnfile) throws Exception {

		String sql        = null;

		PreparedStatement pstmt = null;
		int  cnt = 0;


		String issueday = param.getProperty("IssueDate");		// YYYYMMDDHHMISS
		String issuedate = issueday.substring(0, 8);	// YYYYMMDD
		String issuetime = issueday.substring(8);		// HHMISS
		String issueno = param.getProperty("IssueNO");			// ���ι�ȣ
		String txstatus  = param.getProperty("FiType");	// ����

		if ( txstatus.equals("11") ) {			// ����
			txstatus = PGCode.ST_TAX_REQFAIL;
		} else if ( txstatus.equals("22") ) {	// ���
			txstatus = PGCode.ST_TAX_REVFAIL;
		}
		String resmsg    = param.getProperty("ReplyMessage");
		String errcode = param.getProperty("ReplyCode");		// ���������ڵ�

		String tabName      = param.getProperty("TabName");

		String txno      = param.getProperty("TxNO");



/*
		String issueno   = param.getProperty("IssueNO");
		String issuedate = param.getProperty("IssueDay");
		String issuetime = param.getProperty("IssueTime");
		String appcode   = param.getProperty("AppCode");
		String txstatus  = param.getProperty("ReplyCode");
		String resmsg    = param.getProperty("ReplyMessage");


		String tabName      = param.getProperty("TabName");
*/
//		String apptype = param.getProperty("AppType");

		try {
		    boolean issuenoExt = false;

			// ���ݿ����� �߻� ��û
			sql =   "UPDATE taxtr "+
			        "   SET appcode = ?, txstatus = ?, recvfile = ?, replymsg = ? " ;

			sql += " WHERE txno = ? ";

			/*
			if ( issueno != null && !(issueno.trim()).equals("") ) {
				sql = sql + " and issueno = ? ";
				issuenoExt = true;
			}*/

			pstmt = conn.prepareStatement(sql);
			pstmt.setString(1, getValue(errcode));
			pstmt.setString(2, getValue(txstatus));
			pstmt.setString(3, getValue(dnfile));
			pstmt.setString(4, getValue(resmsg));
			pstmt.setString(5, getValue("" + txno));
/*
			if( issuenoExt ) {
				pstmt.setString(8, issueno);
			}
*/
			cnt = pstmt.executeUpdate();
			if( pstmt != null ) pstmt.close();

			if( cnt != 1 )
				throw new Exception("Orginal Tranasction update(taxtr) fail !");

			// //////////////////////////////////////////////////////
			// OM & MM �� Update
			if( tabName == null || tabName.equals("") )
			    throw new Exception("not defined - Table Name");


			String tmallQuery = "";
			tmallQuery ="UPDATE "+ tabName +" "+
						  " SET cash_rcpt_req_stat = ? "+
						     ", refs_cd = ? "+
						     ", trt_msg = ? "+
						     ", update_dt = SYSDATE "+
						     ", update_no = 0 ";

			tmallQuery = tmallQuery +
					" WHERE csh_rcpt_iss_seq = ? "+
					//"  AND cash_rcpt_req_stat = '04' " +
					"  AND aprv_no = ? ";

			pstmt = conn.prepareStatement(tmallQuery);

			// 01:��û���, 02:��û, 03:��û���  04:��û����, 05:ó���Ϸ�, 06:ó������
			pstmt.setString(1, "06");

			pstmt.setString(2, errcode);

			if ( resmsg.getBytes().length >= 128 )
			{
				resmsg = new String(resmsg.getBytes(), 0, 126, "KSC5601");
			}
			pstmt.setString(3, resmsg );

			pstmt.setLong(4, Long.parseLong( param.getProperty("tMallNO") ) );

			pstmt.setString(5, issueno );

			cnt = pstmt.executeUpdate();

			if( cnt != 1 )
				throw new Exception("Orginal Tranasction update(csh_rcpt_iss_seq) fail !");

		} catch (SQLException e ) {
		    StdOut.error("updateTR", "SQLException:" + e.getMessage()+ ", TxNO" + txno );
		    e.printStackTrace();
		    throw new Exception( e.getMessage());
		} catch (Exception e ) {
			StdOut.error("updateTR", "Exception:" + e.getMessage()+ ", TxNO" + txno );
			throw new Exception( e.getMessage());
		} finally {
			DBHandler.closeDBResource(pstmt);
		}

		return param;
	}

	/**
	 *
	 * Get Value
	 * <P/>
	 * ���� �޼ҵ� ����.
	 *
	 * @param value
	 * @return
	 */
	public static String getValue(String value) {
		if( value == null )
		    value = " ";

		return value;
	}


	static Properties updateSuccessTR( Connection conn, Properties param , String dnfile) throws Exception {

		String sql = null;

		PreparedStatement pstmt = null;
		ResultSet rs = null;
		int cnt = 0;

		String recvdate = param.getProperty("ReqDate");
		String mxissueno = "";
		String mxid = "";
		String fitype = "";
		String txno = "";
		String tabname = "";

		try {
			sql =
				" SELECT mxissueno, mxid, fitype, txno " +
				" FROM taxtr " +
				" WHERE reqdate = TO_CHAR(TO_DATE( ?, 'yyyymmdd') - 2, 'yyyymmdd') " +
				" AND recvfile is null AND replymsg is null AND txstatus not in ('00003630', '00003660') ";

			pstmt = conn.prepareStatement(sql);

			pstmt.setString(1, getValue(recvdate));

			rs = pstmt.executeQuery();

			String replycode = "";
			String replymessage = "";

			while ( rs.next() ) {

				mxissueno = rs.getString(1);
				mxid = rs.getString(2);
				fitype = rs.getString(3);
				txno = rs.getString(4);

				param.setProperty("tMallNO", mxissueno );
				param.setProperty("MxID", mxid );
				param.setProperty("FiType", fitype );
				param.setProperty("TxNO", txno );

				if ( fitype.equals("11") ) {			// ����
						replycode = "00003000";
						replymessage = "����Ϸ�";
				} else if ( fitype.equals("22") ) {	// ���
						replycode = "00003000";
						replymessage = "�������";
				}

				sql =
					" UPDATE taxtr " +
					" SET recvdate=TO_CHAR(SYSDATE, 'yyyymmdd'), appcode='0000', txstatus=?, replymsg=?, recvfile = ? " +
					" WHERE txno = ? ";

				pstmt = conn.prepareStatement(sql);

				pstmt.setString(1, getValue(replycode));
				pstmt.setString(2, getValue(replymessage));
				pstmt.setString(3, getValue(dnfile));

				pstmt.setString(4, txno );

				cnt = pstmt.executeUpdate();
				if( pstmt != null ) pstmt.close();

				if( cnt != 1 )
					throw new Exception("Orginal Tranasction update(taxtr) fail !");


			    if( param.getProperty( "tMallNO" ) == null || param.getProperty( "tMallNO" ).equals("") )
			        throw new Exception("Orginal Tranasction Not Exist ! - tMallNO");

			    if( param.getProperty( "MxID" ) == null || param.getProperty( "MxID" ).equals("") )
                    throw new Exception("Orginal Tranasction Not Exist ! - MxID");

			    param = routeMerchant(conn, param );

			    tabname = param.getProperty("TabName");

				if( tabname == null || tabname.equals("") )
				    throw new Exception("not defined - Table Name");

				String tmallQuery = "";
				tmallQuery = "UPDATE "+ tabname +" "+
							  " SET cash_rcpt_req_stat = ? "+
							     ", refs_cd = ? "+
							     ", trt_msg = ? "+
							     ", update_dt = SYSDATE "+
							     ", update_no = 0 ";

				tmallQuery = tmallQuery +
					" WHERE csh_rcpt_iss_seq = ? " +
					"  AND cash_rcpt_req_stat = '04' ";


				pstmt = conn.prepareStatement(tmallQuery);

				// 01:��û���, 02:��û, 03:��û���  04:��û����, 05:ó���Ϸ�, 06:ó������
				pstmt.setString(1, "05");
				pstmt.setString(2, "0000");

				if ( getValue(replymessage).getBytes().length >= 128 )
				{
					replymessage = new String(getValue(replymessage).getBytes(), 0, 126, "KSC5601");
				}
				pstmt.setString(3, getValue(replymessage));
				pstmt.setLong(4, Long.parseLong( param.getProperty("tMallNO") ));

				cnt = pstmt.executeUpdate();

				if( pstmt != null ) pstmt.close();

				if( cnt != 1 )
					throw new Exception("Orginal Tranasction update(csh_rcpt_iss_seq) fail !");
			}
		} catch (SQLException e ) {
		    StdOut.error("updateTR", "SQLException:" + e.getMessage()+ ", TxNO" + txno );
		    e.printStackTrace();
		    throw new Exception( e.getMessage());
		} catch (Exception e ) {
			StdOut.error("updateTR", "Exception:" + e.getMessage()+ ", TxNO" + txno );
			throw new Exception( e.getMessage());
		} finally {
			DBHandler.closeDBResource(rs, pstmt);
		}


		return param;
	}

}
