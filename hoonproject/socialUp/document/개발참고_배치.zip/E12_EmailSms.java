package skt.tmall.daemon.escrow;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;

import skt.tmall.daemon.common.util.DBHandler;

/**
 * Email SMS ���� ��ġ
 * 	�ֱ� : �� 1ȸ
 *  : ���˸��� �߼�
 *  : ����SMS �߼�
 * @author ZZ07237
 *
 */
public class E12_EmailSms extends EscrowBaseDaemon {

	/**
	 * @param args
	 */
	public static void main(String[] args) {
		E12_EmailSms dm = new E12_EmailSms();
		dm.run();
	}

	public void run() {
		batch_no = 2512;
		batchID = "tmba_bo_12A";
		batchName = "Email ���� ��ġ";
		
		/* ��ø ���� ����  */
		if (isRunning(batch_no)) {
			String errMsg = "�̹� �������Դϴ�";
			log.error(errMsg);
			batchLogPrint(batch_no, null, null, "-1", "User Define Error", "N/A", "Y", errMsg, errMsg);
			return;
		}
		
		run_email();
		run_sms();
	}

	public void run_email() {
		batchID = "tmba_bo_12A";
		this.batchName = "Email ���� ��ġ";

		batchLogStart(batch_no,"Email ���� ��ġ");

		log.debug("===== "+batchName+" START =====");

		Connection conn = null;
		PreparedStatement pstmt = null;
		ResultSet rs = null;
		
		StringBuffer buff = new StringBuffer();
		buff.append("	BEGIN 									\n");
		buff.append("   	SP_TR_DEMAND_MAIL;					\n");
		buff.append("	END;									\n");

		try {
			conn = DBHandler.getConnection(dbUrl,dbId,dbPwd);
			if (conn == null) {
				log.error("Connection is NULL !!!");
				throw new Exception("Connection is NULL !!!");
			}
			
			pstmt = conn.prepareStatement(buff.toString());
			pstmt.execute();
			
			DBHandler.closeDBResource(rs,pstmt);
			DBHandler.closeDBResource(conn);
			
			batchLogEnd(batch_no, "0", "Success", "N/A", "N", "���˸��� ������ ����", null);
			
		} catch (Exception e) {
			batchLogEnd(batch_no, "-1", "ERROR", "N/A", "Y", "���˸��� ������  ����", "���˸��� ������  ����");
			log.error(e.toString());
		} finally {
			try {
				DBHandler.closeDBResource(rs,pstmt);
				DBHandler.closeDBResource(conn);
			} catch (Exception e) {}

			log.debug("===== "+batchName+" END =====");
		}
	}

	public void run_sms() {
		batchID = "tmba_bo_12B";
		this.batchName = "SMS ���� ��ġ";

		log.debug("===== "+batchName+" START =====");
		batchLogStart(batch_no,"SMS ���� ��ġ");

		Connection conn = null;
		PreparedStatement pstmt = null;
		ResultSet rs = null;
		
		StringBuffer buff = new StringBuffer();
		buff.append("	BEGIN 									\n");
		buff.append("   	SP_TR_DEMAND_SMS('','','','','');	\n");
		buff.append("	END;									\n");

		try {
			conn = DBHandler.getConnection(dbUrl,dbId,dbPwd);
			if (conn == null) {
				log.error("Connection is NULL !!!");
				throw new Exception("Connection is NULL !!!");
			}
			
			pstmt = conn.prepareStatement(buff.toString());
			pstmt.execute();
			
			DBHandler.closeDBResource(rs,pstmt);
			DBHandler.closeDBResource(conn);
			
			batchLogEnd(batch_no, "0", "Success", "N/A", "N", "����SMS ������ ����", null);
			
		} catch (Exception e) {
			batchLogEnd(batch_no, "-1", "ERROR", "N/A", "Y", "����SMS ������  ����", "����SMS ������  ����");
			log.error(e.toString());
		} finally {
			try {
				DBHandler.closeDBResource(rs,pstmt);
				DBHandler.closeDBResource(conn);
			} catch (Exception e) {}

			log.debug("===== "+batchName+" END =====");
		}
	}
} // end of class
