package skt.tmall.daemon.escrow;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;

import skt.tmall.bdt.transfer.mail.EmailRequestBO;
import skt.tmall.bdt.transfer.mail.EmailUserInfo;
import skt.tmall.common.TmallException;
import skt.tmall.daemon.common.util.DBHandler;

import skt.tmall.process.share.remittance.remittancesummary.service.EmailService;
import skt.tmall.process.share.remittance.remittancesummary.service.EmailServiceImpl;
import com.skt.omp.common.util.DateTime;

public class E21_SellerEscrowInfoEmail extends EscrowBaseDaemon {


    private static EmailRequestBO mailRequest = null;
    private static EmailUserInfo mailUsers = null;
    private EmailService service = null;
    private final String mailSubject = "[11����] �Ǹ� ���� ��Ȳ�� �˷��帳�ϴ�.";
    private static final String curDate = DateTime.getFormatString("yyyy��MM��dd��");
    //private boolean useTrunc;
    //private long megaBytes = 1024 * 1024;
    private boolean debugMode = false;
    private static final String dblink = "@scrt_link";

    /**
     * ������� ������ȣ
     */
    private long defaultSellerNo = 10000005;
    private volatile int send_count = 0;
    private static final int update_limit = 50;
    private long totalcount = 0;

    //private final StringBuilder selectSQL = null;

    public E21_SellerEscrowInfoEmail() throws Exception {
        batchName = "�������ǽ� ��� ���� ���ø�";
        batch_no = 2521;

        try {
            super.initSqlMap();

            /* ��ø ���� ����
            if (isRunning(batch_no)) {
                String errMsg = "�̹� �������Դϴ�:";
                log.error(errMsg);
                batchLogPrint(batch_no, null, null, "-1", "User Define Error", "N/A", "Y", errMsg, errMsg);
                return;
            }*/

            mailRequest = new EmailRequestBO();
            mailRequest.setTemplateId(303);    //TID_199 templateId : �������ǽ� ��� ���� ���ø�);
            mailRequest.setSubject(mailSubject);
            mailRequest.setResponseTerm(7);
            service = new EmailServiceImpl();

            boolean clearSummery = emailDefaultBatch();
            if(!clearSummery) {
                summeryBatch();
                clearSummery = emailDefaultBatch();
            } else {
            	 log.error("���� ��߼�  �� : " + totalcount);
            }


        } catch(Exception e) {
            log.error(batchName + " FATAL : SqlMapLoader.init()");
            throw new TmallException(e.toString());
        } finally {
            mailUsers = null;
            mailRequest = null;
            service = null;
            log.error("������ ���� �Ǹ��� �� : " + totalcount);
        }

    }

    private void sendEmailService() throws Exception  {

        long errCnt = service.sendEmailChecked(mailRequest); //���⸸ �ּ� ������ ���� �߼� ����.

        if(errCnt > 0) {
            log.error("�Ǹ��� �Ǹ���Ȳ ���� �߼� ���� : �ȿ (�����)");
            throw new Exception("�Ǹ��� �Ǹ���Ȳ ���� �߼� ���� : �ȿ (�����)");

        }

        mailRequest = new EmailRequestBO();
        mailRequest.setTemplateId(303);    //TID_199 templateId : �������ǽ� ��� ���� ���ø�);
        mailRequest.setSubject(mailSubject);
        mailRequest.setResponseTerm(7);
    }

    /**
     * @param args
     * @throws Exception
     */
    public static void main( String[] args ) throws Exception {

        E21_SellerEscrowInfoEmail selelrEscrow = new E21_SellerEscrowInfoEmail();
    }

    /**
     *    SELLER_SELL_SUMMARY ���̺��� ���� �߼� ���� ���� <br>
     *    �Ǹ��ڸ� �ٽ� ���� �߼� ó�� �Ѵ�. <br>
     * @return boolean
     * @throws Exception
     */
    private boolean emailDefaultBatch()  throws Exception {
        Connection conn = null;
        PreparedStatement pstmt = null;
        String query = null;
        ResultSet rs = null;
        String sellerNo = null;
        boolean emailSend = false;

        try {

            conn = DBHandler.getConnection(dbUrl,dbId,dbPwd);
            //conn.setAutoCommit(false); DBHandler�� �ϰ� ����
            query = this.getEmailSendSQL().toString();              // step 1
            pstmt = conn.prepareStatement(query);
            pstmt.setLong(1, defaultSellerNo);
            rs = pstmt.executeQuery();



            /*
             * SELLER_SELL_SUMMARY�� ����Ÿ�� send_yn�� N�� ����Ÿ�� ������
             * �ش� ����Ÿ�� mail���� ���̺��� ���ε��Ѵ�.
             */
            if(rs.next()) {

                /**
                 * rs.next()��  �Ҷ� �Ź� ����Ÿ�� ���྿ ���� �������� ���� �ƴϸ�,
                 * ������ ��(data fefch size)��ƴ �����͸� ���ڿɴϴ�.
                 * ������ ũ���� ���� �����ϴ� ResultSet.setFetchSize(int rows)
                 * �� ���� �޼��尡 �ֽ��ϴ�.
                 */
                rs.setFetchSize(100);

                boolean hasNext = false;
                do {
                   sellerNo = rs.getString("SELLER_MEM_NO");
                   //log.debug(sellerNo);
                   boolean commitTime = sendEmailSummery(rs);    // step 2

                   if(commitTime) {
                       sendEmailService();                             // step 3
                       commitTime = updateSendSuccess(conn, sellerNo); // step 4
                       conn.commit();
                       //log.debug(sellerNo + " �������" );
                       totalcount = totalcount + send_count;
                       send_count = 0;
                   }
                }while(hasNext = rs.next());

                if(send_count > 0) {
                    sendEmailService();
                    updateSendSuccess(conn, sellerNo);
                    totalcount = totalcount + send_count;

                }
                emailSend = true;
            }

        } catch (SQLException e) {
            conn.rollback();
            log.error(e.toString());
            throw new SQLException(e.toString());
        } catch (Exception e) {
            conn.rollback();
            log.error(e.toString());
            throw new Exception(e.toString());
        } finally {
            conn.commit();
            conn.setAutoCommit(true);
            DBHandler.closeDBResource(rs,pstmt);
            DBHandler.closeDBResource(conn);
            mailUsers = null;
            log.debug("===== "+batchName+" ���� END =====");
        }
        return emailSend;
    }

    /**
     * seller_sell_summary�� ���̺��� truncate �ϰ�, �ش絥��Ÿ�� <br>
     * �������� insert ���� ��
     * @throws Exception
     */
    private void summeryBatch() throws Exception {
        Connection conn = null;
        try {
            conn = DBHandler.getConnection(dbUrl,dbId,dbPwd);
            //conn.setAutoCommit(false); DBHandler �� �ϰ� ����
            boolean commitTime = truncateSummery(conn);

            if(commitTime) {
              commitTime = insertSummery(conn);
              conn.commit();
            }

        } catch (SQLException e) {
            conn.rollback();
            log.error(e.toString());
            throw new SQLException(e.toString());
        } finally {
            conn.commit();
            conn.setAutoCommit(true);
            DBHandler.closeDBResource(conn);
            log.debug("===== "+batchName+" ���� END =====");
        }
    }


    /**
     *
     * <P/>
     * email �߼� ���̺��� �ش� �Ǹ��ڸ� insert �Ѵ�.
     * ȸ�����°�(MB_MEM.mem_stat_cd = 01) �����϶��� �߼� ó�� �Ѵ�.
     * @param conn
     * @param rs
     * @return
     * @throws Exception
     */
    private boolean sendEmailSummery(ResultSet rs) throws Exception {

        ResultSet rset = rs;

        boolean commitTime = false;

        if(rset.getString("MEM_STAT_CD").equals("01")) {
            mailUsers = new EmailUserInfo();
            mailUsers.setUserId(rset.getString("MEM_ID"));     // ������ ���� T-mall ȸ�� ���̵�
            mailUsers.setName(rset.getString("MEM_NM"));              // ȸ�� �̸�
            mailUsers.setEmail(rs.getString("EMAIL_DETAIL").trim());                  // leave1@nate.com ȸ�� ���� �ּ� rs.getString("EMAIL_DETAIL");
            //mailUsers.setEmail("leave1@nate.com");
            mailUsers.setStaticData(                                 // ���� ���ø��� ������ ���� �Ķ����
                              new String[] {
                               rset.getString("MEM_NM")                // FIELD1 �̸�(��ȣ)
                              ,curDate                               // FIELD2 �������
                              ,rset.getString("SETTLE")                // FIELD3 ����Ȯ��
                              ,rset.getString("CONFIRM")              // FIELD4 �߼�ó���� ����
                              ,rset.getString("CANCELING")            // FIELD5 ��ҽ�û
                              ,rset.getString("RETURNING")            // FIELD6 ��ǰ��û
                              ,rset.getString("EXCHANGE")             // FIELD7 ��ȯ��û
                              ,rset.getString("REDELIVERY")           // FIELD8 ���۽�û
                              ,rset.getString("QUESTION")             // FIELD9 Q&A �̴�
                              ,rset.getString("NOTIFI")               // FIELD10 �˸���
                              ,rset.getString("delivery_delay")       // FIELD11 �������
                              ,rset.getString("auto_return")          // FIELD12 �ڵ���ǰ�Ϸ�
                              ,rset.getString("auto_exchange")        // FIELD13 �ڵ���ȯ����
                              ,rset.getString("workday")              // FIELD14 �ڵ�ó����
                              ,rset.getString("AUTO_CANCEL_APPROVE")  // FIELD15 �ڵ���ҿϷ�
                              ,rset.getString("approveDay")           // FIELD16 �ڵ������
                              ,rset.getString("DELAY_REPORT")         // FIELD17 �߼������ȳ�
                              });

            send_count++;
            mailRequest.addUserInfo(mailUsers);
        }
        //System.out.println(mailUsers.toString());
        if(send_count == update_limit) {
            commitTime = true;
        }
        return commitTime;
        //mailRequest.addUserInfo(mailUsers);
    }

    /**
     *
     * <P/>
     * email ���̺��� ������Ʈ �Ǹ�, SELLER_SELL_SUMMERY�� Ư�� �Ǹ����� send_yn�� Y�� ������Ʈ ��.
     * @param conn
     * @param seller_mem_no
     * @return
     * @throws SQLException
     */
    private boolean updateSendSuccess(Connection conn, String seller_mem_no) throws SQLException {
        PreparedStatement pstmt = null;
        String query = null;
        String seller_no = null;
        int incnt = 0;
        boolean commitTime = false;

        try {
            query = this.getUpdateSQL().toString();
            seller_no = seller_mem_no;
            pstmt = conn.prepareStatement(query.toString());
            pstmt.setString(1, seller_no);

            incnt = pstmt.executeUpdate();

            if(incnt > 0) {
                commitTime = true;
            }

        } finally {
            pstmt.close();
        }
        return commitTime;

    }

    /*
     * SHREK_SELLER_SELL_SUMMERY ����Ÿ�� truncate�Ѵ�.
     */
    private boolean truncateSummery(Connection conn) throws SQLException {
        Statement stmt = null;
        boolean commitTime = false;
        try {
            log.debug("TRUNCATE TABLE SELLER_SELL_SUMMARY Start ...");
            stmt = conn.createStatement();
            stmt.executeUpdate(" TRUNCATE TABLE SELLER_SELL_SUMMARY ");
            log.debug("TRUNCATE TABLE SELLER_SELL_SUMMARY End!");
            commitTime =true;
        } finally {
            stmt.close();
        }
        return commitTime;
    }


    private boolean insertSummery(Connection conn) throws SQLException {
        PreparedStatement pstmt = null;
        String query = null;
        int incnt = 0;
        boolean commitTime = false;

        try {
            query = this.getInsertBatchSQL(debugMode).toString();
            System.out.println(query);
            pstmt = conn.prepareStatement(query.toString());
            incnt = pstmt.executeUpdate();
            commitTime = true;
        } finally {
            pstmt.close();
        }

        return commitTime;
    }



    /**
     * �Ǹ����� ��踦 ������ �ٷ� insert�Ѵ�
     * @param debugMode (Ư�������� �׽�Ʈ��)
     * @return
     */
    private StringBuilder getInsertBatchSQL(boolean debugMode) {

        final StringBuilder selectSQL = new StringBuilder();
            selectSQL.append("  insert   into SELLER_SELL_SUMMARY (SELLER_MEM_NO                                    ");
            selectSQL.append("                                        ,SETTLE                                                   ");
            selectSQL.append("                                        ,CONFIRM                                                  ");
            selectSQL.append("                                        ,CANCELING                                                ");
            selectSQL.append("                                        ,RETURNING                                                ");
            selectSQL.append("                                        ,EXCHANGE                                                 ");
            selectSQL.append("                                        ,REDELIVERY                                               ");
            selectSQL.append("                                        ,NOTIFI                                                   ");
            selectSQL.append("                                        ,QUESTION                                                 ");
            selectSQL.append("                                        ,DELIVERY_DELAY											");
            selectSQL.append("                                        ,auto_return                                              ");
            selectSQL.append("                                        ,auto_exchange                                            ");
            selectSQL.append("										  ,AUTO_CANCEL_APPROVE                                      ");
       		selectSQL.append("										  ,DELAY_REPORT                                             ");
            selectSQL.append("                                        ,workday                                                   ");
            selectSQL.append("                                        ,approveDay											    ");
            selectSQL.append("                                        ,SEND_KIND_TYPE                                            ");
            selectSQL.append("                                        ,CREATE_DT)                                                ");
            selectSQL.append(" SELECT                                                                                             ");
            selectSQL.append("      seller_mem_no                                                                                 ");
            selectSQL.append("      ,sum(case stat when 'settle' then cnt else 0 end) as settle                                   ");
            selectSQL.append("      ,sum(case stat when 'confirm' then cnt else 0 end) as  confirm                                ");
            selectSQL.append("      ,sum(case stat when 'canceled' then cnt else 0 end) as  canceling                             ");
            selectSQL.append("      ,sum(case stat when 'returning' then cnt else 0 end) as  returning                            ");
            selectSQL.append("      ,sum(case stat when 'exchange' then cnt else 0 end) as  exchange                              ");
            selectSQL.append("      ,sum(case stat when 'redelivery' then cnt else 0 end)  as redelivery                          ");
            selectSQL.append("      ,sum(case stat when 'notifi' then cnt else 0 end) as notifi                                   ");
            selectSQL.append("      ,sum(case stat when 'question' then cnt else 0 end) as question                               ");
            selectSQL.append("      ,sum(case stat when 'DELIVERY_DELAY' then cnt else 0 end) as DELIVERY_DELAY                   ");
            selectSQL.append("      ,sum(case stat when 'auto_return' then cnt else 0 end) as auto_return                         ");
            selectSQL.append("      ,sum(case stat when 'auto_exchange' then cnt else 0 end) as auto_exchange                     ");
            selectSQL.append("      ,sum(case stat when 'AUTO_CANCEL_APPROVE' then cnt else 0 end) as AUTO_CANCEL_APPROVE         ");
            selectSQL.append("      ,sum(case stat when 'DELAY_REPORT' then cnt else 0 end) as DELAY_REPORT                       ");
            selectSQL.append("      ,to_char(to_date(FN_SY_CALENDAR('+', '3', sysdate ), 'YYYYMMDD'), 'MM/DD') as workday         ");
            selectSQL.append("      ,to_char(to_date(FN_SY_CALENDAR('+', '1', sysdate ), 'YYYYMMDD'), 'MM/DD') as approveDay      ");
            selectSQL.append("      ,'M'                                                                                          ");
            selectSQL.append("      ,'1111111112'                                                                                 ");
            selectSQL.append("  FROM (                                                                                            ");
            selectSQL.append("      SELECT seller_mem_no,                                                                         ");
            selectSQL.append("          case when ord_prd_stat = '202' then 'settle'                                              ");
            selectSQL.append("                  when ord_prd_stat = '301' then  'confirm'                                         ");
            selectSQL.append("                  when ord_prd_stat = '701' then 'canceled'                                         ");
            selectSQL.append("          end as stat                                                                               ");
            selectSQL.append("          ,count(1) as cnt                                                                          ");
            selectSQL.append("      FROM tr_ord_prd                                                                               ");
            selectSQL.append("      WHERE ord_dt > sysdate - 30                                                                   ");
            selectSQL.append("      AND ord_no > to_char(sysdate - 30 , 'yyyymmdd')||'0000000'                                    ");
if(debugMode) selectSQL.append("      AND seller_mem_no = 20224331                                                                ");
            selectSQL.append("      AND ord_prd_stat in ('301', '202', '701')                                                     ");
            selectSQL.append("      group by seller_mem_no, ord_prd_stat                                                          ");
            selectSQL.append("      union all                                                                                     ");
            selectSQL.append("      SELECT b.seller_mem_no,                                                                       ");
            selectSQL.append("          case when  a.clm_stat = '105' then 'returning'                                            ");
            selectSQL.append("                  when  a.clm_stat = '201' then 'exchange'                                          ");
            selectSQL.append("                  when  a.clm_stat = '301' then 'redelivery'                                        ");
            selectSQL.append("          end as stat                                                                               ");
            selectSQL.append("          ,count(1) as cnt                                                                          ");
            selectSQL.append("      FROM tr_ord_clm_req_prd a, tr_ord_prd b                                                       ");
            selectSQL.append("      WHERE a.req_dt > sysdate - 30                                                                 ");
            selectSQL.append("      AND a.clm_stat in ( '105' , '201', '301')                                                     ");
if(debugMode) selectSQL.append("      AND seller_mem_no = 20224331                                                                ");
            selectSQL.append("      AND a.ord_no=b.ord_no                                                                         ");
            selectSQL.append("      AND a.ord_prd_seq=b.ord_prd_seq                                                               ");
            selectSQL.append("      group by b.seller_mem_no, a.clm_stat                                                          ");
            selectSQL.append("      union all                                                                                     ");
            selectSQL.append("      SELECT mem_no as seller_mem_no,'notifi' as stat, count(1) as cnt from CC_EMER_NTCE            ");
            selectSQL.append("      WHERE create_dt > sysdate - 30                                                                ");
            selectSQL.append("      AND EMER_NTCE_CRNT_CD IN ('01', '02','04')                                                    ");
if(debugMode) selectSQL.append("      AND mem_no = 20224331                                                                       ");
            selectSQL.append("      group by mem_no                                                                               ");
            selectSQL.append("      union all                                                                                     ");
            selectSQL.append("      SELECT /*+ use_nl(a b) */                                                                     ");
            selectSQL.append("           b.sel_mnbd_no                                                                            ");
            selectSQL.append("           ,'question' as stat                                                                      ");
            selectSQL.append("           ,sum(cnt) as cnt                                                                         ");
            selectSQL.append("      FROM (                                                                                        ");
            selectSQL.append("          SELECT /*+ use_hash(a b) parallel(a 2) full(a) */                                         ");
            selectSQL.append("              a.brd_info_clf_no,                                                                    ");
            selectSQL.append("              count(1) cnt                                                                          ");
            selectSQL.append("          FROM cm_unity_brd_info a ,(                                                               ");
            selectSQL.append("              SELECT                                                                                ");
            selectSQL.append("                  aa.brd_info_no sub_info_no,                                                       ");
            selectSQL.append("                  hgrnk_brd_info_no                                                                 ");
            selectSQL.append("              FROM cm_unity_brd_info aa                                                             ");
            selectSQL.append("              WHERE unity_brd_no = '3'                                                              ");
            selectSQL.append("              AND brd_info_clf = '02'                                                               ");
            selectSQL.append("              AND del_yn = 'N'                                                                      ");
            selectSQL.append("              AND hgrnk_brd_info_no != '0' ) d                                                      ");
            selectSQL.append("          WHERE unity_brd_no = '3'                                                                  ");
            selectSQL.append("          AND brd_info_clf = '02'                                                                   ");
            selectSQL.append("          AND del_yn = 'N'                                                                          ");
            selectSQL.append("          AND a.hgrnk_brd_info_no = '0'                                                             ");
            selectSQL.append("          AND a.brd_info_no = d.hgrnk_brd_info_no(+)                                                ");
            selectSQL.append("          AND d.sub_info_no is null                                                                 ");
            selectSQL.append("          AND a.create_dt > sysdate - 30                                                            ");
            selectSQL.append("          group by a.brd_info_clf_no ) a, pd_prd b                                                  ");
            selectSQL.append("      WHERE a.brd_info_clf_no = b.prd_no                                                            ");
if(debugMode) selectSQL.append("      AND b.sel_mnbd_no = 20224331                                                                ");
            selectSQL.append("      group by b.sel_mnbd_no                                                                        ");
            selectSQL.append(" union all                                                                                       ");
            selectSQL.append(" select                                                                    							");
            selectSQL.append("     aa.seller_mem_no                                                     							");
            selectSQL.append("     ,'DELIVERY_DELAY' as DELIVERY_DELAY                                                              ");
            selectSQL.append("     ,count(1) as cnt                                                      							");
            selectSQL.append(" from                                                                      							");
            selectSQL.append("       (                                                                   							");
            selectSQL.append("         select                                                            							");
            selectSQL.append("             seller_mem_no                                                 							");
            selectSQL.append("             ,ord_no                                                       							");
            selectSQL.append("             ,ord_stl_end_dt                                               							");
            selectSQL.append("             ,trunc(sysdate) - trunc(a.ord_stl_end_dt)                     							");
            selectSQL.append("                     - (select count(1) from sy_off_dy where solar_dy      							");
            selectSQL.append("                         between to_char(a.ord_stl_end_dt, 'YYYYMMDD')     							");
            selectSQL.append("                         and to_char(sysdate, 'YYYYMMDD')                  							");
            selectSQL.append("                         and hldy_yn = 'Y' and weekdy !=7 )                							");
            selectSQL.append("              as total_day                                                 							");
            selectSQL.append("         from tr_ord_prd a                                                 							");
            selectSQL.append("         WHERE ord_dt > sysdate - 30                                       							");
            selectSQL.append("         AND ord_no > to_char(sysdate - 30 , 'yyyymmdd')||'0000000'        							");
            selectSQL.append("         and ord_prd_stat in ('202', '301')                                							");
if(debugMode) selectSQL.append("         and seller_mem_no = 20224331                                    							");
            selectSQL.append("       ) aa                                                                							");
            selectSQL.append(" where aa.total_day >= 3                                                   							");
            selectSQL.append(" group by aa.seller_mem_no                                                                          ");
            selectSQL.append("    union all                                                                                       ");
			selectSQL.append("       SELECT  seller_mem_no_de                                                                     ");
		    selectSQL.append("               ,case when clm_occr_typ  = '01' then 'auto_return' 								  ");
		    selectSQL.append("                     when clm_occr_typ  = '02' then 'auto_exchange'                                 ");
		    selectSQL.append("                end as auto_clm  														              ");
		    selectSQL.append("               ,count(*) as cnt                                                                                                                                                                                                   ");
		    selectSQL.append("       FROM                                                                                                                                                                                                               ");
		    selectSQL.append("       (                                                                                                                                                                                                                  ");
		    selectSQL.append("        select                                                                                                                                                                                                            ");
		    selectSQL.append("           seller_mem_no_de                                                                                                                                                                                              ");
		    selectSQL.append("           ,ord_no	                                                                                                                                                                                                      ");
		 	selectSQL.append("           ,ord_prd_seq	                                                                                                                                                                                                    ");
		 	selectSQL.append("           ,clm_req_seq	                                                                                                                                                                                                    ");
		 	selectSQL.append("           ,clm_stat	                                                                                                                                                                                                      ");
		 	selectSQL.append("           ,clm_occr_typ	                                                                                                                                                                                                  ");
		      selectSQL.append("      from                                                                                                                                                                                                               ");
		      selectSQL.append("               (                                                                                                                                                                                                      ");
		      selectSQL.append("               select                                                                                                                                                                                                 ");
		      selectSQL.append("           				/*+ no_expand leading(crp ocd cdd) use_hash(crp ocd) full(crp) parallel(crp 4) index_ffs(ocd FK1_TR_ORD_CLM_DELVPLACE) parallel_index(ocd FK1_TR_ORD_CLM_DELVPLACE 4) use_nl(ocd cdd)*/       ");
		      selectSQL.append("                       crp.seller_mem_no_de                                                                                                                                                                           ");
		      selectSQL.append("                       ,crp.ord_no                                                                                                                                                                                    ");
		      selectSQL.append("                       ,crp.ord_prd_seq                                                                                                                                                                               ");
		      selectSQL.append("                       ,crp.clm_req_seq                                                                                                                                                                               ");
		      selectSQL.append("                       ,crp.clm_stat                                                                                                                                                                                  ");
		      selectSQL.append("                       ,crp.clm_occr_typ                                                                                                                                                                              ");
		      selectSQL.append("               from                                                                                                                                                                                                   ");
		      selectSQL.append("               tr_ord_clm_dlv_dtls cdd                                                                                                                                                                                ");
		      selectSQL.append("               ,tr_ord_clm_delvplace ocd                                                                                                                                                                              ");
		      selectSQL.append("               ,tr_ord_clm_req_prd crp                                                                                                                                                                                ");
		      selectSQL.append("                                                                                                                                                                                                                      ");
		      selectSQL.append("               where  cdd.dlv_end_dt between  to_date(FN_SY_CALENDAR('-', '2', sysdate )  ,'YYYYMMDD') and to_date(FN_SY_CALENDAR('-', '2', sysdate ) || '235959' ,'YYYYMMDDHH24MISS')                                ");
		      selectSQL.append("               and ( (ocd.ord_clm_dlv_clf = '04' and clm_occr_typ = '01') or ( ocd.ord_clm_dlv_clf = '04' and clm_occr_typ = '02' )  ) /* ��ǰ��  04 , ��ȯ�� ��߼۰� 02 */                                          ");
		      selectSQL.append("               and ocd.delvplace_seq = cdd.delvplace_seq                                                                                                                                                              ");
		      selectSQL.append("               and crp.clm_req_seq =  ocd.ord_clm_seq                                                                                                                                                                 ");
		      //selectSQL.append("               --��ǰ��û����/��ȯ��û,����,����                                                                                                                                                                      ");
		      selectSQL.append("               and crp.req_dt >= to_date('20091224','YYYYMMDD')                                                                                                                                                     ");
		      selectSQL.append("               and crp.clm_stat  in ('105','101','201','211')                                                                                                                                                         ");
		      //selectSQL.append("               -- and crp.ord_no = 200912168150153                                                                                                                                                                    ");
  if(debugMode) selectSQL.append("             AND crp.seller_mem_no_de = 20224331                                                                                                                                    ");
		      selectSQL.append("               union all                                                                                                                                                                                              ");
		      selectSQL.append("                                                                                                                                                                                                                      ");
		      //selectSQL.append("               --  ��ǰ��û�������� + ��ۿϷ��Ͼ���  �Ǵ�  ��ȯ��û,���� + ��ۿϷ��Ͼ���  (�����Ϻ��� ������ 15����)                                                                                                ");
		      selectSQL.append("               select                                                                                                                                                                                                 ");
		      selectSQL.append("                       crp.seller_mem_no_de                                                                                                                                                                           ");
		      selectSQL.append("                       ,crp.ord_no                                                                                                                                                                                    ");
		      selectSQL.append("                       ,crp.ord_prd_seq                                                                                                                                                                               ");
		      selectSQL.append("                       ,crp.clm_req_seq                                                                                                                                                                               ");
		      selectSQL.append("                       ,crp.clm_stat                                                                                                                                                                                  ");
		      selectSQL.append("                       ,crp.clm_occr_typ                                                                                                                                                                              ");
		      selectSQL.append("               from                                                                                                                                                                                                   ");
		      selectSQL.append("               tr_ord_clm_req_prd crp                                                                                                                                                                                 ");
		      selectSQL.append("               where crp.req_dt between  to_date(FN_SY_CALENDAR('-', '12', sysdate )  ,'YYYYMMDD') and to_date(FN_SY_CALENDAR('-', '12', sysdate ) || '235959' ,'YYYYMMDDHH24MISS')                                   ");
		      //selectSQL.append("               --��ǰ��û����/��ȯ��û,����,����                                                                                                                                                                      ");
		      selectSQL.append("               and crp.req_dt >= to_date('20091224','YYYYMMDD')                                                                                                                                                     ");
		      selectSQL.append("               and crp.clm_stat  in ('105','101','201','211')                                                                                                                                                         ");
		      //selectSQL.append("               -- and crp.ord_no = 200912168150153                                                                                                                                                                    ");
if(debugMode) selectSQL.append("               AND crp.seller_mem_no_de = 20224331                                                                                                                                    ");
		      selectSQL.append("               union all                                                                                                                                                                                              ");
		      selectSQL.append("                                                                                                                                                                                                                      ");
		      //selectSQL.append("               --  ��ǰ����+ ��ۿϷ�������  �Ǵ�  ��ȯ���� + ��ۿϷ�������                                                                                                                                          ");
		      selectSQL.append("               select  /*+ no_expand leading(crp ocd cdd) use_hash(crp ocd) full(crp) parallel(crp 4) index_ffs(ocd FK1_TR_ORD_CLM_DELVPLACE) parallel_index(ocd FK1_TR_ORD_CLM_DELVPLACE 4) use_nl(ocd cdd)*/        ");
		      selectSQL.append("                       crp.seller_mem_no_de                                                                                                                                                                           ");
		      selectSQL.append("                       ,crp.ord_no                                                                                                                                                                                    ");
		      selectSQL.append("                       ,crp.ord_prd_seq                                                                                                                                                                               ");
		      selectSQL.append("                       ,crp.clm_req_seq                                                                                                                                                                               ");
		      selectSQL.append("                       ,crp.clm_stat                                                                                                                                                                                  ");
		      selectSQL.append("                       ,crp.clm_occr_typ                                                                                                                                                                              ");
		      selectSQL.append("               from                                                                                                                                                                                                   ");
		      selectSQL.append("               tr_ord_clm_dlv_dtls cdd                                                                                                                                                                                ");
		      selectSQL.append("               ,tr_ord_clm_delvplace ocd                                                                                                                                                                              ");
		      selectSQL.append("               ,tr_ord_clm_req_prd crp                                                                                                                                                                                ");
		      selectSQL.append("               where  cdd.dlv_end_dt between  to_date(FN_SY_CALENDAR('-', '7', sysdate )  ,'YYYYMMDD') and to_date(FN_SY_CALENDAR('-', '7', sysdate ) || '235959' ,'YYYYMMDDHH24MISS')                                ");
		      selectSQL.append("               and ( (ocd.ord_clm_dlv_clf = '04' and clm_occr_typ = '01') or ( ocd.ord_clm_dlv_clf = '04' and clm_occr_typ = '02' )  ) /* ��ǰ��  04 , ��ȯ�� ��߼۰� 02 */                                          ");
		      selectSQL.append("               and ocd.delvplace_seq = cdd.delvplace_seq                                                                                                                                                              ");
		      selectSQL.append("               and crp.clm_req_seq =  ocd.ord_clm_seq                                                                                                                                                                 ");
		      //selectSQL.append("               --��ǰ��û����/��ȯ��û,����,����                                                                                                                                                                      ");
		      selectSQL.append("               and crp.req_dt >= to_date('20091224','YYYYMMDD')                                                                                                                                                     ");
		      selectSQL.append("               and crp.clm_stat  in ('104','214')                                                                                                                                                                     ");
if(debugMode) selectSQL.append("               AND crp.seller_mem_no_de = 20224331                                                                                                                                    ");
		      //selectSQL.append("               -- and crp.ord_no = 200912168150153                                                                                                                                                                    ");
		      selectSQL.append("               union all                                                                                                                                                                                              ");
		      selectSQL.append("                                                                                                                                                                                                                      ");
		      //selectSQL.append("               --  ��ǰ����+ ��ۿϷ��Ͼ���  �Ǵ�  ��ȯ���� + ��ۿϷ��Ͼ���                                                                                                                                          ");
		      selectSQL.append("               select                                                                                                                                                                                                 ");
		      selectSQL.append("                       crp.seller_mem_no_de                                                                                                                                                                           ");
		      selectSQL.append("                       ,crp.ord_no                                                                                                                                                                                    ");
		      selectSQL.append("                       ,crp.ord_prd_seq                                                                                                                                                                               ");
		      selectSQL.append("                       ,crp.clm_req_seq                                                                                                                                                                               ");
		      selectSQL.append("                       ,crp.clm_stat                                                                                                                                                                                  ");
		      selectSQL.append("                       ,crp.clm_occr_typ                                                                                                                                                                              ");
		      selectSQL.append("               from                                                                                                                                                                                                   ");
		      selectSQL.append("               tr_ord_clm_req_prd crp                                                                                                                                                                                 ");
		      selectSQL.append("               where crp.req_dt between  to_date(FN_SY_CALENDAR('-', '17', sysdate )  ,'YYYYMMDD') and to_date(FN_SY_CALENDAR('-', '17', sysdate ) || '235959' ,'YYYYMMDDHH24MISS')                                   ");
		      //selectSQL.append("               --��ǰ��û����/��ȯ��û,����,����                                                                                                                                                                                                              																						  	  ");
		      selectSQL.append("               and crp.req_dt >= to_date('20091224','YYYYMMDD')                                                                                                                                                     ");
		      selectSQL.append("               and crp.clm_stat  in ('104','214')                                                                                                                                                                     ");
if(debugMode) selectSQL.append("               AND crp.seller_mem_no_de = 20224331                                                                                                                                    ");
		      //selectSQL.append("               -- and crp.ord_no = 200912168150153                                                                                                                                                                    ");
		      selectSQL.append("               )                                                                                                                                                                                                      ");
		      selectSQL.append("        group by                                                                                                                                                                                                      ");
		      selectSQL.append("        seller_mem_no_de,ord_no,ord_prd_seq,clm_req_seq,clm_stat,clm_occr_typ	                                                                                                                                      ");
		      selectSQL.append("       	 )                                                                                                                                                                                                            ");
 			  selectSQL.append("      group by seller_mem_no_de,clm_occr_typ                                                                                                                                                                               ");
 			  selectSQL.append("  union all                                                                                                                                   ");
 			  selectSQL.append("  	SELECT /* �Ǹ��ں� 1�������� ��ҿϷ� �����ΰ� */                                                                                             ");
 			  selectSQL.append("      	   a.seller_mem_no_de                                                                                                                 ");
 			  selectSQL.append("        		,'AUTO_CANCEL_APPROVE' as AUTO_CANCEL_APPROVE                                                                                 ");
 			  selectSQL.append("        		, count(1) as cnt                                                                                                             ");
 			  selectSQL.append("  FROM   tr_ord_prd_cn_dtls a, mb_mem b, tr_ord_prd c, dp_disp_ctgr d                                                                         ");
 			  selectSQL.append("  WHERE  to_date(FN_SY_CALENDAR('-', '2', sysdate) || '235959', 'YYYYMMDDHH24MISS') >=  a.ord_cn_req_dt /* ��ҽ�û�� 1 �������� ������ */        ");
 			  selectSQL.append("  AND    a.ord_cn_stat_cd = '01'                                                                                                              ");
 			  selectSQL.append("  AND    a.seller_mem_no_de = b.mem_no                                                                                                           ");
 			  selectSQL.append("  AND    a.ord_no = c.ord_no                                                                                                                  ");
 			  selectSQL.append("  AND    a.ord_prd_seq = c.ord_prd_seq                                                                                                        ");
 			  selectSQL.append("  AND    c.disp_ctgr_no = d.disp_ctgr_no                                                                                                      ");
 			  selectSQL.append("  AND    d.auto_cancel_yn = 'Y'                                                                                                               ");
 			  selectSQL.append("  AND    nvl(b.auto_cancel_yn, 'Y') = 'Y'                                                                                                     ");
 			  selectSQL.append("  AND    a.ord_cn_req_dt > to_date('20100723000000', 'yyyymmddhh24miss')                                                                      ");
 			  selectSQL.append("  AND    a.ord_cn_req_dt > SYSDATE - 10                                                                                                       ");
if(debugMode) selectSQL.append("  AND    a.seller_mem_no_de = 20224331                                                                                                             ");
 			  selectSQL.append("  group by a.seller_mem_no_de                                                                                                                 ");
 			  selectSQL.append(" union all                                                                  														 		  ");
 			  selectSQL.append("    select                                                                  																   ");
 			  selectSQL.append("         a.SELLER_MEM_NO_DE                                                																  		");
 			  selectSQL.append("        ,'DELAY_REPORT' as DELAY_REPORT                                    																	  	 ");
 			  selectSQL.append("        ,count(1) as cnt                                                    														 			 ");
 			  selectSQL.append("    from TR_ORD_DELAY_REPORT a                                              																	 ");
 			  selectSQL.append("    where DELAY_SEND_DT = trunc(sysdate)                                    														 			 ");
if(debugMode) selectSQL.append("    AND   a.seller_mem_no_de = 20224331                                                                                                               ");
 			  selectSQL.append("    group by a.seller_mem_no_de                                             																	 ");
 			  selectSQL.append("      ) kkk                                                                                         ");
            //selectSQL.append("  where rownum <= 100                                                                               ");
            selectSQL.append("  group by seller_mem_no                                                                            ");
            selectSQL.append("  order by seller_mem_no                                                                            ");

        return selectSQL;
    }


    private StringBuilder getUpdateSQL() {
        final StringBuilder updateSQL = new StringBuilder();
        updateSQL.append(" UPDATE /*+INDEX (SELLER_SELL_SUMMARY PK_SELLER_SELL_SUMMARY)*/ ");
        updateSQL.append("                  SELLER_SELL_SUMMARY                           ");
        updateSQL.append("              SET SEND_YN = 'Y'                                 ");
        updateSQL.append("              ,UPDATE_DT = SYSDATE                              ");
        updateSQL.append("              WHERE SELLER_MEM_NO <= :SELLER_MEM_NO             ");
        updateSQL.append("              AND CREATE_DT = '1111111112'                      ");
        updateSQL.append("              AND SEND_YN = 'N'                                 ");
        updateSQL.append("              AND send_kind_type = 'M'                          ");
        return updateSQL;
    }
    /**
     * <P/>
     * SELLER_SELL_SUMMERY ���� email ���̺��� ��ϵ��� ���� ����Ÿ�� �����Ѵ�.
     * @return
     */
    private StringBuilder getEmailSendSQL() {
        final StringBuilder emailSendSQL = new StringBuilder();
        emailSendSQL.append(" SELECT  /*+ ORDERED USE_NL(SUMMARY, MEM, CODE) INDEX (summary PK_SELLER_SELL_SUMMARY)*/ ");
        emailSendSQL.append("          summary.seller_mem_no                                                                ");
        emailSendSQL.append("         ,mem.mem_id                                                                           ");
        emailSendSQL.append("         ,substr(mem.mem_nm, 0, 15) as mem_nm                                                                         ");
        emailSendSQL.append("         ,mem.e_mail||'@'||                                                                    ");
        emailSendSQL.append("          case when e_mailaddr_cd = '01' then                                                  ");
        emailSendSQL.append("              mem.drct_mailaddr                                                                ");
        emailSendSQL.append("              else                                                                             ");
        emailSendSQL.append("                code.dtls_com_nm                                                               ");
        emailSendSQL.append("         end as  email_detail                                                                  ");
        emailSendSQL.append("         ,summary.SETTLE                                                                       ");
        emailSendSQL.append("         ,summary.CONFIRM                                                                      ");
        emailSendSQL.append("         ,summary.CANCELING                                                                    ");
        emailSendSQL.append("         ,summary.RETURNING                                                                    ");
        emailSendSQL.append("         ,summary.EXCHANGE                                                                     ");
        emailSendSQL.append("         ,summary.REDELIVERY                                                                   ");
        emailSendSQL.append("         ,summary.NOTIFI                                                                       ");
        emailSendSQL.append("         ,summary.QUESTION                                                                     ");
        emailSendSQL.append("         ,summary.delivery_delay 														  	    ");
        emailSendSQL.append("         ,summary.auto_return																    ");
        emailSendSQL.append("         ,summary.auto_exchange																");
        emailSendSQL.append("        ,summary.workday      																	");
        emailSendSQL.append("         ,mem.MEM_STAT_CD                                                                     ");
        emailSendSQL.append("         ,summary.AUTO_CANCEL_APPROVE																");
        emailSendSQL.append("         ,summary.approveDay      																	");
        emailSendSQL.append("         ,summary.DELAY_REPORT                                                                     ");
        emailSendSQL.append("  FROM SELLER_SELL_SUMMARY summary, mb_mem mem, sy_co_detail code                              ");
        emailSendSQL.append("  WHERE summary.seller_mem_no > :sellerNo                                                      ");
        emailSendSQL.append("  AND summary.SELLER_MEM_NO = mem.mem_no                                                       ");
        emailSendSQL.append("  AND summary.CREATE_DT = '1111111112'                                                       ");
        //emailSendSQL.append("  AND mem.mem_typ_cd = '02'                                                                    ");
        emailSendSQL.append("  AND mem.e_mailaddr_cd = code.dtls_cd                                                         ");
        emailSendSQL.append("  AND code.grp_cd = 'SY001'                                                                    ");
        emailSendSQL.append("  AND send_yn = 'N'                                                                            ");
        emailSendSQL.append("  AND send_kind_type = 'M'                                                                            ");
       // emailSendSQL.append("  AND  seller_mem_no = 18233194    														");
        //emailSendSQL.append("  AND rownum <  5                                                                    ");

        return emailSendSQL;
    }


    /* ----------------------------------------------------------------------------- */
    private StringBuilder getSelectSql(boolean debugMode) {

        final StringBuilder selectSQL = new StringBuilder();
            selectSQL.append(" SELECT                                                                                             ");
            selectSQL.append("      seller_mem_no                                                                                 ");
            selectSQL.append("      ,sum(case stat when 'settle' then cnt else 0 end) as settle                                   ");
            selectSQL.append("      ,sum(case stat when 'confirm' then cnt else 0 end) as  confirm                                ");
            selectSQL.append("      ,sum(case stat when 'canceled' then cnt else 0 end) as  canceling                             ");
            selectSQL.append("      ,sum(case stat when 'returning' then cnt else 0 end) as  returning                            ");
            selectSQL.append("      ,sum(case stat when 'exchange' then cnt else 0 end) as  exchange                              ");
            selectSQL.append("      ,sum(case stat when 'redelivery' then cnt else 0 end)  as redelivery                          ");
            selectSQL.append("      ,sum(case stat when 'notifi' then cnt else 0 end) as notifi                                   ");
            selectSQL.append("      ,sum(case stat when 'question' then cnt else 0 end) as question                               ");
            selectSQL.append("  FROM (                                                                                            ");
            selectSQL.append("      SELECT seller_mem_no,                                                                         ");
            selectSQL.append("          case when ord_prd_stat = '202' then 'settle'                                              ");
            selectSQL.append("                  when ord_prd_stat = '301' then  'confirm'                                         ");
            selectSQL.append("                  when ord_prd_stat = '701' then 'canceled'                                         ");
            selectSQL.append("          end as stat                                                                               ");
            selectSQL.append("          ,count(1) as cnt                                                                          ");
            selectSQL.append("      FROM tr_ord_prd@scrt_link                                                                     ");
            selectSQL.append("      WHERE ord_dt > sysdate - 30                                                                   ");
            selectSQL.append("      AND ord_no > to_char(sysdate - 30 , 'yyyymmdd')||'0000000'                                    ");
        if(debugMode) selectSQL.append("      AND seller_mem_no = 10000026                                                        ");
            selectSQL.append("      AND ord_prd_stat in ('301', '202', '701')                                                     ");
            selectSQL.append("      group by seller_mem_no, ord_prd_stat                                                          ");
            selectSQL.append("      union all                                                                                     ");
            selectSQL.append("      SELECT b.seller_mem_no,                                                                       ");
            selectSQL.append("          case when  a.clm_stat = '105' then 'returning'                                            ");
            selectSQL.append("                  when  a.clm_stat = '201' then 'exchange'                                          ");
            selectSQL.append("                  when  a.clm_stat = '301' then 'redelivery'                                        ");
            selectSQL.append("          end as stat                                                                               ");
            selectSQL.append("          ,count(1) as cnt                                                                          ");
            selectSQL.append("      FROM tr_ord_clm_req_prd a, tr_ord_prd b                                   ");
            selectSQL.append("      WHERE a.req_dt > sysdate - 30                                                                 ");
            selectSQL.append("      AND a.clm_stat in ( '105' , '201', '301')                                                     ");
        if(debugMode) selectSQL.append("      AND seller_mem_no = 10000026                                                        ");
            selectSQL.append("      AND a.ord_no=b.ord_no                                                                         ");
            selectSQL.append("      AND a.ord_prd_seq=b.ord_prd_seq                                                               ");
            selectSQL.append("      group by b.seller_mem_no, a.clm_stat                                                          ");
            selectSQL.append("      union all                                                                                     ");
            selectSQL.append("      SELECT mem_no as seller_mem_no,'notifi' as stat, count(1) as cnt from CC_EMER_NTCE  ");
            selectSQL.append("      WHERE create_dt > sysdate - 30                                                                ");
            selectSQL.append("      AND EMER_NTCE_CRNT_CD IN ('01', '02','04')                                                    ");
        if(debugMode) selectSQL.append("      AND mem_no = 10000026                                                               ");
            selectSQL.append("      group by mem_no                                                                               ");
            selectSQL.append("      union all                                                                                     ");
            selectSQL.append("      SELECT /*+ use_nl(a b) */                                                                     ");
            selectSQL.append("           b.sel_mnbd_no                                                                            ");
            selectSQL.append("           ,'question' as stat                                                                      ");
            selectSQL.append("           ,sum(cnt) as cnt                                                                         ");
            selectSQL.append("      FROM (                                                                                        ");
            selectSQL.append("          SELECT /*+ use_hash(a b) parallel(a 2) full(a) */                                         ");
            selectSQL.append("              a.brd_info_clf_no,                                                                    ");
            selectSQL.append("              count(1) cnt                                                                          ");
            selectSQL.append("          FROM cm_unity_brd_info@scrt_link a ,(                                                     ");
            selectSQL.append("              SELECT /*+ parallel_index(aa FK8CM_UNITY_BRD_INFO 2) */                               ");
            selectSQL.append("                  aa.brd_info_no sub_info_no,                                                       ");
            selectSQL.append("                  hgrnk_brd_info_no                                                                 ");
            selectSQL.append("              FROM cm_unity_brd_info@scrt_link aa                                                   ");
            selectSQL.append("              WHERE unity_brd_no = '3'                                                              ");
            selectSQL.append("              AND brd_info_clf = '02'                                                               ");
            selectSQL.append("              AND del_yn = 'N'                                                                      ");
            selectSQL.append("              AND hgrnk_brd_info_no != '0' ) d                                                      ");
            selectSQL.append("          WHERE unity_brd_no = '3'                                                                  ");
            selectSQL.append("          AND brd_info_clf = '02'                                                                   ");
            selectSQL.append("          AND del_yn = 'N'                                                                          ");
            selectSQL.append("          AND a.hgrnk_brd_info_no = '0'                                                             ");
            selectSQL.append("          AND a.brd_info_no = d.hgrnk_brd_info_no(+)                                                ");
            selectSQL.append("          AND d.sub_info_no is null                                                                 ");
            selectSQL.append("          AND a.create_dt > sysdate - 30                                                            ");
            selectSQL.append("          group by a.brd_info_clf_no ) a, pd_prd@scrt_link b                                        ");
            selectSQL.append("      WHERE a.brd_info_clf_no = b.prd_no                                                            ");
        if(debugMode) selectSQL.append("      AND b.sel_mnbd_no = 10000026                                                        ");
            selectSQL.append("      group by b.sel_mnbd_no                                                                        ");
            selectSQL.append("      ) kkk                                                                                         ");
            selectSQL.append("  group by seller_mem_no                                                                            ");
            selectSQL.append("  order by seller_mem_no                                                                            ");

        return selectSQL;
    }

    private StringBuilder getInsertSQL() {

        final StringBuilder insertSQL = new StringBuilder();
            insertSQL.append(" INSERT INTO  SELLER_SELL_SUMMARY ");
            insertSQL.append("                    (SELLER_MEM_NO      ");
            insertSQL.append("                     ,SETTLE            ");
            insertSQL.append("                     ,CONFIRM           ");
            insertSQL.append("                     ,CANCELING         ");
            insertSQL.append("                     ,RETURNING         ");
            insertSQL.append("                     ,EXCHANGE          ");
            insertSQL.append("                     ,REDELIVERY        ");
            insertSQL.append("                     ,NOTIFI            ");
            insertSQL.append("                     ,QUESTION)         ");
            insertSQL.append("         VALUES( :SELLER_MEM_NO         ");
            insertSQL.append("                 ,:SETTLE               ");
            insertSQL.append("                 ,:CONFIRM              ");
            insertSQL.append("                 ,:CANCELING            ");
            insertSQL.append("                 ,:RETURNING            ");
            insertSQL.append("                 ,:EXCHANGE             ");
            insertSQL.append("                 ,:REDELIVERY           ");
            insertSQL.append("                 ,:NOTIFI               ");
            insertSQL.append("                 ,:QUESTION)            ");
        return insertSQL;

    }



    private StringBuilder getStartCheck() {
        final StringBuilder startCheckSQL = new StringBuilder();
        startCheckSQL.append(" SELECT count(*) as NOT_SENT ");
        startCheckSQL.append(" FROM SELLER_SELL_SUMMARY ");
        startCheckSQL.append(" WHERE seller_mem_no > 10000005 ");
        startCheckSQL.append(" AND send_yn = 'N' ");
        return startCheckSQL;
    }

    private StringBuilder getSummeryInsertAll(long summeryRow) {
        final StringBuilder summerInsertAll = new StringBuilder();

        summerInsertAll.append(" INSERT ALL                                                                                                                    ");

        for(int i = 0; i < summeryRow; i++) {
            summerInsertAll.append("    INTO SELLER_SELL_SUMMARY (SELLER_MEM_NO,SETTLE,CONFIRM,CANCELING,RETURNING,EXCHANGE,REDELIVERY,NOTIFI,QUESTION)  ");
            summerInsertAll.append("      VALUES(:SELLER_MEM_NO,:SETTLE,:CONFIRM,:CANCELING,:RETURNING,:EXCHANGE,:REDELIVERY,:NOTIFI,:QUESTION)                ");
        }

        summerInsertAll.append("SELECT 1 FROM dual                                                                                                             ");

        return summerInsertAll;
    }

    private void sendSellerMail() throws TmallException {
        try {

            mailRequest = new EmailRequestBO();
            mailRequest.setTemplateId(199);       //TID_199 templateId : �������ǽ� ��� ���� ���ø�
            mailRequest.setSubject(mailSubject);
            mailRequest.setResponseTerm(7);

         //   int i = 0;

           // mailUser = new EmailUserInfo[200];
            for (int i = 0; i < 10; i++) {
                mailUsers = new EmailUserInfo();

                mailUsers.setUserId("stageshrek");         // ������ ���� T-mall ȸ�� ���̵�
                mailUsers.setName("�ȿ"+1);              // ȸ�� �̸�
                mailUsers.setEmail("leave1@nate.com");     // ȸ�� ���� �ּ�

                mailUsers.setStaticData(                   // ���� ���ø��� ������ ���� �Ķ����
                             new String[] {
                                     "�ȿ" + i           // FIELD1 �̸�(��ȣ)
                                     , curDate             // FIELD2 �ֹ�����
                                     , "300"               // FIELD3 �ֹ���ȣ
                                     , "400"               // FIELD4 ��ǰ�հ�ݾ�
                                     , "500"               // FIELD5 ��ۺ�
                                     , "600"               // FIELD6 ���ֹ��ݾ�
                                     , "700"               // FIELD7 �������αݾ�
                                     , "800"               // FIELD8 ���������ݾ�
                                     , "900"               // FIELD9 ��������
                                     , "10000"             // FIELD10 �����ݾ� �� ����
                                  });

                mailRequest.addUserInfo(mailUsers);
                //log.info("GC before Memory : "+(Runtime.getRuntime().totalMemory()-Runtime.getRuntime().freeMemory())/megaBytes + "MB /" +Runtime.getRuntime().totalMemory()/megaBytes + "MB");
            }

            service = new EmailServiceImpl();

            service.sendEmail(mailRequest);


            System.out.println(curDate);
            //run();
        } catch(TmallException tmall) {

        } catch(Exception e ) {
            e.printStackTrace();
            log.error(e.toString());
        }
    }
}
