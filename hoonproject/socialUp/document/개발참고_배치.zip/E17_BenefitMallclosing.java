package skt.tmall.daemon.escrow;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.util.Date;

import skt.tmall.common.util.EDate;
import skt.tmall.daemon.common.util.DBHandler;

/**
 * MO �������� ��ġ
 * @author ZZ07237
 *
 */
public class E17_BenefitMallclosing extends EscrowBaseDaemon {

	/**
	 * @param args
	 */
	public static void main(String[] args) {
		E17_BenefitMallclosing dm = new E17_BenefitMallclosing();
		String yesterday = "";
		if (args != null && args.length > 0) {
			yesterday = args[0];
		}
		dm.run(yesterday);
	}

	public void run(String yesterday) {
		batch_no = 2517;
		batchID = "tmba_bo_17";
		batchName = "MO �������� ��ġ";

		/* ��ø ���� ����  */
		if (isRunning(batch_no)) {
			String errMsg = "�̹� �������Դϴ�";
			log.error(errMsg);
			batchLogPrint(batch_no, null, null, "-1", "User Define Error", "N/A", "Y", errMsg, errMsg);
			return;
		}

		run_sub(yesterday);
	}

	public void run_sub(String yesterday) {
		log.debug("===== "+batchName+" START =====");

		if (yesterday == null || yesterday.length() != 8) {
			Date dt = EDate.offset(new Date(), 0, 0, -1);
			yesterday = this.dateFormat(dt, "yyyyMMdd");
		}
		log.debug("�������� : "+yesterday);
		batchLogStart(batch_no,"MO��������/�������� : "+yesterday);

		Connection conn = null;
		PreparedStatement pstmt = null;
		ResultSet rs = null;

		StringBuffer buff = new StringBuffer();
		buff.append("	BEGIN 										\n");
		buff.append("   	SP_SE_BENEFIT_MALLCLOSING('DAY', ?);	\n");
		//buff.append("   	SP_SE_BENEFIT_MALLCLOSING('WEEK', ?);	\n");
		//buff.append("   	SP_SE_BENEFIT_MALLCLOSING('MONTH', ?);	\n");
		buff.append("	END;										\n");

		try {
			conn = DBHandler.getConnection(dbUrl,dbId,dbPwd);
			if (conn == null) {
				log.error("Connection is NULL !!!");
				throw new Exception("Connection is NULL !!!");
			}

			pstmt = conn.prepareStatement(buff.toString());
			pstmt.setString(1, yesterday);
			//pstmt.setString(2, yesterday);
			//pstmt.setString(3, yesterday);
			pstmt.execute();

			DBHandler.closeDBResource(rs,pstmt);
			DBHandler.closeDBResource(conn);

			batchLogEnd(batch_no, "0", "Success", "N/A", "N", "MO�������� ��������:"+yesterday, null);

		} catch (Exception e) {
			String err = "��������:"+yesterday;
			err += " Err:"+e.toString();
			batchLogEnd(batch_no, "-1", "ERROR", "N/A", "Y", "MO����������� ��������:"+yesterday, "MO����������� ��������:"+yesterday);
			log.error(err);
		} finally {
			try {
				DBHandler.closeDBResource(rs,pstmt);
				DBHandler.closeDBResource(conn);
			} catch (Exception e) {}

			log.debug("===== "+batchName+" END =====");
		}
	}
} // end of class
