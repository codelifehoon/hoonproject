package skt.tmall.daemon.escrow;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.util.Date;

import skt.tmall.common.util.EDate;
import skt.tmall.daemon.common.util.DBHandler;

/**
 * �����ϸ��� ��ġ
 * @author ZZ07237
 *
 */
public class E42_CybrMinusLimitProc extends EscrowBaseDaemon {

	/**
	 * @param args
	 */
	public static void main(String[] args) {
		E42_CybrMinusLimitProc dm = new E42_CybrMinusLimitProc();
		String yesterday = "";
		if (args != null && args.length > 0) {
			yesterday = args[0];
		}
		dm.run(yesterday);
	}

	public void run(String yesterday) {
		batch_no = 2542;
		batchID = "tmba_bo_42";
		batchName = "�Ǹ��� ȸ�� ��޺�  ���̳ʽ� ĳ�� �ѵ� �ο� ó��";

		/* ��ø ���� ����  */
		if (isRunning(batch_no)) {
			String errMsg = "�̹� �������Դϴ�:" + yesterday;
			log.error(errMsg);
			batchLogPrint(batch_no, null, null, "-1", "User Define Error", "N/A", "Y", errMsg, errMsg);
			return;
		}

		run_sub(yesterday);
	}

	public void run_sub(String today) {
		log.debug("===== "+batchName+" START =====");

		if (today == null || today.length() != 8) {
			Date dt = EDate.offset(new Date(), 0, 0, 0);
			today = this.dateFormat(dt, "yyyyMMdd");
		}
		String stlDy = "(��������:"+today+")";
		log.debug(stlDy);

		batchLogStart(batch_no,stlDy);

		Connection conn = null;
		PreparedStatement pstmt = null;
		ResultSet rs = null;

		StringBuffer buff = new StringBuffer();
		buff.append("	BEGIN 							    \n");
		buff.append("   	SP_SE_MINUS_CYBR_AMT_LIMIT(?);	\n");
		buff.append("	END;							    \n");


		try {
			conn = DBHandler.getConnection(dbUrl,dbId,dbPwd);
			if (conn == null) {
				log.error("Connection is NULL !!!");
				throw new Exception("Connection is NULL !!!");
			}

			pstmt = conn.prepareStatement(buff.toString());
			pstmt.setString(1, today);
			pstmt.execute();


			DBHandler.closeDBResource(rs,pstmt);
			DBHandler.closeDBResource(conn);

			batchLogEnd(batch_no, "0", "Success", "N/A", "N", "��������:"+today, null);
		} catch (Exception e) {
			String err = "��������:"+today;
			err += " Err:"+e.toString();
			batchLogEnd(batch_no, "-1", "Error", "N/A", "Y", err, "[�ϸ�������] ��������:"+today);
			log.error(err);
		} finally {
			try {
				DBHandler.closeDBResource(rs,pstmt);
				DBHandler.closeDBResource(conn);
			} catch (Exception e) {}

			log.debug("===== "+batchName+" END =====");
		}
	}
} // end of class
