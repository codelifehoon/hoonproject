package skt.tmall.daemon.escrow;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.util.List;

import com.ibatis.sqlmap.client.SqlMapClient;
import com.skt.omp.common.db.SqlMapLoader;

import skt.tmall.BOFactory;
import skt.tmall.ServiceFactory;
import skt.tmall.business.escrow.trade.domain.EscrowSearchBO;
import skt.tmall.business.remittance.settlement.domain.TrOrdStlRfndBO;
import skt.tmall.daemon.common.util.DBHandler;
import skt.tmall.process.share.escrow.sell.service.TradeService;
import skt.tmall.process.share.escrow.sell.service.TradeServiceImpl;

/**
 * ���ݰ�꼭 ���� ��ġ
 * @author ZZ07237
 *
 */

public class ggongMtPntSumTest extends EscrowBaseDaemon {
	/**
	 * @param args
	 */
	public static void main(String[] args) {
		String batchDate = "";
		if (args != null && args.length > 0) {
			batchDate = args[0];
		}

		EscrowBaseDaemon.initSqlMap();
		ggongMtPntSumTest dm = new ggongMtPntSumTest();
		dm.run(batchDate);
	}

	public void run(String batchDate) {

		run_sub(batchDate);
	}

	public void run_sub(String batchDate) {

		try
		{



			TradeService tradeService 	= (TradeService)ServiceFactory.createService(TradeServiceImpl.class);
			EscrowSearchBO esBO 		=		(EscrowSearchBO)BOFactory.createBO(EscrowSearchBO.class);

			esBO.setMemNo("10005311");
			List<TrOrdStlRfndBO> resultList  = tradeService.getMemRefundList(esBO);

			for(int i =0;i<resultList.size();i++)
			{
				log.debug("TrOrdStlRfndBO :" + skt.tmall.common.util.DebugUtil.DebugBo(resultList.get(i)));
			}



		} catch (Exception e)
		{
			e.printStackTrace();

		} finally
		{

		}
	}
} // end of class
