package skt.tmall.daemon.escrow;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;

import skt.tmall.daemon.common.util.DBHandler;

public class E73_SkDlvCupnEvnt extends EscrowBaseDaemon {
	/**
	 * @param args
	 */
	public static void main(String[] args) {
		E73_SkDlvCupnEvnt dm = new E73_SkDlvCupnEvnt();
		dm.run();
	}

	public void run() {
		batch_no = 2573;
		batchID = "tmba_bo_73";
		batchName = "SK��ۺ������̺�Ʈ";

		/* ��ø ���� ����  */
		if (isRunning(batch_no)) {
			String errMsg = "�̹� �������Դϴ�";
			log.error(errMsg);
			batchLogPrint(batch_no, null, null, "-1", "User Define Error", "N/A", "Y", errMsg, errMsg);
			return;
		}

		run_sub();
	}

	public void run_sub() {
		log.debug("===== "+batchName+" START =====");

		batchLogStart(batch_no, batchName);

		Connection conn = null;
		PreparedStatement pstmt = null;
		ResultSet rs = null;

		StringBuffer buff = new StringBuffer();
		buff.append("	BEGIN /* SK��ۺ������̺�Ʈ (/05.tMallETCProject/src/skt/tmall/daemon/escrow/E73_SkDlvCupnEvnt.java) */	\n");
		buff.append("   	SP_TR_SKTMEMBER_CUPN_EVENT;	        \n");
		buff.append("	END;							        \n");

		log.info("#######################");
		log.info("# SK��ۺ������̺�Ʈ ��ġ �۵� #");
		log.info("#######################");
		try {
			conn = DBHandler.getConnection(dbUrl,dbId,dbPwd);
			if (conn == null) {
				log.error("Connection is NULL !!!");
				throw new Exception("Connection is NULL !!!");
			}

			pstmt = conn.prepareStatement(buff.toString());
			pstmt.execute();

			DBHandler.closeDBResource(rs,pstmt);
			DBHandler.closeDBResource(conn);

			batchLogEnd(batch_no, "0", "Success", "N/A", "N", "SK��ۺ������̺�Ʈ ��ġ ����", null);

		} catch (Exception e) {
			batchLogEnd(batch_no, "-1", "ERROR", "N/A", "Y", "SK��ۺ������̺�Ʈ ��ġ ����", "SK��ۺ������̺�Ʈ ��ġ ����");
			log.error(e.toString());
		} finally {
			try {
				DBHandler.closeDBResource(rs,pstmt);
				DBHandler.closeDBResource(conn);
			} catch (Exception e) {}

			log.debug("===== "+batchName+" END =====");
		}
	}
}
