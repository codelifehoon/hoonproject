package skt.tmall.daemon.escrow;

import java.util.List;

import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;

import com.ibatis.sqlmap.client.SqlMapClient;
import com.skt.omp.common.db.SqlMapLoader;
import com.skt.omp.common.logger.Logger;
import com.skt.omp.common.util.DateTime;
import com.skt.omp.common.util.StringUtil;

import skt.tmall.BOFactory;
import skt.tmall.ServiceFactory;
import skt.tmall.bdt.transfer.ChannelType;
import skt.tmall.bdt.transfer.InterfaceData;
import skt.tmall.bdt.transfer.pas.PASCancelRequestBO;
import skt.tmall.bdt.transfer.pas.PASCancelResponseBO;
import skt.tmall.common.TmallException;
import skt.tmall.common.util.CmnUtil;
import skt.tmall.common.util.NumUtil;
import skt.tmall.interfacehub.InterfaceHubFactory;
import skt.tmall.interfacehub.client.core.InterfaceHub;
import skt.tmall.interfacehub.client.lookup.body.DeliveryImage;
import skt.tmall.interfacehub.client.lookup.body.DeliverySMILBody;
import skt.tmall.interfacehub.client.lookup.body.DeliveryXTBody;
import skt.tmall.interfacehub.client.lookup.parse.BaseMMSParse;
import skt.tmall.interfacehub.client.lookup.soap.SOAPHeader;
import skt.tmall.interfacehub.common.config.IFHubConfig;
import skt.tmall.process.share.escrow.payment.service.RefundWaitService;
import skt.tmall.process.share.escrow.payment.service.RefundWaitServiceImpl;
import skt.tmall.process.share.escrow.payment.service.SettlementManagerService;
import skt.tmall.process.share.escrow.payment.service.SettlementManagerServiceImpl;
import skt.tmall.daemon.common.ThreadPool;
import skt.tmall.daemon.common.IWorkerThread;
import skt.tmall.business.escrow.trade.domain.SettlementCancelAmountBO;
import skt.tmall.business.escrow.trade.domain.TrRefundWaitBO;
import skt.tmall.business.escrow.trade.domain.TrStlCnLogDtls;


public class E25_WorkerThreadRefundWait extends Thread implements IWorkerThread
{
//	�Ǹ��� �߼�ó��
//
//	UAPS ��ȸ  mgsstatus == '6'
//
//	If(NGB 2. 0 , MMS 4. 0 �̻� )
//	      MMS �߼� , MMS_LOG insert
//	Else
//	      SmsAPI ȣ�� , uaps_message ����
//
//
//	Delivery_req  Ű : messageid �� ������ ���
//
//	������ MMS_log update
//
//	If(Status_code != 1000) {
//	      SmsAPI ȣ�� ,
//	 }
//
//	������ uaps_message ����



	public static Log log = LogFactory.getLog(E25_WorkerThreadRefundWait.class);

	private ThreadPool pool;
	private TrRefundWaitBO trRefundWaitBO = null;


	/*
    public E25_WorkerThreadRefundWait(ThreadPool pool)
    {
		this.pool = pool;
	}
*/
    public void setPool(ThreadPool pool)
    {
    	this.pool = pool;
    }

    public synchronized void run()
    {
	    while (true)
loop:   {
			try
			{
				this.wait();
			}
			catch (InterruptedException e)
			{
				// ���ͷ�Ʈ�� �߻��ϸ� �ش� �۾�����
				this.interrupted();
				log.debug(Thread.currentThread().getName() + "this.interrupted()");
				return;
			}

			if (this.trRefundWaitBO == null)
			{
				log.info("trRefundWaitBO is null - pool.putThread");
				pool.putThread(this);
				break loop;
			}

			try
			{
				RefundWaitService 	refundWaitService =  (RefundWaitService)ServiceFactory.createService(RefundWaitServiceImpl.class);

				// ȯ��ó�� ����
				refundWaitService.processRefund(this.trRefundWaitBO);
			}
			catch (Exception e)
			{
				log.debug("���� ȯ�ҽ���");
				e.printStackTrace();
			}
			finally
			{
				/*sqlMap.endTransaction();*/
				this.trRefundWaitBO = null;
				pool.putThread(this);
			}
	    }
	}

	public synchronized void workHard(TrRefundWaitBO trRefundWaitBO)
	{
		log.debug("workHard - work");
		this.trRefundWaitBO = trRefundWaitBO;
		this.notify();
	}




}
