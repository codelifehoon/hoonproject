package skt.tmall.daemon.escrow;

import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.sql.Timestamp;
import java.util.Properties;
import java.util.StringTokenizer;
import java.sql.PreparedStatement;

import skt.tmall.common.security.TmallSecureManager;

import skt.tmall.daemon.common.util.DBHandler;
import skt.tmall.daemon.pas.*;

/*
import tgcorp.pg.PGCode;
import tgcorp.tfc.db.DBUtil;
import tgcorp.tfc.util.Format;

import com.tgcorp.pg.batch.ConnectionManager;
import com.tgcorp.pg.batch.taxskt.TAXConf;
import com.tgcorp.pg.batch.taxskt.getDATA1;
import com.tgcorp.pg.batch.taxskt.saveTAXFile;
*/

public class P02_MakeTAXFile extends EscrowBaseDaemon {


    public static void main( String[] args ) {

        StdOut.setDebug( false );

	    if ( args.length != 4 ) {
	    	usage();
	    } else {
	        StdOut.log("main", "*** Begin - Service *** ");

	        EscrowBaseDaemon.initSqlMap();
	        P02_MakeTAXFile dm = new P02_MakeTAXFile();

	        dm.run( args[0], args[1], args[2], args[3] );

	        StdOut.log("main", "*** End   - Service *** ");
	    }
    }

    private static void usage() {
        StdOut.error("main", "Usage: java skt.tmall.daemon.escrow.P02_MakeTAXFile <capture date> <interface name> <opcode> <bizno code>");

        System.exit(-1);
	}

	public void run( String cDate, String iName, String oCode, String bCode ) {
		batch_no = 2702;
    	batchID = "tmba_2702";
    	batchName = "���ݿ����� ���ϻ��� 2�ܰ� (2/2)";

		/* ��ø ���� ����  */
		if (isRunning(batch_no)) {
			String errMsg = "�̹� �������Դϴ�";
			log.error(errMsg);
			batchLogPrint(batch_no, null, null, "-1", "User Define Error", "N/A", "Y", errMsg, errMsg);
			return;
		}

		run_sub( cDate, iName, oCode, bCode );
	}


    public void run_sub( String capdate, String interfacename, String opcode, String biznocode )
	{
    	batchLogStart(batch_no,"��ġ ���� : ���ݿ����� ���ϻ�����ġ");


		String captype    = null;

		int cap_seq       = 1;
		byte[] temp       = null;
		int logfiletype   = 1;

	    StdOut.log("makeFile", "CAPTURE DAY=" + capdate + ", INTERFACE NAME=" + interfacename + ", OPCODE=" + opcode + ", BIZNO CODE=" + biznocode);


		Timestamp to_date = new Timestamp(System.currentTimeMillis());
		Timestamp yes_date = new Timestamp(to_date.getTime() - 24*60*60*1000);
		Timestamp tomorrow_date = new Timestamp(to_date.getTime() + 24*60*60*1000);

		String to_tmp  = to_date.toString();
		// ���� �Ͻ� : ex : 2010-06-10 18:13:29.81

		String yes_ext = yes_date.toString().substring(0, 4) + yes_date.toString().substring(5,7)+yes_date.toString().substring(8,10);
		// ���� ��¥ : ex : 20100609
		String req_date = to_date.toString().substring(0, 4) + to_date.toString().substring(5,7)+to_date.toString().substring(8,10);
		// ���� ��¥ : ex : 20100610
		String tomo_date = tomorrow_date.toString().substring(0, 4) + tomorrow_date.toString().substring(5,7)+tomorrow_date.toString().substring(8,10);
		// ���� ��¥ : ex : 20100611

		if ( ! capdate.equals(yes_ext) ) {
			capdate = yes_ext;
		}

		StdOut.debug("makeFile", "time="+to_tmp.substring(11,13) );

	//	String to_ext = to_date.toString().substring(2, 4) + to_date.toString().substring(5,7)+to_date.toString().substring(8,10);

		String to_ext = capdate.substring( 2 );
		// ���� ��¥�� �� ���ڸ� 2�� ���� : ex : 100609

		StdOut.log("makeFile", "to_ext=" + to_ext);

		// //////////////////////////////////////////////////////////
		// TODO :: DEBUG �Ҷ� ���
		if( false ) {  // if release
	//	if( true ) {  // if debug
    		StdOut.log("makeFile", "\n\n�������ڰ� ������ ���Ͽ� ���� �����Ǿ� �ֽ��ϴ�. �ݵ�� Ȯ���Ͻñ� �ٶ��ϴ�.\n\n" );
    //		to_ext = "091210";
		}
		// //////////////////////////////////////////////////////////

		//
		int idx = 0;

		//String up_edifile = "SKT_TAX_S_KSNET"+"."+to_ext;
		//String dn_edifile = "SKT_TAX_R_KSNET"+"."+yes_ext;


		// SKT�� ������ ���ϸ� ���� : ������ ������ SYSDATE�� ��û
		String up_edifile = "ZPAYBOTS10020-001-" + req_date + "_02.dat";


		// SKT���� ������ ���ϸ� ����
		String dn_edifile = "ERO.NTSG." + tomo_date + "_02";


		StdOut.log("makeFile", "<Info><makeEDIFile> Upload   filename[0] =" + up_edifile );
		StdOut.log("makeFile", "<Info><makeEDIFile> Download filename[0] =" + dn_edifile );


		String[] txno_ar = null;
		String[] mxid_ar = null;
		String[] mxissueno_ar = null;
		String[] mxissuedate_ar = null;
		String[] termid_ar = null;
		String[] reqdate_ar = null;
		String[] fitype_ar = null;
		String[] bizno_ar = null;
		String[] currency_ar = null;
		String[] biztype_ar = null;
		String[] idno_ar = null;
		String[] amount_ar = null;
		String[] tax_ar = null;
		String[] svcfee_ar = null;
		String[] tamount_ar = null;
		String[] senddate_ar = null;
		String[] txcode_ar = null;
		String[] txstatus_ar = null;

		String[] oissueno_ar = null;
		String[] oissuedate_ar = null;

		String[] seller_bizno_ar = null;	// ���� ����ڹ�ȣ
		String[] issueno_ar = null;	// 11�������� ������ ���ι�ȣ
		String[] issuedate_ar = null;

		String[] pgname_ar = null;		// ���ݿ����� ����� ����(KSNET/SKT, null �̸� KSNET)

		String qs1 =
			 "SELECT txno, mxid, mxissueno, mxissuedate, termid, reqdate, fitype, bizno, currency, biztype, " +		// 1 ~ 10
		           " idno, amount, tax, svcfee, tamount, senddate, txcode, txstatus, oissuedate, oissueno, " +		// 11 ~ 20
		           " decodeparam(seller_bizno), issueno, pgname, issuedate " +		// 21 ~ 24
		      " FROM ";

		String qs_t =
		     "SELECT COUNT(*) " +
		      " FROM ";

		String qs2 =
			       " taxtr " +
			  "WHERE sendfile ='"+up_edifile+"' " +
			  " ORDER BY issueno ASC ";

		StdOut.debug("makeFile", "============ SQL =======================================");
		StdOut.debug("makeFile", qs1 + qs2 );
		StdOut.debug("makeFile", "========================================================");

		String sql_req =
			"SELECT DISTINCT TO_CHAR(TO_DATE(senddate, 'yyyymmdd')+1 , 'yyyymmdd') " +
			  "FROM taxtr " +
			 "WHERE txstatus = '"+PGCode.ST_TAX_REQING+"' " +
			  " AND senddate <=TO_CHAR(sysdate - 1, 'YYYYMMDD') "+
			 "ORDER BY TO_CHAR(TO_DATE(senddate, 'yyyymmdd')+1 , 'yyyymmdd') ASC";

		String dn_script = "";
		String ex_script = "";

		String dn_script_1 = "./file_get " + dq(interfacename) + " \"/ngmshr/data/batch/pay/sam\" " + dq(dn_edifile) + dq("/weblogic/pas/taxsave/EDI_FILE") + dq(dn_edifile) + " " + dq(opcode) + " \nsleep 5 \n";
		String ex_script_1 = "java -classpath $1 skt.tmall.daemon.escrow.P03_RecvTAXFile /weblogic/batch/bin/pas/taxsave/EDI_FILE/"+ dn_edifile +"\nsleep 5\n";



		//String dn_script_1 = "./edi_ftp D "+ vansite_no +" EDI_FILE/"+ dn_edifile+" "+ tomo_date +  " 5 \nsleep 5\n";
		//String ex_script_1 = "java -classpath $1 com.tgcorp.pg.batch.taxskt.ReceiveExe /home/insppg/pgdev/batch/edi/taxsave/skt/EDI_FILE/"+ dn_edifile +"\nsleep 5\n";


		// //////////////////////////////////////////////////////////
		// 1. EDI ������ �����ؾ� �� ��ü ��� �Ǽ��� Array�� �ʱ�ȭ �Ѵ�.
		// 2. EDI ������ �۽��ϱ� ���� ���� �Ǿ�� �� Shell Script �� ���� �Ѵ�.
		// JDBC connection
		Connection con = null;
        PreparedStatement pstmt = null;
		ResultSet rs = null;

		int mrownum = 0;

		try {

			con = DBHandler.getConnection(dbUrl,dbId,dbPwd);

            if (con == null) {
                log.error("Connection is NULL !!!");
                throw new Exception("Connection is NULL !!!");
            }

            pstmt    = con.prepareStatement( qs_t + qs2 );
            rs = pstmt.executeQuery();


			// EDI ������ �����ؾ� �� ��ü ��� �Ǽ��� Array �ֱ�ȭ �Ѵ�.
			if (rs.next()) {
				mrownum = rs.getInt(1 );
				StdOut.log("makeFile", "Init. Array [" + mrownum +"]" );

				txno_ar 	   = new String[mrownum];
				mxid_ar 	   = new String[mrownum];
				mxissueno_ar   = new String[mrownum];
				mxissuedate_ar = new String[mrownum];
				termid_ar 	   = new String[mrownum];
				reqdate_ar 	   = new String[mrownum];
				fitype_ar 	   = new String[mrownum];
				bizno_ar 	   = new String[mrownum];
				currency_ar    = new String[mrownum];
				biztype_ar     = new String[mrownum];
				idno_ar 	   = new String[mrownum];
				amount_ar 	   = new String[mrownum];
				tax_ar 		   = new String[mrownum];
				svcfee_ar 	   = new String[mrownum];
				tamount_ar 	   = new String[mrownum];
				senddate_ar    = new String[mrownum];
				txcode_ar 	   = new String[mrownum];
				txstatus_ar    = new String[mrownum];
				oissuedate_ar   = new String[mrownum];
				oissueno_ar 	   = new String[mrownum];
				seller_bizno_ar 	   = new String[mrownum];
				issueno_ar 	   = new String[mrownum];
				pgname_ar 	   = new String[mrownum];
				issuedate_ar 	   = new String[mrownum];

			}

			DBHandler.closeDBResource(rs);
			DBHandler.closeDBResource(pstmt);


			// ���� �������� ��û���� �������� VAN���� ��� �����͸� �����Ƿ�
			// ����������, �����, �Ͽ��Ͽ� ������ �־� D-1 ���� ���� ��û���ڸ� ���Ѵ�.
            pstmt    = con.prepareStatement( sql_req );
            rs = pstmt.executeQuery();

			while(rs.next()) {
				//dn_edifile = "SKT_TAX_R_KSNET"+"."+ rs.getString(1).substring( 2 );
				dn_edifile = "ERO.NTSG." + rs.getString(1) + "_02";
				StdOut.log("makeFile", "DownLoad EDI filename["+(idx++)+"] = " +dn_edifile );

				dn_script += "./file_get " + dq(interfacename) + dq("/ngmshr/data/batch/pay/sam") + dq(dn_edifile) + dq("/weblogic/pas/taxsave/EDI_FILE") + dq(dn_edifile) + dq(opcode);
				ex_script += "java -classpath $1 skt.tmall.daemon.escrow.P03_RecvTAXFile /weblogic/batch/bin/pas/taxsave/EDI_FILE/"+ dn_edifile +"\nsleep 5\n";

				//dn_script += "./edi_ftp D "+ vansite_no +" EDI_FILE/"+ dn_edifile+" "+ rs.getString(1) +  " 5 \nsleep 5\n";
				//ex_script += "java -classpath $1 com.tgcorp.pg.batch.taxskt.ReceiveExe /home/insppg/pgdev/batch/edi/taxsave/skt/EDI_FILE/"+ dn_edifile +"\nsleep 5\n";
			}

			if ( mrownum < 1 ){
				StdOut.error("makeFile", "EDI Data not found");

				throw new Exception ("EDI Data not found");
			}

		} catch( Exception e) {
		    StdOut.error("makeFile", "Exception : " +e.getMessage() );
		} finally {

            DBHandler.closeDBResource( rs, pstmt );
            DBHandler.closeDBResource( con );


			if( dn_script == null || dn_script.equals("") || ex_script == null || ex_script.equals("") ) {
				dn_script = dn_script + dn_script_1;
				ex_script = ex_script + ex_script_1;
			}

			//
			// EDI ������ �۽��ϱ� ���� ���� �Ǿ�� �� Shell Script �� ���� �Ѵ�.
			StdOut.log("makeFile", "Script File Create !"  );




			//saveTAXFile.saveFile("./edi_ftp U "+ vansite_no +" EDI_FILE/"+ up_edifile +" "+ cap_seq+ " 5 ", 3, "send_cap" );

			saveTAXFile.saveFile("./file_put " + dq("TMALL.COMM_PAY_FBT") + dq("/home/eaiadmin/pas/EDI_FILE") + dq(up_edifile) + dq("/ngmshr/data/batch/pay/sam") + dq(up_edifile) + dq(opcode), 3, "send_cap" );

			saveTAXFile.saveFile(dn_script, 4, "recv_cap");

			saveTAXFile.saveFile(ex_script, 5, "recv_exe" );

			StdOut.log("makeFile", "File Create Success !"  );


		}




        // //////////////////////////////////////////////////////////
        // 3. EDI ������ �����ؾ� �� ��ü ��� �Ǽ��� 1. ���� �ʱ�ȭ �� Array �� ��´�.
		int index2 = 0;
		try {
			con = DBHandler.getConnection(dbUrl,dbId,dbPwd);
            if (con == null) {
                log.error("Connection is NULL !!!");
                throw new Exception("Connection is NULL !!!");
            }
			StdOut.log("makeFile", "Success ConnectionPool (Detail) !!! ");

            pstmt    = con.prepareStatement( qs1 + qs2 );
            rs = pstmt.executeQuery();

			StdOut.log("makeFile", "Before Set Value.[" + mrownum +"]" );

			int financial_cnt = 0;
			int cancel_cnt = 0;

			while(rs.next()) {

				try {
					txno_ar[index2] 	= getValue(rs.getString(1));
					mxid_ar[index2] 	= getValue(rs.getString(2));
					mxissueno_ar[index2] = getValue(rs.getString(3));
					mxissuedate_ar[index2] = getValue(rs.getString(4));
					termid_ar[index2] 	= getValue(rs.getString(5));
					reqdate_ar[index2] 	= getValue(rs.getString(6));
					fitype_ar [index2]	= getValue(rs.getString(7));

					if ( fitype_ar[index2].equals("11") )
					{
						financial_cnt++;
					} else {
						cancel_cnt++;
					}

					bizno_ar [index2]	= getValue(rs.getString(8));
					currency_ar[index2] = getValue(rs.getString(9));
					biztype_ar [index2] = getValue(rs.getString(10));

					idno_ar[index2]     = TmallSecureManager.decodeParam(rs.getString(11) );

					amount_ar [index2]	= getValue(rs.getString(12));
					tax_ar [index2]		= getValue(rs.getString(13));
					svcfee_ar[index2]	= getValue(rs.getString(14));
					tamount_ar [index2]	= getValue(rs.getString(15));
					senddate_ar [index2]= getValue(rs.getString(16));
					txcode_ar [index2]	= getValue(rs.getString(17));
					txstatus_ar [index2]= getValue(rs.getString(18));

					// ��ҽ� ���
					oissuedate_ar[index2] = rs.getString(19);
					oissueno_ar[index2] 	= rs.getString(20);

					// ���� ����ڹ�ȣ
					seller_bizno_ar[index2] 	= rs.getString(21);

					// 11���� ���� ���ι�ȣ
					issueno_ar[index2] 	= rs.getString(22);

					// ���ݿ����� ����� ����(KSNET/SKT, null �̸� KSNET)
					pgname_ar[index2] 	= rs.getString(23);

					// 11���� ���� �����Ͻ�
					issuedate_ar[index2] 	= rs.getString(24);

				} catch(Exception e) {
				    StdOut.error("makeFile", "index : " + index2
										   + ", txno : " + txno_ar[index2]
		                                   + ", mxissueno : " + mxissueno_ar[index2]);

					txno_ar[index2] 	= null;
					mxid_ar[index2] 	= null;
					mxissueno_ar[index2] = null;
					mxissuedate_ar[index2] = null;
					termid_ar[index2] 	= null;
					reqdate_ar[index2] 	= null;
					fitype_ar [index2]	= null;
					bizno_ar [index2]	= null;
					currency_ar[index2] = null;
					biztype_ar [index2] = null;

					idno_ar[index2]     = null;

					amount_ar [index2]	= null;
					tax_ar [index2]		= null;
					svcfee_ar[index2]	= null;
					tamount_ar [index2]	= null;
					senddate_ar [index2]= null;
					txcode_ar [index2]	= null;
					txstatus_ar [index2] = null;

					// ��ҽ� ���
					oissuedate_ar[index2] = null;
					oissueno_ar[index2] 	= null;

					seller_bizno_ar[index2] 	= null;

					issueno_ar[index2] 	= null;
					pgname_ar[index2] 	= null;
					issuedate_ar[index2] 	= null;

					continue;
				}

				index2++;

			}    // End while()





            // SMS �� �ޱ����� ���� ���θ� Y �� ��
            batchLogEnd(batch_no, "0", "Success", "N/A", "Y", "��ġ�Ϸ�", "[���ݿ��������ϻ���]�߱�" + financial_cnt + "��/���:" + cancel_cnt + "��" );




			DBHandler.closeDBResource(rs);
		} catch(SQLException e) {
			 StdOut.error("makeFile", "" + e.getMessage() );
			 e.printStackTrace();
			//throw new SQLException(e.getMessage());
		} catch(Exception e) {
		    StdOut.error("makeFile", "Exception : " + e.getMessage());
			//throw new SQLException(e.getMessage());
		} finally {
			DBHandler.closeDBResource( pstmt );
			DBHandler.closeDBResource( con );
		}

		int totalcnt = 0;
		int currentcnt = 0;

		Properties param = new Properties();

		param.setProperty( "BNCode", biznocode );

		long capcnt = 0;
		long cancnt = 0;

		index2 = index2 + 2;

		for ( int j = -1; j < index2 - 1; j++ ) {

			if ( j > -1 && j < index2 - 2 ) {
				//���α��� ����[����/���]
				if( txstatus_ar[j].equals(PGCode.ST_TAX_REQ) || txstatus_ar[j].equals(PGCode.ST_TAX_REQING) ) {
					captype = "CA";		// ��û
					StdOut.log("makeFile", "["+captype+"] issueno=" + issueno_ar[j] + ", issuedate=" + oissuedate_ar[j]+ ", txstatus=" + txstatus_ar[j]);

					capcnt++;
				} else if( txstatus_ar[j].equals(PGCode.ST_TAX_REV) || txstatus_ar[j].equals(PGCode.ST_TAX_REVING) ) {
				    captype = "CC";      // ���
				    StdOut.log("makeFile", "["+captype+"] issueno=" + oissueno_ar[j] + ", issuedate=" + oissuedate_ar[j]+ ", txstatus=" + txstatus_ar[j]);

					cancnt++;

					if( oissueno_ar[j] == null || oissuedate_ar[j] == null
							|| oissueno_ar[j].equals("" ) || oissuedate_ar[j].equals("" ) ) {
						param.setProperty("IssueNo", "      ");
						param.setProperty("IssueDate", "          ");
					} else {
						param.setProperty("IssueNo", oissueno_ar[j]);
						param.setProperty("IssueDate", oissuedate_ar[j]);
					}
				} else {
					captype =  null;
					StdOut.error("makeFile", "[null] issueno=" + oissueno_ar[j] + ", issuedate=" + oissuedate_ar[j]+ ", txstatus=" + txstatus_ar[j]);
					StdOut.error("makeFile", "TxStatus Fail! issueno=" + oissueno_ar[j] + ", issuedate=" + oissuedate_ar[j]+ ", txstatus=" + txstatus_ar[j]);

					continue;
				}

				StdOut.debug("makeFile", "captype=" + captype +", capture cnt="+ capcnt +", cancel cnt="+ cancnt );

				param.setProperty("TxNO", txno_ar[j]);
				param.setProperty("MxID", mxid_ar[j]);
				param.setProperty("MxIssueNO", mxissueno_ar[j]);
				param.setProperty("MxIssueDate", mxissuedate_ar[j]);
				param.setProperty("VanSiteNO", termid_ar[j]);
				param.setProperty("ReqDate", reqdate_ar[j]);
				param.setProperty("FiType", fitype_ar[j]);

				// Biz. NO --->

				param.setProperty("Currency", currency_ar[j]);
				param.setProperty("BizType", biztype_ar[j]);

				param.setProperty("IDNO", idno_ar[j]);
				param.setProperty("Amount", amount_ar[j]);
				param.setProperty("Tax", tax_ar[j]);
				param.setProperty("SVCFee", svcfee_ar[j]);
				param.setProperty("TAmount", tamount_ar[j]);
				param.setProperty("SendDate", senddate_ar[j]);
				param.setProperty("TxCode", txcode_ar[j]);
				param.setProperty("TxStatus", txstatus_ar[j]);

				// ���� ����ڹ�ȣ
				if ( seller_bizno_ar[j].equals("") || seller_bizno_ar[j] == null || seller_bizno_ar[j].length() >= 11 ) {
					param.setProperty("SBizNO",    "1048137225");
				} else {
					param.setProperty("SBizNO", seller_bizno_ar[j]);
				}

				param.setProperty("IssueNO", issueno_ar[j]);
				param.setProperty("PGName", pgname_ar[j]);

				if ( issuedate_ar[j] == null || issuedate_ar[j].equals("") ) {
					param.setProperty("IssueDATE", senddate_ar[j]);
				} else {
					param.setProperty("IssueDATE", issuedate_ar[j]);
				}

				// Biz. NO
				String biz_temp = bizno_ar[j];
				if( biz_temp != null ) {
				    StdOut.debug( "makeFile", "BizNO=" + biz_temp);
		            String Out="";
		            StringTokenizer st = new StringTokenizer(biz_temp, "-");
		            while (st.hasMoreTokens()) {
		                String token = st.nextToken();
		                Out += token;
		            }
		            StdOut.debug( "makeFile", "remove '-', BizNO=" + Out );
				    param.setProperty("BizNO", Out);
				}
			}
			else {
				captype = "";
			}

			if ( j == -1 || j == index2 - 2) {
				param.setProperty("BizNO", bizno_ar[0]);
			}

			totalcnt = index2 - 2;
			param.setProperty("totalcnt",   Integer.toString(totalcnt) );
			param.setProperty("currentcnt", Integer.toString(currentcnt));
			currentcnt++;

			StdOut.debug("makeFile", "Param : " + param.toString() );


			if(captype != null) {
				try {
					temp = getDATA1.getCapReq(param, TAXConf.vfcode4, captype);

					StdOut.debug("makeFile", "getDATA1.getCapReq");
				} catch(Exception e) {
					StdOut.error("makeFile", "error in getDATA1.getCapReq() : "+e.getMessage() );
				}

				try {
					saveTAXFile.saveFile( Format.decodeLJFS(temp,0,600), logfiletype, up_edifile);
					StdOut.debug("makeFile", "saveEDIFile.saveFile");
			   	} catch(Exception e) {
					StdOut.error("makeFile", "error in saveEDIFile.saveFile call! ... "+e.getMessage());
			   	}
			} else {
			    StdOut.error("makeFile", "Invalid captype (is null)! ");
			}
		} //for loop end!!


		if ( index2 - 2 == 0 ) {
			totalcnt = index2 - 2;
			param.setProperty("currentcnt", "1");
			param.setProperty("totalcnt", "0");

			captype = "CA";

			try {

				temp = getDATA1.getCapReq(param, TAXConf.vfcode4, captype);

			} catch(Exception e) {
				StdOut.error("makeFile", "error in getDATA1.getCapReq() : "+e.getMessage());
			}
			try {

				saveTAXFile.saveFile( Format.decodeLJFS(temp,0,600), logfiletype, up_edifile);

			} catch(Exception e) {
					StdOut.error("makeFile","error in saveEDIFile.saveFile call! ... "+e.getMessage());
		   	}
		}

		StdOut.log("makeFile", "File Create Success !"  );

	} // function:makeFile end!!



	/**
	 *
	 * Get Value
	 * <P/>
	 * ���� �޼ҵ� ����.
	 *
	 * @param input
	 * @return
	 * @throws Exception
	 */
	public static String getValue(String input) throws Exception {
		if( input == null )
		    throw new Exception("getValue()::NullPointerException");

		return input;
	}

	// double quotation ����
	public static String dq(String input) {

			input = " \"" + input + "\" ";

		return input;
	}



}
