package skt.tmall.daemon.escrow;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;

import skt.tmall.business.bulkSmsSender.domain.BulkSmsSenderMessageProperites;
import skt.tmall.daemon.common.util.DBHandler;

public class E53_WAPSMSResult extends EscrowBaseDaemon{
	public static void main(String[] args) {

		E53_WAPSMSResult dm = new E53_WAPSMSResult();
		dm.run();
	}

	public void run() {
		batch_no = 2552;
		batchID = "wapsms_E53";
		batchName = "WAP SMS �߼۰��";

		/* ��ø ���� ����  */
		if (isRunning(batch_no)) {
			String errMsg = "�̹� �������Դϴ�";
			log.error(errMsg);
			batchLogPrint(batch_no, null, null, "-1", "User Define Error", "N/A", "Y", errMsg, errMsg);
			return;
		}


		process();
	}

	public void process() {
		batchLogStart(batch_no,"WAP SMS �߼� ��� ������Ʈ ��ġ ");

		log.debug("===== "+batchName+" START =====");

		Connection conn = null;
		PreparedStatement pstmt = null;
		ResultSet rs = null;

		StringBuffer buff = new StringBuffer();
		buff.append("	BEGIN 									\n");
		buff.append("   	SP_WAP_SMS_RESULT;					\n");
		buff.append("	END;									\n");

		try {

			conn = DBHandler.getConnection(dbUrl,dbId,dbPwd);
			if (conn == null) {
				log.error("Connection is NULL !!!");
				throw new Exception("Connection is NULL !!!");
			}

			pstmt = conn.prepareStatement(buff.toString());
			pstmt.execute();

			DBHandler.closeDBResource(rs,pstmt);
			DBHandler.closeDBResource(conn);

			batchLogEnd(batch_no, "0", "Success", "N/A", "N", "WAP SMS �߼۰�� ������Ʈ ����", null);

		} catch (Exception e) {
			batchLogEnd(batch_no, "-1", "ERROR", "N/A", "Y", "WAP SMS �߼۰�� ������Ʈ ����", "WAP SMS �߼۰�� ������Ʈ ����");
			log.error(e.toString());
		} finally {
			try {
				DBHandler.closeDBResource(rs,pstmt);
				DBHandler.closeDBResource(conn);
			} catch (Exception e) {}

			log.debug("===== "+batchName+" END =====");
		}

	}
}
