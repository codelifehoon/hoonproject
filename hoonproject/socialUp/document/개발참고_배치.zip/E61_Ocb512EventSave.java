package skt.tmall.daemon.escrow;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

import skt.tmall.BOFactory;
import skt.tmall.ServiceFactory;
import skt.tmall.business.event.domain.EventOcb512BO;
import skt.tmall.daemon.common.util.DBHandler;
import skt.tmall.process.share.escrow.buymng.service.BuyManagementService;
import skt.tmall.process.share.escrow.buymng.service.BuyManagementServiceImpl;

/**
 * 512 OCB �̺�Ʈ 5�� ����
 *
 */
public class E61_Ocb512EventSave extends EscrowBaseDaemon {
    /**
     * @param args
     */
    public static void main(String[] args) {
        EscrowBaseDaemon.initSqlMap();
        E61_Ocb512EventSave dm = new E61_Ocb512EventSave();
        dm.run();
    }


	public void run() {
		batch_no = 2561;
    	batchID = "tmba_bo_61";
    	batchName = "512 OCB �̺�Ʈ 5�� ����";

		/* ��ø ���� ����  */
		if (isRunning(batch_no)) {
			String errMsg = "�̹� �������Դϴ�";
			log.error(errMsg);
			batchLogPrint(batch_no, null, null, "-1", "User Define Error", "N/A", "Y", errMsg, errMsg);
			return;
		}

		run_sub();
	}

	@SuppressWarnings("unchecked")
	public void run_sub() {
    	log.debug("===== "+batchName+" START =====");

		batchLogStart(batch_no,"512 OCB �̺�Ʈ 5�� ����");

        Connection conn = null;
        PreparedStatement pstmt = null;
        ResultSet rs = null;

        long sTime = 0;
        long eTime = 0;

        StringBuffer buff = new StringBuffer();
        buff.append("	select a.ORD_NO 																			  ");
        buff.append("	     , a.ORD_PRD_SEQ                                                                          ");
        buff.append("	     , a.ORD_DT                                                                               ");
        buff.append("	     , a.MEM_NO                                                                               ");
        buff.append("	     , a.EXT_PNT                                                                              ");
        buff.append("	     , nvl(ord.ocb_card_num, m.ocb_card_num) as ocb_card_num 				                  ");
        buff.append("	     , nvl(ord.ocb_rsdnt_no,'') ocb_rsdnt_no	                                              ");
        buff.append("	     , FN_TR_GET_CARD_AMT(a.ORD_NO) AS card_amt 				                              ");
        buff.append("	from MT_EVNT_100512_OCB a                                                                     ");
        buff.append("	   , tr_ord_prd b                                                                  			  ");
        buff.append("	   , tr_ord ord                                                                    			  ");
        buff.append("	   , mb_mem m                                                                      			  ");
        buff.append("	where a.ord_no = b.ord_no                                                                     ");
        buff.append("	  and a.ord_prd_seq = b.ord_prd_seq                                                           ");
        buff.append("	  and b.ord_prd_stat = '901'                                                                  ");
        buff.append("	  and a.ext_pnt_yn = 'N'                                                                      ");
        buff.append("	  and ord.buy_mem_no = m.mem_no                                                               ");
        buff.append("	  and b.ord_no = ord.ord_no                                                                   ");
        buff.append("	  AND b.ord_qty - b.ord_cn_qty - ord_cn_req_qty > 0                                           ");
        buff.append("	  and (nvl(ord.ocb_card_num, m.ocb_card_num) is not null or ord.ocb_rsdnt_no is not null)     ");

        List arOrdNo 		= new ArrayList();
        List arOrdPrdSeq	= new ArrayList();
        List arMemNo		= new ArrayList();
        List arOrdDt		= new ArrayList();
        List arExpSavePnt	= new ArrayList();
        List arOcbCardNum	= new ArrayList();
        List arOcbRsdntNo	= new ArrayList();
        List arCardAmt		= new ArrayList();

        int cnt = 0;

        try {

            conn = DBHandler.getConnection(dbUrl,dbId,dbPwd);
            if (conn == null) {
                log.error("Connection is NULL !!!");
                throw new Exception("Connection is NULL !!!");
            }

            log.info(buff.toString());
            pstmt = conn.prepareStatement(buff.toString());
            sTime = System.currentTimeMillis();
            log.error("512 OCB �̺�Ʈ 5�� ���� ���ǰ������� ����");
            rs = pstmt.executeQuery();
            while( rs.next() ) {
            	arOrdNo.add(rs.getString("ord_no"));
            	arOrdPrdSeq.add(rs.getString("ord_prd_seq"));
            	arMemNo.add(rs.getString("mem_no"));
            	arOrdDt.add(rs.getString("ord_dt"));
            	arExpSavePnt.add(rs.getString("ext_pnt"));
            	arOcbCardNum.add(rs.getString("ocb_card_num"));
            	arOcbRsdntNo.add(rs.getString("ocb_rsdnt_no"));
            	arCardAmt.add(rs.getString("card_amt"));
            	cnt++;
            }
            eTime = System.currentTimeMillis();
            log.error("���Ǽ�===>"+cnt);
            log.error("512 OCB �̺�Ʈ 5�� ���� ���ǰ������� ���� : ����ð� ===> "+((double)(eTime-sTime) / (double)1000)+" sec");

            DBHandler.closeDBResource(rs,pstmt);
            DBHandler.closeDBResource(conn);

        } catch (Exception e) {
			batchLogEnd(batch_no, "-1", "ERROR", "step.01", "Y", "512 OCB �̺�Ʈ 5�� ���� ��ȸ ����", "512 OCB �̺�Ʈ 5�� ���� ��ȸ ����");
            e.printStackTrace();
            log.error(e.toString());
            return;
        } finally {
            try {
                DBHandler.closeDBResource(rs,pstmt);
                DBHandler.closeDBResource(conn);
            } catch (Exception e) {}
        }


        /******************************
         * 512 OCB �̺�Ʈ 5�� ���� ó��
         */

        if (arOrdNo.size() <= 0) {
			batchLogEnd(batch_no, "0", "Success", "N/A", "N", "512 OCB �̺�Ʈ 5�� ���� ���� : ������", "512 OCB �̺�Ʈ 5�� ���� ���� : ������");
			return;
        }

        String msg = "512 OCB �̺�Ʈ 5�� ����";
        try {
        	BuyManagementService buyManagementService = (BuyManagementService)ServiceFactory.createService( BuyManagementServiceImpl.class );
		    EventOcb512BO		 paramBO              = null;

            long cntSucc = 0;
            long cntFail = 0;
            int cntProc = 0;

            for(int i=0; i<arOrdNo.size(); i++)
            {
            	sTime = System.currentTimeMillis();
                cntProc ++;
                log.info("############################################################");
                log.info("### [" + cntProc + "] �ֹ���ȣ : " + (String)arOrdNo.get(i) + "/�ֹ����� : " + (String)arOrdPrdSeq.get(i) + " START~!!");
                log.info("############################################################");
                try {
                    paramBO = (EventOcb512BO)BOFactory.createBO(EventOcb512BO.class);
                    paramBO.setOrdNo( (String)arOrdNo.get(i) );
                    paramBO.setOrdPrdSeq( (String)arOrdPrdSeq.get(i) );
                    paramBO.setMemNo( (String)arMemNo.get(i) );
                    paramBO.setOrdDt( (String)arOrdDt.get(i) );
                    paramBO.setExpSavePnt( (String)arExpSavePnt.get(i) );

                    paramBO.setOcbCardNumber( (String)arOcbCardNum.get(i) );
                    paramBO.setOcbRsdntNo( (String)arOcbRsdntNo.get(i) );
                    paramBO.setOcbRsdntNoByEncrypt( (String)arOcbRsdntNo.get(i) );
                    if(Long.parseLong((String)arCardAmt.get(i)) > 0){
                    	paramBO.setIsCardPay("Y");
                    }else{
                    	paramBO.setIsCardPay("N");
                    }

                    buyManagementService.updateOcb512Event(paramBO);

                    cntSucc++;

                } catch (SQLException e) {
                    log.error("512 OCB �̺�Ʈ 5�� ����ó�� ����!");
                    log.error(e.getMessage());
                    log.error("### 1�ֹ���ȣ : " + (String)arOrdNo.get(i) + "/�ֹ����� : " + (String)arOrdPrdSeq.get(i));
                    cntFail++;
                } catch (Exception e) {
                    log.error("512 OCB �̺�Ʈ 5�� ����ó�� ����!");
                    log.error(e.getMessage());
                    log.error("### 2�ֹ���ȣ : " + (String)arOrdNo.get(i) + "/�ֹ����� : " + (String)arOrdPrdSeq.get(i));
                    cntFail++;
                }
                eTime = System.currentTimeMillis();
                if ( ((i+1)%5000) == 0 )
                {
                	log.error("[" + String.valueOf(i+1) + "/" + String.valueOf(arOrdNo.size()) + "] 512 OCB �̺�Ʈ 5�� ����("+(String)arOrdNo.get(i)+","+(String)arOrdPrdSeq.get(i)+") ����ð�===> "+((double)(eTime-sTime) / (double)1000)+" sec");
                }
                log.info("############################################################");
                log.info("### [" + cntProc + "] �ֹ���ȣ : " + (String)arOrdNo.get(i) + "/�ֹ����� : " + (String)arOrdPrdSeq.get(i) + " END~!!");
                log.info("############################################################");
            }

            msg += " : ���� " + cntSucc + "��";
            msg += " : ���� " + cntFail + "��";
            String errYN = (cntFail > 0) ? "Y" : "N";

        	batchLogEnd(batch_no, "0", "Success", "step.02", errYN, msg, msg);
        } catch (Exception e) {
			batchLogEnd(batch_no, "-1", "ERROR", "step.03", "Y", "512 OCB �̺�Ʈ 5�� ���� ����", "512 OCB �̺�Ʈ 5�� ���� ����");
            e.printStackTrace();
            log.error(e.toString());
        } finally {
            log.error("===== "+msg+" END =====");
        }
    }

} // end of class