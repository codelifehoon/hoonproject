package skt.tmall.daemon.escrow;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

import skt.tmall.BOFactory;
import skt.tmall.ServiceFactory;
import skt.tmall.business.escrow.trade.domain.OrderProductBO;
import skt.tmall.daemon.common.util.DBHandler;
import skt.tmall.process.share.escrow.buymng.service.BuyManagementService;
import skt.tmall.process.share.escrow.buymng.service.BuyManagementServiceImpl;

/**
 * �ڵ�����Ȯ�� ��ġ
 * @author ZZ07237
 *
 */
public class E02_AutoDecisionBatch extends EscrowBaseDaemon {
    /**
     * @param args
     */
    public static void main(String[] args) {
        EscrowBaseDaemon.initSqlMap();
        E02_AutoDecisionBatch dm = new E02_AutoDecisionBatch();
        dm.run();
    }

	public void run() {
		batch_no = 2502;
    	batchID = "tmba_bo_02";
    	batchName = "�ڵ�����Ȯ�� DATA ����(401)";

		/* ��ø ���� ����  */
		if (isRunning(batch_no)) {
			String errMsg = "�̹� �������Դϴ�";
			log.error(errMsg);
			batchLogPrint(batch_no, null, null, "-1", "User Define Error", "N/A", "Y", errMsg, errMsg);
			return;
		}

		run_sub();
	}

	@SuppressWarnings("unchecked")
	public void run_sub() {
    	log.debug("===== "+batchName+" START =====");

		batchLogStart(batch_no,"�ڵ�����Ȯ��");

        Connection conn = null;
        PreparedStatement pstmt = null;
        ResultSet rs = null;

        long sTime = 0;
        long eTime = 0;

        StringBuffer buff = new StringBuffer();
        buff.append(" SELECT /* E02_AutoDecisionBatch.java */																		\n");
        buff.append("        /*+ full(b) parallel(b 4) use_nl(b c) */                                                               \n");
        buff.append("         b.ORD_PRD_STAT_CHG_DT																					\n");
        buff.append("         , b.ORD_STL_END_DT																					\n");
        buff.append("         , b.ord_no as ord_no																					\n");
        buff.append("         , b.ord_prd_seq as ord_prd_seq																		\n");
        buff.append("         , b.ord_qty - b.ord_cn_qty as qty																		\n");
        buff.append(" FROM tr_ord_prd b																								\n");
        buff.append(" 	  ,tr_ord_clm_dlv_dtls c																					\n");
        buff.append(" WHERE 1=1                                                                       								\n");
        buff.append(" 	and b.dlv_no = c.dlv_no                                                       								\n");
        buff.append("   and b.ord_prd_stat = '401'                                                    								\n");
        buff.append("   AND b.ORD_PRD_STAT_CHG_DT >= to_date(to_char(sysdate-81, 'yyyymmdd')||'235959', 'yyyymmddhh24miss')         \n");
        buff.append("   AND b.ORD_PRD_STAT_CHG_DT <= to_date(to_char(sysdate-21, 'yyyymmdd')||'235959', 'yyyymmddhh24miss')         \n");
        buff.append("   AND b.ord_qty - b.ord_cn_qty - b.ord_cn_req_qty > 0															\n");
        buff.append(" 	and c.dlv_err_yn = 'N' /* ��ۿ����� 21�� �ڵ�����Ȯ�� �Ұ� */													\n");
        buff.append("   and (b.CHINA_SALE_YN is null or b.CHINA_SALE_YN = 'N')    /*þ�Ż�ǰ����*/                            		\n");
        buff.append("   and b.PRD_TYP_CD != '13'   								  /*�����ǰ����*/  									\n");

        /***************************************************
         * ����Ȯ�� ��� ��ȸ
         */
        List arOrdNo 		= new ArrayList();
        List arOrdPrdSeq	= new ArrayList();
        int cnt = 0;

        try {

            conn = DBHandler.getConnection(dbUrl,dbId,dbPwd);
            if (conn == null) {
                log.error("Connection is NULL !!!");
                throw new Exception("Connection is NULL !!!");
            }

            log.info(buff.toString());
            pstmt = conn.prepareStatement(buff.toString());
sTime = System.currentTimeMillis();
log.error("�ڵ�����Ȯ�� ���ǰ������� ����");
            rs = pstmt.executeQuery();
            while( rs.next() ) {
            	arOrdNo.add(rs.getString("ord_no"));
            	arOrdPrdSeq.add(rs.getString("ord_prd_seq"));
            	cnt++;
            }
eTime = System.currentTimeMillis();
log.error("���Ǽ�===>"+cnt);
log.error("�ڵ�����Ȯ�� ���ǰ������� ���� : ����ð� ===> "+((double)(eTime-sTime) / (double)1000)+" sec");

            DBHandler.closeDBResource(rs,pstmt);
            DBHandler.closeDBResource(conn);

        } catch (Exception e) {
			batchLogEnd(batch_no, "-1", "ERROR", "step.01", "Y", "�ڵ�����Ȯ�� ��ȸ ����", "�ڵ�����Ȯ�� ��ȸ ����");
            e.printStackTrace();
            log.error(e.toString());
            return;
        } finally {
            try {
                DBHandler.closeDBResource(rs,pstmt);
                DBHandler.closeDBResource(conn);
            } catch (Exception e) {}
        }


        /******************************
         * ����Ȯ�� ó��
         */

        if (arOrdNo.size() <= 0) {
			batchLogEnd(batch_no, "0", "Success", "N/A", "N", "�ڵ�����Ȯ�� ���� : ������", "�ڵ�����Ȯ�� ���� : ������");
			return;
        }

        String msg = "�ڵ�����Ȯ��401";
        try {
            BuyManagementService buyManagementService = (BuyManagementService)ServiceFactory.createService( BuyManagementServiceImpl.class );
            String[] arrOrdPrdSeq = new String[1];
            OrderProductBO paramBO = null;

            long cntSucc = 0;
            long cntFail = 0;
            int cntProc = 0;

            for(int i=0; i<arOrdNo.size(); i++)
            {
            	sTime = System.currentTimeMillis();
                cntProc ++;
                log.info("############################################################");
                log.info("### [" + cntProc + "] �ֹ���ȣ : " + (String)arOrdNo.get(i) + "/�ֹ����� : " + (String)arOrdPrdSeq.get(i) + " START~!!");
                log.info("############################################################");
                try {
                    paramBO = (OrderProductBO)BOFactory.createBO(OrderProductBO.class);
                    paramBO.setOrdPrdStat("901");
                    paramBO.setUpdateNo("0");
                    paramBO.setOrdNo( (String)arOrdNo.get(i) );
                    arrOrdPrdSeq[0] = (String)arOrdPrdSeq.get(i);
                    paramBO.setOrdPrdSeqArr(arrOrdPrdSeq);

                    buyManagementService.registerOrderDecision(paramBO);

                    cntSucc++;

                } catch (SQLException e) {
                    log.error("�ڵ� ����Ȯ��ó�� ����!");
                    log.error(e.getMessage());
                    log.error("### 1�ֹ���ȣ : " + (String)arOrdNo.get(i) + "/�ֹ����� : " + (String)arOrdPrdSeq.get(i));
                    cntFail++;
                } catch (Exception e) {
                    log.error("�ڵ� ����Ȯ��ó�� ����!");
                    log.error(e.getMessage());
                    log.error("### 2�ֹ���ȣ : " + (String)arOrdNo.get(i) + "/�ֹ����� : " + (String)arOrdPrdSeq.get(i));
                    cntFail++;
                }
                eTime = System.currentTimeMillis();
                if ( ((i+1)%5000) == 0 )
                {
log.error("[" + String.valueOf(i+1) + "/" + String.valueOf(arOrdNo.size()) + "] �ڵ�����Ȯ��("+(String)arOrdNo.get(i)+","+(String)arOrdPrdSeq.get(i)+") ����ð�===> "+((double)(eTime-sTime) / (double)1000)+" sec");
                }
                log.info("############################################################");
                log.info("### [" + cntProc + "] �ֹ���ȣ : " + (String)arOrdNo.get(i) + "/�ֹ����� : " + (String)arOrdPrdSeq.get(i) + " END~!!");
                log.info("############################################################");
            }

            msg += " : ���� " + cntSucc + "��";
            msg += " : ���� " + cntFail + "��";
            String errYN = (cntFail > 0) ? "Y" : "N";

        	batchLogEnd(batch_no, "0", "Success", "step.02", errYN, msg, msg);
        } catch (Exception e) {
			batchLogEnd(batch_no, "-1", "ERROR", "step.03", "Y", "�ڵ�����Ȯ�� ����", "�ڵ�����Ȯ�� ����");
            e.printStackTrace();
            log.error(e.toString());
        } finally {
            log.error("===== "+msg+" END =====");
        }
    }

} // end of class