package skt.tmall.daemon.escrow;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;

import skt.tmall.common.util.CmnUtil;
import skt.tmall.common.util.EDate;
import skt.tmall.daemon.common.util.DBHandler;

/**
 * �ֹ����� ����͸�
 * �� �������ܺ� ������ �ð��� �ŷ��� �����ϴ��� Ȯ���Ѵ�.
 * @author �����
 * @version 0.1
 */
public class E19_OrderStlMonitoring extends EscrowBaseDaemon {

	/**
	 * @param args
	 */
	public static void main(String[] args) {
        EscrowBaseDaemon.initSqlMap();
        E19_OrderStlMonitoring dm = new E19_OrderStlMonitoring();
		dm.run();
	}

	public void run() {
		batchName = "�ֹ����� ����͸�";
        batch_no = 2519;
        
		
        /* ��ø ���� ����  */
//        if (isRunning(batch_no)) {
//            String errMsg = "�̹� �������Դϴ�:";
//            log.error(errMsg);
//            batchLogPrint(batch_no, null, null, "-1", "User Define Error", "N/A", "Y", errMsg, errMsg);
//            return;
//        }
		
		run_sub();
	}

	public void run_sub() {
		log.debug("===== "+batchName+" START =====");
		
        batchLogStart(batch_no,"��ġ ����");
    	
        try {
        	long minute = 60;
        	
        	/**
        	 * 2 ~ 9 �� ���̿��� 60�д����� üũ�ϰ�
        	 * �̿��� �ð����� 30�д����� üũ�Ѵ�.
        	 */
        	long hh = CmnUtil.parseLong(EDate.today("HH"));
        	if (hh < 2 || 9 < hh) {
        		minute = 30;
        	}
        	
        	String[][] mnsClfList = {
        			  {"01","�ſ�ī��"}	
        			, {"02","������"}	
        			, {"03","�ǽð� ������ü"}	
        			, {"05","OKĳ����"}	
        			, {"10","�޴����Ҿװ���"}	
        		};
        	
        	for (int i=0; i<mnsClfList.length; i++) {
        		long stlCnt = getOrderStlCount(mnsClfList[i][0], minute); 
            	if (stlCnt > 0) {
            		String errMsg = minute + "�а� "+mnsClfList[i][1]+" �ŷ��� "+stlCnt+"�� �ֽ��ϴ�.";
            		batchLogPrint(batch_no, null, null, "0", "Success", "N/A", "N", errMsg, "");
            	} else {
            		long pasCnt = getPasStlCount(mnsClfList[i][0], minute);
            		if (pasCnt > 0) {
            			// 11���� �ŷ��� ���� PAS �ŷ��� �ִ°�� ������ ó����
	            		String errMsg = minute + "�а� "+mnsClfList[i][1]+" �ŷ��� �����ϴ�. Ȯ�� �ٶ��ϴ�!";
	            		errMsg += " PAS�ŷ�:"+pasCnt+"��";
	            		batchLogPrint(batch_no, null, null, "-1", "User Define Error", "N/A", "Y", errMsg, errMsg);
            		} else {
            			// 11���� �ŷ� �� PAS �ŷ��� ���°�� log�� ����ϰ� ����ó�� ����
	            		String errMsg = minute + "�а� "+mnsClfList[i][1]+" �ŷ� �� PAS�ŷ��� �����ϴ�";
	            		batchLogPrint(batch_no, null, null, "0", "Success", "N/A", "N", errMsg, errMsg);
            		}
            	}
        	}
        	
        	batchLogEnd(batch_no, "0", "Success", "N/A", "N", "����", null);
        }
        catch(Exception e) {
        	
        	e.printStackTrace();
        	log.error(e.toString());
        	
            String err="";
            err += " Err:"+e.toString();
            batchLogEnd(batch_no, "-1", "Error", "N/A", "Y", err, batchName + " ����");
            log.error(e);
		} finally {
			log.debug("===== "+batchName+" END =====");
		}
        log.info(batchName + " ����!!");
    }
	
	public long getOrderStlCount(String mnsClfCd, long minute) {
		
		long resultCnt = 0;

		Connection conn = null;
		PreparedStatement pstmt = null;
		ResultSet rs = null;
		
		StringBuffer buff = new StringBuffer();
		buff.append(" select                                  	\n");
		buff.append("     count(1) as cnt                    	\n");
		buff.append(" from TR_ORD_STL_RFND                    	\n");
		buff.append(" where RCVM_CLF_CD = '01'              	\n");
		buff.append("     and STL_MNS_CLF_CD = ?	          	\n");
		buff.append("     and create_dt > sysdate - (?/1440)	\n");

		try {
			conn = DBHandler.getConnection(dbUrl,dbId,dbPwd);
			if (conn == null) {
				log.error("Connection is NULL !!!");
				throw new Exception("Connection is NULL !!!");
			}
			
			pstmt = conn.prepareStatement(buff.toString());
			pstmt.setString(1, mnsClfCd);
			pstmt.setLong(2, minute);
			
			rs = pstmt.executeQuery();
			while( rs.next() ) {
				resultCnt = rs.getLong("CNT");
			}

			DBHandler.closeDBResource(rs,pstmt);
			DBHandler.closeDBResource(conn);

		} catch (Exception e) {
			e.printStackTrace();
			log.error(e.toString());
			batchLogPrint(batch_no, null, null, "-1", "User Define Error", "N/A", "Y", e.toString(), "11���� ����Ȯ�� ����");
		} finally {
			try {
				DBHandler.closeDBResource(rs,pstmt);
				DBHandler.closeDBResource(conn);
			} catch (Exception e) {}
		}

		return resultCnt;
	}

	public long getPasStlCount(String mnsClfCd, long minute) {
		
		long resultCnt = 0;

		Connection conn = null;
		PreparedStatement pstmt = null;
		ResultSet rs = null;
		
		StringBuffer buff = new StringBuffer();
		if ("01".equals(mnsClfCd)) {
			// ī��
			buff.append(" select                            	\n ");
			buff.append(" 	count(1) as cnt                 	\n ");
			buff.append(" from transaction                  	\n ");
			buff.append(" where txtstamp > sysdate - (?/1440)	\n ");
		} else if ("02".equals(mnsClfCd)) {
			// ������
			buff.append(" select                                                            \n ");
			buff.append(" 	count(1) as cnt                                                 \n ");
			buff.append(" from vatr                                                         \n ");
			buff.append(" where appdate > to_char(sysdate - (?/1440), 'yyyymmddhh24miss')	\n ");
		} else if ("03".equals(mnsClfCd)) {
			// �ǽð�������ü
			buff.append(" select                                                          	\n ");
			buff.append(" 	count(1) as cnt                                               	\n ");
			buff.append(" from trkftc                                                     	\n ");
			buff.append(" where appdate > to_char(sysdate - (?/1440), 'yyyymmddhh24miss')	\n ");
		} else if ("05".equals(mnsClfCd)) {
			// OCB
			buff.append(" select                                                          	\n ");
			buff.append(" 	count(1) as cnt                                               	\n ");
			buff.append(" from ocbtr                                                     	\n ");
			buff.append(" where appdate > to_char(sysdate - (?/1440), 'yyyymmddhh24miss')	\n ");
			buff.append(" and txcode = 'EC191000'											\n ");
		} else if ("10".equals(mnsClfCd)) {
			// �޴����Ҿװ���
			buff.append(" select                                                          	\n ");
			buff.append(" 	count(1) as cnt                                               	\n ");
			buff.append(" from pbilltr                                                     	\n ");
			buff.append(" where appdate > to_char(sysdate - (?/1440), 'yyyymmddhh24miss')	\n ");
		} else {
			return 0;
		}

		try {
			conn = DBHandler.getConnection(dbUrl,dbId,dbPwd);
			if (conn == null) {
				log.error("Connection is NULL !!!");
				throw new Exception("Connection is NULL !!!");
			}
			
			pstmt = conn.prepareStatement(buff.toString());
			pstmt.setLong(1, minute);
			
			rs = pstmt.executeQuery();
			while( rs.next() ) {
				resultCnt = rs.getLong("CNT");
			}

			DBHandler.closeDBResource(rs,pstmt);
			DBHandler.closeDBResource(conn);

		} catch (Exception e) {
			e.printStackTrace();
			log.error(e.toString());
			batchLogPrint(batch_no, null, null, "-1", "User Define Error", "N/A", "Y", e.toString(), "PAS����Ȯ�� ����");
		} finally {
			try {
				DBHandler.closeDBResource(rs,pstmt);
				DBHandler.closeDBResource(conn);
			} catch (Exception e) {}
		}

		return resultCnt;
	}

} // end of class
